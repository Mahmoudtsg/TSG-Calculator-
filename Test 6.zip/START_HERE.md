# 🚀 START HERE - TSG Salary Calculator v1.1.6

## Welcome! 👋

This is the **TSG Salary & Cost Calculator** - a professional payroll and business margin calculator for Switzerland, Romania, and Spain.

---

## ⚡ Quick Start (30 seconds)

### 1. Open the Calculator
```
Double-click: index.html
```

That's it! No installation needed. ✅

### 2. Start Using
- **Employee Mode:** Calculate salaries, taxes, and costs
- **B2B Mode:** Calculate margins and client rates

### 3. Need Help?
- Hover over any **[?]** icon for calculation formulas
- Exchange rates update automatically every 24 hours
- All calculations happen instantly

---

## 📚 Documentation Overview

### 🎯 Essential Reading (Pick Based on Your Need):

| Document | When to Read | Time |
|----------|--------------|------|
| **README.md** | Full overview + country rules | 10 min |
| **RELEASE_NOTES.md** | What's new in v1.1.6 | 2 min |
| **FINAL_SUMMARY_v1.1.6.md** | Complete feature list | 5 min |
| **BEFORE_AFTER_v1.1.6.md** | Visual changes explained | 3 min |

### 🧪 For Testers:

| Document | Purpose | Time |
|----------|---------|------|
| **TESTING_GUIDE_v1.1.6.md** | Test scenarios + formulas | 8 min |
| **IMPLEMENTATION_VERIFIED_v1.1.6.md** | Code verification details | 6 min |

### 🚀 For Deployment:

| Document | Purpose | Time |
|----------|---------|------|
| **DEPLOYMENT_READY_v1.1.6.md** | Deployment checklist | 4 min |

---

## 🎯 What Does This Calculator Do?

### Employee Mode (Payroll):
Calculate for any employee in 3 countries:
- ✅ **Net Salary** → What they receive
- ✅ **Gross Salary** → Before deductions
- ✅ **Total Cost** → What company pays (with employer contributions)

**Features:**
- Start from Net, Gross, OR Total
- Occupation Rate (60%, 80%, 100%)
- Meal Benefits (non-taxable Romania)
- Dual currency display (original + EUR)
- PDF export with employee details

### B2B Mode (Staffing Margins):
Calculate client rates and profit margins:
- ✅ **Daily Cost Rate** → Cost to hire contractor
- ✅ **Daily Placement Rate** → Rate to charge client
- ✅ **Profit Margin** → Your profit (%)
- ✅ **Monthly/Annual** → Full breakdown

**Features:**
- Target Margin % (TRUE profit margin!)
- Fixed Daily Amount option
- Multi-currency support (EUR/CHF/RON)
- Display in EUR, CHF, or Both

---

## 🌍 Supported Countries

| Country | Currency | Key Features |
|---------|----------|--------------|
| **Switzerland** 🇨🇭 | CHF | AVS, LPP, LAA, Canton tax (estimate) |
| **Romania** 🇷🇴 | RON | CAS, CASS, CAM, IT exemptions, Meal benefits |
| **Spain** 🇪🇸 | EUR | SS contributions, IRPF (estimate) |

---

## 💡 Common Use Cases

### 1. "What's the net salary for 15,000 RON gross?"
```
1. Select: Romania
2. Mode: Gross
3. Enter: 15,000 RON
4. Click: Calculate
→ Result: ~9,000 RON net + employer costs
```

### 2. "I pay 500 EUR/day, what should I charge for 30% margin?"
```
1. Select: B2B Mode
2. Contractor Cost: 500 EUR
3. Pricing Mode: Target Margin %
4. Target: 30
5. Click: Calculate
→ Result: 714.29 EUR client rate (exactly 30% margin!)
```

### 3. "Part-time employee at 80% occupation?"
```
1. Select country
2. Enter full-time salary: 10,000 RON
3. Occupation Rate: 80%
4. Click: Calculate
→ Result: Adjusted to 8,000 RON (working days stay 220)
```

---

## ⚡ Key Features

### ✅ What Makes v1.1.6 Special:

1. **TRUE Profit Margin** (Not Markup!)
   - Old: 30% target → 23% actual ❌
   - New: 30% target → 30% actual ✅

2. **Correct Occupation Rate**
   - Old: 80% → 176 days ❌
   - New: 80% → 220 days ✅

3. **Fixed Currency Conversion**
   - Old: 10,000 RON → 49,700 CHF ❌
   - New: 10,000 RON → 1,871 CHF ✅

4. **Better UX**
   - 22 help icons (? instead of !)
   - Display Currency in logical position
   - Smart hiding of unnecessary outputs

---

## 🧪 Try These Examples

### Example 1: Romania Employee (Monthly Gross)
```
Country: Romania
Mode: Gross
Amount: 15,000 RON
Period: Monthly

Expected Results:
- Net Salary: ~9,000 RON (after CAS, CASS, tax)
- Total Cost: ~16,543 RON (with CAM)
- Daily Cost: ~900 RON (÷ 220 days)
```

### Example 2: B2B with 30% Margin
```
Mode: B2B
Contractor Cost: 500 EUR/day
Pricing Mode: Target Margin %
Target Margin: 30%
Working Days: 220

Expected Results:
- Daily Placement Rate: 714.29 EUR
- Daily Profit: 214.29 EUR (30%)
- Monthly Profit: 3,928.63 EUR
- Annual Profit: 47,143 EUR
```

### Example 3: Switzerland Part-time
```
Country: Switzerland
Mode: Gross
Amount: 8,000 CHF (monthly)
Occupation: 80%

Expected Results:
- Adjusted Salary: 6,400 CHF
- Working Days: 220 (NOT 176!)
- Daily Cost: [Annual Total ÷ 220]
```

---

## 🎓 Understanding the Interface

### Top Section (Always Visible):
```
┌──────────────────────────────────┐
│ [Employee] [B2B]                 │  ← Mode selector
│                                  │
│ Country: [Switzerland ▼]        │  ← Select country
│                                  │
│ Calculation Mode:                │
│  ○ Net  ● Gross  ○ Total        │  ← Start point
└──────────────────────────────────┘
```

### Employee Inputs:
```
┌──────────────────────────────────┐
│ Employee Name: ___________       │
│ Date of Birth: __/__/____        │
│ Role: ___________                │
│                                  │
│ Salary Period: [Monthly ▼]      │
│ Gross Salary: [5000] CHF        │
│ Occupation Rate: [100]%          │
│                                  │
│ [⚙️ Advanced Options]            │
└──────────────────────────────────┘
```

### B2B Inputs:
```
┌──────────────────────────────────┐
│ Contractor Cost/Day: [500] EUR   │
│ Client Daily Rate: [750] CHF     │
│ Display Currency: [Both ▼]       │
│ Working Days: [220]              │
│                                  │
│ Pricing Mode:                    │
│  ● Target Margin %  ○ Fixed      │
│  Target Margin: [30]%            │
└──────────────────────────────────┘
```

### Results (Auto-displayed):
```
┌──────────────────────────────────┐
│ 💰 Payroll Summary               │
│ ┌──────────────────────────────┐ │
│ │ Net Salary: 9,000 RON [?]    │ │
│ │ Gross Salary: 15,000 RON [?] │ │
│ │ Total Cost: 16,543 RON [?]   │ │
│ └──────────────────────────────┘ │
│                                  │
│ [Download PDF] [Print]           │
└──────────────────────────────────┘
```

---

## ❓ FAQ

### Q: Do I need to install anything?
**A:** No! Just open `index.html` in your browser. ✅

### Q: Does it work offline?
**A:** Yes, after first load. Exchange rates cached for 24h. ✅

### Q: How do I update exchange rates?
**A:** They auto-update every 24h. Or click the 🔄 button. ✅

### Q: What's "Occupation Rate"?
**A:** For part-time employees. 80% = 80% of salary, but working days stay 220. ✅

### Q: What's "Target Margin %"?
**A:** Your desired profit margin. E.g., 30% means 30% of revenue is profit. ✅

### Q: Can I export to PDF?
**A:** Yes! Click "Download PDF" after calculating. ✅

### Q: What are the [?] icons?
**A:** Help tooltips! Hover to see calculation formulas. ✅

---

## 🚨 Important Notes

### ⚠️ For Switzerland:
- Income tax NOT included (varies by canton)
- LPP rates configurable (default 7%)
- Results are pre-tax estimates

### ⚠️ For Romania:
- IT workers may be tax-exempt
- Meal benefits are non-taxable
- Personal deduction: 510 RON/month (if "base function")

### ⚠️ For Spain:
- IRPF is an estimate (varies by region)
- Contribution base limits applied
- Actual tax depends on personal situation

---

## 🔗 Quick Links

### Need Specific Information?

| I want to... | Read this |
|--------------|-----------|
| Understand all features | README.md |
| See what changed | RELEASE_NOTES.md |
| Test the calculator | TESTING_GUIDE_v1.1.6.md |
| Deploy to production | DEPLOYMENT_READY_v1.1.6.md |
| Compare old vs new | BEFORE_AFTER_v1.1.6.md |
| Get complete summary | FINAL_SUMMARY_v1.1.6.md |
| Verify implementation | IMPLEMENTATION_VERIFIED_v1.1.6.md |

---

## 💪 Power User Tips

### 1. Keyboard Shortcuts
- `Ctrl/Cmd + Enter` - Calculate
- `Ctrl/Cmd + P` - Print

### 2. Advanced Options (⚙️ button)
- Monthly Meal Benefits (Romania)
- Number of Dependents
- Tax Exemption checkbox
- LPP/LFP rates (Switzerland)

### 3. Currency Display
- B2B Mode: Choose EUR, CHF, or Both
- See same result in multiple currencies

### 4. Formula Transparency
- Hover [?] icons to see exact formulas
- Understand how numbers are calculated

---

## 📞 Need Help?

### Common Issues:

**Calculator not loading?**
→ Clear browser cache (Ctrl+F5)

**Wrong results?**
→ Check exchange rates (click 🔄 to refresh)

**PDF not working?**
→ Allow popups in browser

**Numbers look wrong?**
→ Ensure correct country selected

---

## ✅ You're Ready!

1. ✅ Open `index.html`
2. ✅ Select your mode (Employee or B2B)
3. ✅ Enter your data
4. ✅ Click Calculate
5. ✅ Get instant results!

**That's it! You're now a TSG Calculator expert! 🎓**

---

## 🎯 Quick Test (30 seconds)

Try this to verify everything works:

1. Open calculator
2. Select: Romania
3. Mode: Gross
4. Enter: 15,000 RON
5. Click: Calculate

**Expected:**
- Net: ~9,000 RON ✅
- Total Cost: ~16,543 RON ✅
- Daily Cost: ~900 RON ✅

**If you see these numbers, you're good to go! 🎉**

---

**Version:** 1.1.6 (Final)  
**Status:** ✅ Production Ready  
**Date:** 2025-12-19  

**Happy Calculating! 🚀**

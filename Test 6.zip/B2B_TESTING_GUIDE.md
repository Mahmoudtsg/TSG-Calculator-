# B2B UX Improvements - Quick Testing Guide

**Test Date:** 2026-01-09  
**Version:** 1.2.0

---

## 🧪 Quick Test Scenarios

### Test 1: Hourly Cost Mode
**Steps:**
1. Open calculator
2. Select "B2B" engagement type
3. Enter:
   - Contractor Cost: 100 EUR
   - Cost Unit: **Per Hour**
   - Pricing Mode: Target Margin %
   - Target Margin: 30%
4. Click Calculate

**Expected Results:**
- Daily Cost: 800 EUR (100 × 8)
- Daily Revenue: 1,142.86 EUR
- Daily Profit: 342.86 EUR
- Margin: 30%

✅ Pass Criteria: Daily cost shows 800 EUR, margin is exactly 30%

---

### Test 2: RON Currency Support
**Steps:**
1. Select "B2B" engagement type
2. Enter:
   - Contractor Cost: 5000 **RON**
   - Cost Unit: Per Day
   - Pricing Mode: Target Margin %
   - Target Margin: 25%
4. Click Calculate

**Expected Results:**
- All amounts displayed in RON
- Daily Revenue: 6,666.67 RON
- Margin: 25%

✅ Pass Criteria: Results show in RON, no EUR conversion

---

### Test 3: Post-Calculation Conversion
**Steps:**
1. Perform calculation with:
   - Contractor Cost: 500 EUR
   - Target Margin: 30%
2. After results appear, change:
   - "Convert results to:" → **CHF**

**Expected Results:**
- All amounts convert to CHF
- Margin stays exactly 30%
- Shows conversion rate: "1 EUR = X CHF"
- Shows last update date

✅ Pass Criteria: 
- Amounts in CHF
- Margin unchanged (30%)
- Rate info displayed

---

### Test 4: Cross-Rate Conversion (CHF → RON)
**Steps:**
1. Calculate with:
   - Contractor Cost: 1000 CHF
   - Target Margin: 20%
2. Convert results to: **RON**

**Expected Results:**
- Amounts convert via EUR intermediate
- Formula: CHF → EUR → RON
- Shows cross rate: "1 CHF = X RON"
- Margin stays 20%

✅ Pass Criteria:
- Conversion works correctly
- Margin preserved
- Cross rate displayed

---

### Test 5: Business Outputs Hidden
**Steps:**
1. Perform ANY B2B calculation
2. Try different currency combinations:
   - EUR cost, CHF client rate
   - CHF cost, EUR client rate
   - RON cost, EUR client rate

**Expected Results:**
- "Business Outputs" card NEVER appears
- Results section only shows B2B summary

✅ Pass Criteria: No Business Outputs card visible

---

### Test 6: Client Rate Mode
**Steps:**
1. Enter:
   - Contractor Cost: 400 EUR
   - Pricing Mode: **Client Daily Rate**
   - Client Daily Rate: 600 EUR
2. Calculate

**Expected Results:**
- Daily Revenue: 600 EUR
- Daily Profit: 200 EUR
- Margin: 33.33%

✅ Pass Criteria: Margin calculated correctly from revenue

---

### Test 7: Mixed Currency Mode
**Steps:**
1. Enter:
   - Contractor Cost: 500 EUR
   - Pricing Mode: Client Daily Rate
   - Client Daily Rate: 700 **CHF**
2. Calculate

**Expected Results:**
- System converts CHF to EUR internally
- Results display in EUR (cost currency)
- Margin calculated correctly

✅ Pass Criteria: 
- Conversion automatic
- Results in cost currency

---

### Test 8: Employee Mode Unchanged
**Steps:**
1. Switch to "Employee" mode
2. Select any country (Switzerland/Romania/Spain)
3. Perform standard employee calculation
4. Check Business Outputs card

**Expected Results:**
- All employee features work normally
- Business Outputs card VISIBLE for employee
- No interference from B2B changes

✅ Pass Criteria: Employee mode unaffected

---

## 🎯 Critical Validations

### Validation 1: Cost Unit Normalization
```
Hourly = 100 → Daily must be 800
Hourly = 50  → Daily must be 400
Daily = 500  → Daily stays 500
```

### Validation 2: Margin Preservation
```
Before conversion: 30% margin
After conversion: EXACTLY 30% margin
(No rounding differences > 0.01%)
```

### Validation 3: Cross-Rate Formula
```
CHF → RON conversion:
Step 1: CHF → EUR = value / CHF_per_EUR
Step 2: EUR → RON = result × RON_per_EUR
```

### Validation 4: Default Display
```
Cost in EUR → Display in EUR ✓
Cost in CHF → Display in CHF ✓
Cost in RON → Display in RON ✓
```

---

## 🔍 Edge Cases to Test

### Edge Case 1: Very Small Margin
- Target Margin: 1%
- Verify calculation accuracy

### Edge Case 2: Large Numbers
- Contractor Cost: 10,000 CHF
- Verify formatting and calculations

### Edge Case 3: Switching Cost Unit
- Enter 100 as hourly → Switch to daily → Should stay 100
- Enter 100 as daily → Switch to hourly → Should stay 100

### Edge Case 4: API Failure
- Disconnect network
- Verify fallback rates used
- Check "fallback rate" indicator shows

---

## 🛠️ Debugging Tips

### Issue: Conversion Not Working
**Check:**
1. Console for FX API errors
2. FXService cache status
3. Network tab for API calls

### Issue: Wrong Margin After Conversion
**Check:**
1. Original margin % before conversion
2. Calculation: (profit / revenue) × 100
3. Should be identical before/after

### Issue: Business Outputs Visible
**Check:**
1. Confirm B2B mode is active
2. Inspect `activeMode` variable
3. Verify `displayB2BResults()` called

---

## ✅ Final Verification Checklist

- [ ] Hourly cost converts to daily (×8)
- [ ] Results default to input currency
- [ ] Post-calculation converter works
- [ ] EUR/CHF/RON all supported
- [ ] Cross-rate conversions correct
- [ ] Margin % preserved exactly
- [ ] Business Outputs never shows
- [ ] Employee mode unaffected
- [ ] Conversion rate displayed
- [ ] Fallback rates work
- [ ] All currencies format correctly
- [ ] No console errors

---

## 📊 Expected Calculation Examples

### Example 1: 30% Margin Target
```
Input:
- Cost: 500 EUR/day
- Margin: 30%

Output:
- Revenue: 714.29 EUR/day
- Profit: 214.29 EUR/day
- Margin: 30.00%

Monthly:
- Cost: 9,166.67 EUR
- Revenue: 13,095.24 EUR
- Profit: 3,928.57 EUR

Annual:
- Cost: 110,000 EUR
- Revenue: 157,142.86 EUR
- Profit: 47,142.86 EUR
```

### Example 2: Hourly to Daily
```
Input:
- Cost: 100 EUR/hour
- Margin: 25%

Normalized:
- Daily Cost: 800 EUR (100 × 8)

Output:
- Revenue: 1,066.67 EUR/day
- Profit: 266.67 EUR/day
- Margin: 25.00%
```

---

**Testing Complete When All Scenarios Pass** ✅

**Report Issues To:** Development Team  
**Last Updated:** 2026-01-09

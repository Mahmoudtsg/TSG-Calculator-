# Testing Guide - TSG Salary Calculator v1.1.6

## 🎯 Key Features to Test

### 1. **Target Margin % - TRUE Profit Margin (Not Markup)**

#### Formula Verification
```
Given:
- Daily Cost Rate = 500 EUR
- Target Margin % = 30%

TRUE Profit Margin Calculation:
- target_margin = 30 / 100 = 0.30
- daily_placement_rate = 500 / (1 - 0.30) = 500 / 0.70 = 714.29 EUR
- daily_profit = 714.29 - 500 = 214.29 EUR
- displayed_margin = (214.29 / 714.29) × 100 = 30.00%

OLD Markup Calculation (INCORRECT):
- daily_placement_rate = 500 × (1 + 0.30) = 650 EUR
- daily_profit = 650 - 500 = 150 EUR
- margin = (150 / 650) × 100 = 23.08% ❌ NOT 30%
```

### 2. **Occupation Rate - Scales Salary Only**

#### Key Rules
- ✅ Occupation Rate scales: Salary, Employee Cost, Employer Cost
- ❌ Occupation Rate DOES NOT scale: Working Days (always 220)
- ✅ Daily Cost Rate = Annual Total Cost ÷ 220 (not ÷ effective days)

#### Test Case
```
Full-time Salary: 10,000 RON
Occupation Rate: 80%

Expected Results:
- Adjusted Salary = 10,000 × 0.80 = 8,000 RON ✅
- Working Days = 220 (NOT 176) ✅
- Annual Cost = [Monthly Cost for 8,000] × 12
- Daily Cost = Annual Cost ÷ 220 ✅
```

### 3. **Currency Conversion - Always Via RON**

#### Conversion Rules
```
Always convert through RON base:
1. Input → RON: valueRON = valueInput × RON_per_input
2. RON → Target: valueTarget = valueRON / RON_per_target

Example: Romania (RON) → Switzerland (CHF)
- Given: 1,000 RON; 1 EUR = 4.97 RON; 1 EUR = 0.93 CHF
- RON per RON = 1 (no conversion needed)
- RON per CHF = 4.97 / 0.93 = 5.344
- valueCHF = 1,000 / 5.344 = 187.12 CHF ✅

WRONG Approach (do NOT multiply when converting FROM RON):
- 1,000 RON × 4.97 = 4,970 CHF ❌
```

---

## 🧪 Test Scenarios

### Test 1: Employee Mode - Occupation Rate
**Country:** Romania  
**Mode:** Gross  
**Gross Salary:** 15,000 RON  
**Occupation Rate:** 100%

**Expected Results:**
- Net Salary: ~9,000 RON (after 25% CAS, 10% CASS, 10% tax)
- Total Cost: ~16,543 RON (including 2.25% CAM)
- Daily Cost Rate: [Annual Total Cost] ÷ 220

**Test at 80% Occupation:**
- Adjusted Salary: 15,000 × 0.80 = 12,000 RON
- Net Salary: ~7,200 RON
- Total Cost: ~13,234 RON
- Working Days: 220 (NOT 176) ✅

---

### Test 2: B2B Mode - Target Margin 30%
**Country:** Romania  
**Contractor Cost per Day:** 500 EUR  
**Working Days:** 220  
**Pricing Mode:** Target Margin %  
**Target Margin %:** 30%  
**Reference Currency:** EUR

**Expected Results:**
- Daily Cost Rate: 500 EUR
- Daily Placement Rate: 500 ÷ (1 - 0.30) = **714.29 EUR** ✅
- Daily Profit: 714.29 - 500 = **214.29 EUR**
- Displayed Margin: (214.29 ÷ 714.29) × 100 = **30%** (rounded to 0 decimals) ✅
- Monthly Profit: 214.29 × (220 ÷ 12) = **3,928.63 EUR**

**WRONG Results (Old Markup Logic):**
- Daily Placement Rate: 650 EUR ❌
- Margin: 23% ❌

---

### Test 3: Currency Conversion - Romania to CHF
**Country:** Romania  
**Mode:** Gross  
**Gross Salary:** 10,000 RON  
**Display Currency:** CHF  
**Exchange Rates:** 1 EUR = 4.97 RON; 1 EUR = 0.93 CHF

**Expected Conversion:**
- 10,000 RON → CHF
- RON per CHF = 4.97 / 0.93 = 5.344
- 10,000 ÷ 5.344 = **1,871.17 CHF** ✅

**WRONG:**
- 10,000 × 4.97 = 49,700 CHF ❌

---

### Test 4: Monthly Meal Benefits (Romania)
**Country:** Romania  
**Gross Salary:** 15,000 RON  
**Monthly Meal Benefits:** 500 RON

**Expected:**
- Meal Benefits: Non-taxable, added to employer cost
- Total Cost: Base Cost + 500 RON
- Take-Home: Net Salary + 500 RON

---

### Test 5: Help Icons (?)
**Visual Check:**
- ✅ All calculation tooltips should show **?** icons (not !)
- ✅ Total of 22 help icons across Employee and B2B modes

**Tooltip Examples:**
- "Calculated as: Annual Total Cost ÷ 220 working days"
- "Calculated as: Daily Cost ÷ (1 - 30%)"
- "Profit = Placement Rate - Cost"

---

### Test 6: Exchange Rate Auto-Update
**Test Flow:**
1. Open calculator → Rates fetched from API
2. Check localStorage → Rates cached for 24h
3. Refresh page within 24h → Uses cached rates
4. Click refresh button (🔄) → Forces fresh API call
5. After 24h → Auto-fetches new rates

**Expected:**
- First load: "Fetching exchange rates..."
- Cached: "Using cached rates (updated: [timestamp])"
- Manual refresh: "Exchange rate updated"

---

### Test 7: B2B Display Currency Position
**Visual Check:**
- Display Currency dropdown should appear **AFTER** Client Daily Rate input
- Business Outputs should be **hidden** when Contractor Currency = Client Currency

---

## ✅ Success Criteria

### Calculation Accuracy
- [ ] Target Margin 30% → Daily Placement Rate = Cost ÷ 0.70 ✅
- [ ] Displayed Margin = 30% (rounded to 0 decimals) ✅
- [ ] Occupation 80% → Salary scaled, Working Days = 220 ✅
- [ ] RON → CHF conversion via EUR intermediary ✅

### UI/UX
- [ ] 22 help icons (?) visible with tooltips ✅
- [ ] Display Currency positioned after Client Daily Rate ✅
- [ ] Business Outputs hidden when currencies match ✅
- [ ] Meal Benefits labeled correctly (Romania) ✅

### Performance
- [ ] Page loads in <10 seconds
- [ ] Exchange rates cached for 24h
- [ ] Manual refresh button works
- [ ] 0 console errors

---

## 🐛 Known Issues (Should Be Fixed)

### ❌ RESOLVED Issues
1. ~~Occupation rate changed working days to 176~~ → Fixed: Always 220
2. ~~Target Margin used markup formula~~ → Fixed: TRUE profit margin
3. ~~RON → CHF multiplied incorrectly~~ → Fixed: Divide via EUR
4. ~~Info icons showed (!)~~ → Fixed: Changed to (?)
5. ~~Display Currency before Client Rate~~ → Fixed: Moved after

---

## 📊 Test Results Template

```
Date: ___________
Tester: __________

| Test Case | Expected | Actual | Status |
|-----------|----------|--------|--------|
| Target Margin 30% | 714.29 EUR | _____ | ⬜ Pass ⬜ Fail |
| Occupation 80% | 12,000 RON | _____ | ⬜ Pass ⬜ Fail |
| RON → CHF (10,000) | 1,871.17 CHF | _____ | ⬜ Pass ⬜ Fail |
| Help Icons Count | 22 | _____ | ⬜ Pass ⬜ Fail |
| Exchange Rate | Auto-cached 24h | _____ | ⬜ Pass ⬜ Fail |

Overall Status: ⬜ PASS ⬜ FAIL
Notes: _________________________________
```

---

## 🚀 Quick Test Commands

### Browser Console Tests
```javascript
// Test 1: Verify Target Margin Calculation
const dailyCost = 500;
const targetMargin = 0.30;
const placementRate = dailyCost / (1 - targetMargin);
console.log('Placement Rate:', placementRate); // Should be 714.29
console.log('Profit:', placementRate - dailyCost); // Should be 214.29
console.log('Margin %:', ((placementRate - dailyCost) / placementRate * 100).toFixed(0)); // Should be 30

// Test 2: Verify Occupation Rate
const fullTimeSalary = 10000;
const occupationRate = 0.80;
const adjustedSalary = fullTimeSalary * occupationRate;
console.log('Adjusted Salary:', adjustedSalary); // Should be 8000
console.log('Working Days:', 220); // MUST be 220, not 176

// Test 3: Verify Currency Conversion
const ronAmount = 10000;
const ronPerEur = 4.97;
const chfPerEur = 0.93;
const ronPerChf = ronPerEur / chfPerEur;
const chfAmount = ronAmount / ronPerChf;
console.log('CHF Amount:', chfAmount.toFixed(2)); // Should be 1871.17
```

---

## 📝 Version History

### v1.1.6 (Current)
- ✅ Fixed Target Margin to TRUE profit margin
- ✅ Fixed Occupation Rate (scales salary, not days)
- ✅ Fixed Currency Conversion (always via RON)
- ✅ Changed info icons (!) to help icons (?)
- ✅ Moved Display Currency after Client Daily Rate
- ✅ Meal Benefits non-taxable (Romania)

### v1.1.5
- Occupation rate with effective working days (REVERTED)

### v1.1.4
- Employee/B2B modes with parity

---

**Status:** ✅ Ready for Production Testing  
**Last Updated:** 2025-12-19  
**Version:** 1.1.6 (Final)

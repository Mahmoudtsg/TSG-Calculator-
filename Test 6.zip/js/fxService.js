/**
 * FX Service - Currency Exchange Rate Management
 * Handles fetching and caching exchange rates with localStorage
 */

const FXService = {
    // Exchange rate API endpoint (free, no auth required, CORS-enabled)
    API_URL: 'https://api.exchangerate-api.com/v4/latest/EUR',
    CACHE_KEY: 'tsg_fx_rates',
    CACHE_DURATION: 24 * 60 * 60 * 1000, // 24 hours in milliseconds
    
    /**
     * Get exchange rates from cache or API
     * @returns {Promise<Object>} Exchange rates object
     */
    async getRates() {
        try {
            // Check cache first
            const cached = this.getCachedRates();
            if (cached) {
                console.log('Using cached exchange rates');
                return cached;
            }
            
            // Fetch fresh rates
            console.log('Fetching fresh exchange rates...');
            const response = await fetch(this.API_URL);
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const data = await response.json();
            
            // Store in cache
            this.cacheRates(data);
            
            return data;
        } catch (error) {
            console.error('Error fetching exchange rates:', error);
            
            // Try to use cached data even if expired
            const cached = this.getCachedRates(true);
            if (cached) {
                console.warn('Using expired cached rates due to API error');
                return cached;
            }
            
            // Fallback to default rates
            console.warn('Using fallback exchange rates');
            return this.getFallbackRates();
        }
    },
    
    /**
     * Get cached rates from localStorage
     * @param {boolean} ignoreExpiry - Return cached data even if expired
     * @returns {Object|null} Cached rates or null
     */
    getCachedRates(ignoreExpiry = false) {
        try {
            const cached = localStorage.getItem(this.CACHE_KEY);
            if (!cached) return null;
            
            const data = JSON.parse(cached);
            const now = Date.now();
            const age = now - data.timestamp;
            
            if (!ignoreExpiry && age > this.CACHE_DURATION) {
                console.log('Cached rates expired');
                return null;
            }
            
            return data.rates;
        } catch (error) {
            console.error('Error reading cached rates:', error);
            return null;
        }
    },
    
    /**
     * Cache exchange rates in localStorage
     * @param {Object} ratesData - Exchange rates data from API
     */
    cacheRates(ratesData) {
        try {
            const cacheData = {
                rates: ratesData,
                timestamp: Date.now()
            };
            localStorage.setItem(this.CACHE_KEY, JSON.stringify(cacheData));
            console.log('Exchange rates cached successfully');
        } catch (error) {
            console.error('Error caching rates:', error);
        }
    },
    
    /**
     * Get fallback rates (hardcoded as last resort)
     * @returns {Object} Fallback exchange rates
     */
    getFallbackRates() {
        const fallbackDate = new Date().toISOString().split('T')[0];
        return {
            base: 'EUR',
            date: fallbackDate,
            rates: {
                EUR: 1,
                CHF: 0.93,
                RON: 4.97,
                USD: 1.09,
                GBP: 0.85
            }
        };
    },
    
    /**
     * Convert amount from one currency to EUR
     * @param {number} amount - Amount to convert
     * @param {string} fromCurrency - Source currency code (CHF, RON, EUR)
     * @returns {Promise<number>} Converted amount in EUR
     */
    async convertToEUR(amount, fromCurrency) {
        if (fromCurrency === 'EUR') {
            return amount;
        }
        
        try {
            const ratesData = await this.getRates();
            const rate = ratesData.rates[fromCurrency];
            
            if (!rate) {
                throw new Error(`Rate not found for ${fromCurrency}`);
            }
            
            // Convert: amount in currency -> EUR
            // EUR is base, so we divide by the rate
            return amount / rate;
        } catch (error) {
            console.error('Conversion error:', error);
            throw error;
        }
    },
    
    /**
     * Convert amount from EUR to another currency
     * @param {number} amountEUR - Amount in EUR
     * @param {string} toCurrency - Target currency code
     * @returns {Promise<number>} Converted amount
     */
    async convertFromEUR(amountEUR, toCurrency) {
        if (toCurrency === 'EUR') {
            return amountEUR;
        }
        
        try {
            const ratesData = await this.getRates();
            const rate = ratesData.rates[toCurrency];
            
            if (!rate) {
                throw new Error(`Rate not found for ${toCurrency}`);
            }
            
            // Convert: EUR -> target currency
            return amountEUR * rate;
        } catch (error) {
            console.error('Conversion error:', error);
            throw error;
        }
    },
    
    /**
     * Get current rate information for display
     * @param {string} currency - Currency code
     * @returns {Promise<Object>} Rate info object {rate, date, base}
     */
    async getRateInfo(currency) {
        try {
            const ratesData = await this.getRates();
            const rate = ratesData.rates[currency];
            
            // Validate rate is a valid number
            if (rate === null || rate === undefined || isNaN(rate)) {
                throw new Error(`Invalid rate for ${currency}`);
            }
            
            return {
                rate: parseFloat(rate),
                date: ratesData.date || new Date().toISOString().split('T')[0],
                base: ratesData.base || 'EUR',
                currency: currency
            };
        } catch (error) {
            console.error('Error getting rate info:', error);
            
            // Return fallback rate based on currency
            const fallbackRates = {
                'CHF': 0.93,
                'RON': 4.97,
                'EUR': 1.0
            };
            
            return {
                rate: fallbackRates[currency] || 1.0,
                date: new Date().toISOString().split('T')[0],
                base: 'EUR',
                currency: currency,
                fallback: true
            };
        }
    },
    
    /**
     * Clear cached rates (useful for testing or forcing refresh)
     */
    clearCache() {
        try {
            localStorage.removeItem(this.CACHE_KEY);
            console.log('Exchange rate cache cleared');
        } catch (error) {
            console.error('Error clearing cache:', error);
        }
    },
    
    /**
     * Format currency amount with proper symbol and decimals
     * @param {number} amount - Amount to format
     * @param {string} currency - Currency code
     * @returns {string} Formatted currency string
     */
    formatCurrency(amount, currency) {
        // Validate amount
        if (amount === null || amount === undefined || isNaN(amount)) {
            return '0.00';
        }
        
        const symbols = {
            EUR: '€',
            CHF: 'CHF',
            RON: 'RON'
        };
        
        const formatted = amount.toLocaleString('en-US', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
        
        const symbol = symbols[currency] || currency;
        
        if (currency === 'EUR') {
            return `${symbol}${formatted}`;
        } else {
            return `${formatted} ${symbol}`;
        }
    }
};

// Make FXService available globally
window.FXService = FXService;

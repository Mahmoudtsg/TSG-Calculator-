/**
 * Main Calculator Engine
 * Coordinates between different country rules and calculation modes
 */

const Calculator = {
    // Reference to current country rules
    currentRules: null,
    currentCountry: 'CH',
    currentCurrency: 'CHF',
    
    // Average working days per year
    WORKING_DAYS_PER_YEAR: 220,
    
    /**
     * Initialize calculator with a country
     */
    init(countryCode) {
        this.currentCountry = countryCode;
        
        switch(countryCode) {
            case 'CH':
                this.currentRules = SwitzerlandRules;
                this.currentCurrency = 'CHF';
                break;
            case 'RO':
                this.currentRules = RomaniaRules;
                this.currentCurrency = 'RON';
                break;
            case 'ES':
                this.currentRules = SpainRules;
                this.currentCurrency = 'EUR';
                break;
            default:
                throw new Error(`Unknown country code: ${countryCode}`);
        }
        
        return this;
    },
    
    /**
     * Main calculation method
     * 
     * ===== EMPLOYEE-ONLY CALCULATOR =====
     * This calculator is designed ONLY for Employee (Payroll) mode calculations.
     * It handles gross/net salary calculations with tax rules for CH/RO/ES.
     * 
     * For B2B (Contractor) calculations, use direct business logic in UI layer.
     * 
     * @param {Object} params - Calculation parameters
     * @returns {Object} Complete calculation results
     */
    calculate(params) {
        const {
            mode,                    // 'net', 'gross', or 'total'
            amount,
            otherBenefits = 0,
            baseFunction = false,
            dependents = 0,
            taxExemption = false,
            lppRate = 0.07,          // Switzerland specific
            lppPlanMode = 'mandatory', // Switzerland specific: 'mandatory' or 'super'
            lfpRate = 0.0005,        // Switzerland specific
            laaNonProfRate = 0.015,  // Switzerland specific (LAA non-professional)
            displayInEUR = false,
            isB2B = false            // Defensive flag to prevent misuse
        } = params;
        
        // ===== DEFENSIVE CHECK: Prevent B2B misuse =====
        // B2B calculations should NOT use this method
        // B2B has no payroll taxes - use direct business formulas instead
        if (isB2B) {
            throw new Error('Calculator.calculate must not be used for B2B mode. B2B calculations are handled separately in the UI layer.');
        }
        
        // Validate
        if (!amount || amount <= 0) {
            throw new Error('Amount must be greater than zero');
        }
        
        if (!this.currentRules) {
            throw new Error('Calculator not initialized. Call init() first.');
        }
        
        // Build input object
        const input = {
            otherBenefits,
            baseFunction,
            dependents: parseInt(dependents),
            taxExemption,
            lppRate,
            lppPlanMode,
            lfpRate,
            laaNonProfRate
        };
        
        // Calculate based on mode
        let results;
        
        switch(mode) {
            case 'gross':
                input.grossSalary = amount;
                results = this.currentRules.calculateFromGross(input);
                break;
                
            case 'net':
                results = this.currentRules.calculateGrossFromNet(amount, input);
                break;
                
            case 'total':
                results = this.currentRules.calculateGrossFromTotal(amount, input);
                break;
                
            default:
                throw new Error(`Invalid calculation mode: ${mode}`);
        }
        
        // Add metadata
        results.country = this.currentCountry;
        results.currency = this.currentCurrency;
        results.mode = mode;
        results.inputAmount = amount;
        
        // Calculate annual values
        results.annual = {
            grossSalary: this.round(results.grossSalary * 12),
            netSalary: this.round(results.netSalary * 12),
            totalCost: this.round(results.totalCost * 12),
            employeeContributions: this.round(results.employeeContributions.total * 12),
            employerContributions: this.round(results.employerContributions.total * 12),
            incomeTax: this.round(results.incomeTax * 12)
        };
        
        // If display in EUR is requested and currency is not EUR
        if (displayInEUR && this.currentCurrency !== 'EUR') {
            results.displayCurrency = 'EUR';
            results.conversionPending = true; // Will be converted by UI layer
        } else {
            results.displayCurrency = this.currentCurrency;
            results.conversionPending = false;
        }
        
        return results;
    },
    
    /**
     * Calculate business metrics (staffing margins)
     * @param {Object} results - Payroll calculation results
     * @param {Object} businessParams - Business parameters
     * @returns {Object} Business metrics
     */
    calculateBusinessMetrics(results, businessParams) {
        const {
            clientRevenue,           // In EUR
            billingPeriod = 'monthly', // 'monthly' or 'annual'
            marginType = 'margin',   // 'margin' or 'markup'
            marginValue = 0,         // Percentage
            occupationRate = 1       // Decimal (e.g., 0.8 for 80%)
        } = businessParams;
        
        // Use cost in original currency (will be converted in UI)
        const monthlyCostOriginal = results.totalCost;
        
        // Calculate effective working days based on occupation rate
        const effectiveWorkingDays = this.WORKING_DAYS_PER_YEAR * occupationRate;
        
        // Calculate daily cost in original currency
        const dailyCostOriginal = monthlyCostOriginal * 12 / effectiveWorkingDays;
        
        // Calculate daily sell rate based on margin
        // Formula: Daily Sell Rate = Daily Cost + (Daily Cost × Margin%)
        let dailySellRateOriginal = 0;
        let dailyProfitOriginal = 0;
        
        if (marginValue > 0) {
            if (marginType === 'margin') {
                // Daily Sell Rate = Daily Cost × (1 + Margin/100)
                // This means: if margin is 30%, sell rate = cost × 1.30
                dailyProfitOriginal = dailyCostOriginal * (marginValue / 100);
                dailySellRateOriginal = dailyCostOriginal + dailyProfitOriginal;
            } else {
                // Markup calculation (same as margin in this context)
                dailyProfitOriginal = dailyCostOriginal * (marginValue / 100);
                dailySellRateOriginal = dailyCostOriginal + dailyProfitOriginal;
            }
        }
        
        // Convert client revenue to monthly if annual
        const monthlyRevenueEUR = billingPeriod === 'annual' 
            ? clientRevenue / 12 
            : clientRevenue;
        
        // Calculate daily rate from revenue
        const dailyRevenueEUR = monthlyRevenueEUR * 12 / effectiveWorkingDays;
        
        // Calculate actual margin from client revenue (if provided)
        let actualMarginPercent = 0;
        let dailyGrossMarginEUR = 0;
        
        if (clientRevenue > 0) {
            // This will be calculated after conversion in UI
            dailyGrossMarginEUR = dailyRevenueEUR - dailyCostOriginal; // Placeholder
            actualMarginPercent = dailyRevenueEUR > 0 
                ? (dailyGrossMarginEUR / dailyRevenueEUR) * 100 
                : 0;
        }
        
        // Monthly values from daily
        const monthlySellRateOriginal = dailySellRateOriginal * effectiveWorkingDays / 12;
        const monthlyProfitOriginal = dailyProfitOriginal * effectiveWorkingDays / 12;
        
        return {
            // Daily values in original currency
            dailyCost: this.round(dailyCostOriginal),
            dailySellRate: this.round(dailySellRateOriginal),
            dailyProfit: this.round(dailyProfitOriginal),
            
            // Monthly values in original currency
            monthlyCost: this.round(monthlyCostOriginal),
            monthlySellRate: this.round(monthlySellRateOriginal),
            monthlyProfit: this.round(monthlyProfitOriginal),
            
            // Client revenue analysis (if provided)
            dailyRevenueEUR: this.round(dailyRevenueEUR),
            monthlyRevenueEUR: this.round(monthlyRevenueEUR),
            dailyGrossMarginEUR: this.round(dailyGrossMarginEUR),
            actualMarginPercent: this.round(actualMarginPercent),
            
            // Margin percentage used
            marginPercent: marginValue,
            marginType: marginType,
            
            // Currency
            currency: results.currency,
            workingDaysPerYear: effectiveWorkingDays,
            occupationRate: occupationRate
        };
    },
    
    /**
     * Convert result values to EUR
     * @param {Object} results - Calculation results
     * @param {number} exchangeRate - Exchange rate to EUR
     * @returns {Object} Results with EUR values
     */
    convertToEUR(results, exchangeRate) {
        const converted = { ...results };
        
        const fieldsToConvert = [
            'grossSalary', 'netSalary', 'totalCost', 'takeHome',
            'incomeTax', 'personalDeduction', 'taxableBase', 'otherBenefits'
        ];
        
        // Convert main fields
        fieldsToConvert.forEach(field => {
            if (results[field] !== undefined) {
                converted[field + 'EUR'] = this.round(results[field] / exchangeRate);
            }
        });
        
        // Convert employee contributions
        if (results.employeeContributions) {
            converted.employeeContributionsEUR = {};
            for (const [key, value] of Object.entries(results.employeeContributions)) {
                converted.employeeContributionsEUR[key] = this.round(value / exchangeRate);
            }
        }
        
        // Convert employer contributions
        if (results.employerContributions) {
            converted.employerContributionsEUR = {};
            for (const [key, value] of Object.entries(results.employerContributions)) {
                converted.employerContributionsEUR[key] = this.round(value / exchangeRate);
            }
        }
        
        // Convert annual values
        if (results.annual) {
            converted.annualEUR = {};
            for (const [key, value] of Object.entries(results.annual)) {
                converted.annualEUR[key] = this.round(value / exchangeRate);
            }
        }
        
        converted.exchangeRate = exchangeRate;
        converted.originalCurrency = results.currency;
        converted.displayCurrency = 'EUR';
        
        return converted;
    },
    
    /**
     * Get breakdown table data from results
     */
    getBreakdown(results) {
        if (!this.currentRules || !this.currentRules.getBreakdownData) {
            return [];
        }
        
        return this.currentRules.getBreakdownData(results);
    },
    
    /**
     * Round to 2 decimal places
     */
    round(value) {
        return Math.round(value * 100) / 100;
    },
    
    /**
     * Format currency for display
     */
    formatCurrency(value, currency = null) {
        const curr = currency || this.currentCurrency;
        return FXService.formatCurrency(value, curr);
    },
    
    /**
     * Validate input parameters
     */
    validateInput(params) {
        const errors = [];
        
        if (!params.amount || params.amount <= 0) {
            errors.push('Amount must be greater than zero');
        }
        
        if (!['net', 'gross', 'total'].includes(params.mode)) {
            errors.push('Invalid calculation mode');
        }
        
        if (params.dependents < 0 || params.dependents > 10) {
            errors.push('Invalid number of dependents');
        }
        
        if (params.lppRate && (params.lppRate < 0 || params.lppRate > 0.25)) {
            errors.push('LPP rate must be between 0% and 25%');
        }
        
        if (params.lfpRate && (params.lfpRate < 0.0003 || params.lfpRate > 0.0008)) {
            errors.push('LFP rate must be between 0.03% and 0.08%');
        }
        
        return {
            valid: errors.length === 0,
            errors
        };
    }
};

// Make Calculator available globally
window.Calculator = Calculator;

# Switzerland 2026 BVG Quick Reference

## What Changed?

### 2026 Constants
| Constant | Old (2025) | New (2026) | Change |
|----------|------------|------------|--------|
| LPP_MIN_SALARY | 22,050 CHF | 22,680 CHF | +630 |
| LPP_COORDINATION | 25,725 CHF | 26,460 CHF | +735 |
| LPP_MAX_SALARY | N/A | 90,720 CHF | NEW |

### New Feature: Pension Plan Mode

**Location:** Advanced Options → Switzerland section

**Options:**
1. **BVG Mandatory (capped)** [DEFAULT]
   - Insured salary capped at 90,720 CHF/year
   - Standard for most employees
   
2. **Super-obligatory (uncapped)**
   - No salary cap applied
   - For executive/high-earner pension plans

---

## Calculation Examples

### Example: CHF 15,000/month (180,000/year)

#### Mandatory Mode (Default)
```
Yearly Gross:        180,000 CHF
Capped Yearly:        90,720 CHF (min of 180k and 90,720)
Coordination:        -26,460 CHF
Insured Yearly:       64,260 CHF
Insured Monthly:       5,355 CHF (64,260 / 12)
LPP @ 7%:               374.85 CHF/month
```

#### Super-obligatory Mode
```
Yearly Gross:        180,000 CHF
Coordination:        -26,460 CHF
Insured Yearly:      153,540 CHF (no cap!)
Insured Monthly:      12,795 CHF (153,540 / 12)
LPP @ 7%:               895.65 CHF/month
```

**Difference:** 520.80 CHF/month more with super-obligatory

---

## Modified Files

1. **js/rules/switzerland.js**
   - Updated constants
   - Added conditional capping logic
   - Enhanced display with insured base

2. **index.html**
   - Added pension plan mode radio buttons

3. **js/ui.js**
   - Extract and pass lppPlanMode parameter

4. **js/calculator.js**
   - Include lppPlanMode in input object

---

## Testing

See **test-lpp-2026.html** for automated test cases.

Run in browser to verify:
- Mandatory mode caps correctly
- Super-obligatory mode removes cap
- Both modes show correct insured base

---

## Quick Verification

✅ Switzerland constants show 2026 values  
✅ Pension plan toggle visible in UI  
✅ Insured base shown in LPP breakdown  
✅ Mode indicator in formula  
✅ High salary (>90,720) shows different amounts for each mode  
✅ Spain/Romania unchanged  
✅ B2B mode unaffected

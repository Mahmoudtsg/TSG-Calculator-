# Using Your Excel File - Complete Guide

**Your File**: IT_Salaries_Switzerland_2025.xlsx  
**Status**: ✅ Downloaded and ready to convert

---

## 🚀 Quick Start (3 Methods)

### Method 1: Use Python Script (Recommended - Fully Automated)

**Prerequisites**: Python 3.x and pandas library

```bash
# Install pandas if you don't have it
pip install pandas openpyxl

# Run the converter
python scripts/convert_excel_to_js.py
```

**That's it!** The script will:
1. Read your Excel file
2. Auto-detect columns (Role, Min, Median, Max, etc.)
3. Convert to JavaScript format
4. Save to `js/swissSalaryData.js`
5. The data is already linked in `index.html`
6. Refresh your browser and it works!

---

### Method 2: Manual Conversion (If you can't run Python)

1. **Open your Excel file in Excel or Google Sheets**

2. **Export to CSV**:
   - File → Save As → CSV

3. **Convert CSV to JSON**:
   - Go to: https://csvjson.com/csv2json
   - Paste your CSV
   - Click Convert
   - Copy the JSON output

4. **Format for JavaScript**:
   - Open `js/swissSalaryData.js`
   - Find the `salaryData:` array
   - Replace with your data in this format:

```javascript
salaryData: [
    { role: 'Software Engineer', min: 85000, median: 105000, max: 145000, experience: 'Mid', source: '2025' },
    { role: 'Data Scientist', min: 95000, median: 120000, max: 160000, experience: 'Mid', source: '2025' },
    // ... all your rows
]
```

5. **Save and refresh browser**

---

### Method 3: Use the Pre-Populated Sample Data

**Already done!** I've included comprehensive sample data with 40+ common IT roles in Switzerland:
- Software Engineers (Junior, Mid, Senior)
- Data Scientists & Analysts
- Machine Learning Engineers
- DevOps Engineers
- Frontend/Backend/Full Stack Developers
- Product & Project Managers
- And many more...

The sample data uses 2025 market estimates for Swiss IT salaries. If this works for you, **no action needed** - it's ready to use!

---

## 📊 Excel File Requirements

### Expected Column Names (Case-Insensitive)

The Python script auto-detects these column names:

| Column Type | Possible Names |
|-------------|----------------|
| **Role** | "Role", "Job Title", "Position", "Title", "Job" |
| **Min Salary** | "Min", "Minimum", "Min Salary", "Minimum Salary" |
| **Median Salary** | "Median", "Average", "Avg", "Median Salary", "Mid" |
| **Max Salary** | "Max", "Maximum", "Max Salary", "Maximum Salary" |
| **Experience** | "Experience", "Level", "Seniority", "Exp" *(optional)* |
| **Source** | "Source", "Year", "Data Source" *(optional)* |

### Example Excel Structure

| Role | Min | Median | Max | Experience | Source |
|------|-----|--------|-----|------------|--------|
| Software Engineer | 85000 | 105000 | 145000 | Mid | 2025 |
| Data Scientist | 95000 | 120000 | 160000 | Mid | 2025 |
| Senior DevOps Engineer | 115000 | 135000 | 170000 | Senior | 2025 |

---

## 🔧 Python Script Details

### What It Does

1. **Reads** your Excel file from `data/IT_Salaries_Switzerland_2025.xlsx`
2. **Auto-detects** column names (no need for exact naming)
3. **Handles** missing data (estimates if needed)
4. **Converts** to JavaScript format
5. **Saves** to `js/swissSalaryData.js`
6. **Shows** summary and sample records

### Sample Output

```
============================================================
Excel to JavaScript Salary Data Converter
============================================================
📂 Reading Excel file: data/IT_Salaries_Switzerland_2025.xlsx
✅ Found 45 rows
📊 Columns: ['Role', 'Min', 'Median', 'Max', 'Experience']

🔍 Detected columns:
   Role: Role
   Min: Min
   Median: Median
   Max: Max
   Experience: Experience
   Source: Not found (will default to 2025)

✅ Converted 45 salary records

💾 Saved to: js/swissSalaryData.js
📝 File size: 12,345 bytes

📋 Sample records:
   1. Software Engineer: 85,000 - 105,000 - 145,000 CHF
   2. Data Scientist: 95,000 - 120,000 - 160,000 CHF
   3. DevOps Engineer: 90,000 - 110,000 - 145,000 CHF
   ... and 42 more

✅ SUCCESS! Data converted successfully.

📋 Next steps:
   1. Review the generated file: js/swissSalaryData.js
   2. The file is already linked in index.html
   3. Refresh your browser to see the data
```

---

## 🧪 Testing Your Data

After loading your data, test these scenarios:

### Test 1: Exact Match
```
1. Select Employee mode
2. Select Switzerland
3. Enter role exactly as in your Excel: "Software Engineer"
4. Calculate
5. Should show: ✓ Exact Match badge
```

### Test 2: Partial Match
```
1. If Excel has "Business Data Analyst"
2. Enter: "Data Analyst"
3. Should match and show: ≈ Similar Match badge
```

### Test 3: Abbreviation
```
1. If Excel has "Machine Learning Engineer"
2. Enter: "ML Engineer"
3. Should match and show: ✓ Exact Match badge (after expansion)
```

### Test 4: Not in Database
```
1. Enter a role not in your Excel: "Teacher"
2. Should show: "No salary benchmark data found" message
```

---

## 🎯 What Happens After Loading

Once your data is loaded, the system automatically:

1. **Replaces** the sample data with your real data
2. **Matches** user input against your roles using fuzzy matching
3. **Displays** salary ranges from your Excel
4. **Shows** where user's salary falls in your ranges
5. **Handles** abbreviations and variations
6. **Works** only for Switzerland Employee mode

---

## 📁 File Structure

```
project/
├── data/
│   └── IT_Salaries_Switzerland_2025.xlsx  ← Your Excel file (downloaded)
├── scripts/
│   └── convert_excel_to_js.py             ← Python converter script
├── js/
│   ├── salaryBenchmark.js                 ← Matching engine
│   └── swissSalaryData.js                 ← Your data (generated/manual)
└── index.html                              ← Links all files
```

---

## 🔄 Updating Data Later

When you get updated salary data:

### Option 1: Python Script
```bash
# Replace the Excel file
cp new_data.xlsx data/IT_Salaries_Switzerland_2025.xlsx

# Re-run converter
python scripts/convert_excel_to_js.py

# Refresh browser
```

### Option 2: Manual
1. Open `js/swissSalaryData.js`
2. Update the `salaryData` array
3. Save and refresh

---

## 💡 Tips for Best Results

### 1. Excel Data Quality
- ✅ Use clear, standard job titles
- ✅ Ensure min < median < max
- ✅ Use annual gross salaries in CHF
- ✅ Remove empty rows

### 2. Job Title Variations
If you want to improve matching, add common variations:
```javascript
// In js/salaryBenchmark.js, add to abbreviations:
abbreviations: {
    // ... existing
    'js': 'javascript',
    'ts': 'typescript',
    'py': 'python',
    // Add your custom ones
}
```

### 3. Experience Levels
Use consistent labels:
- "Junior" or "Jr"
- "Mid" or "Mid-level"
- "Senior" or "Sr"
- "Lead" or "Team Lead"
- "Principal"

---

## 🐛 Troubleshooting

### Issue: "pandas not found"
**Solution**: 
```bash
pip install pandas openpyxl
```

### Issue: "File not found"
**Solution**: Make sure Excel file is in `data/` folder:
```bash
ls data/IT_Salaries_Switzerland_2025.xlsx
```

### Issue: "No matches found"
**Solution**: 
- Check that data loaded (see browser console: "✅ Loaded X records")
- Try exact role name from your Excel
- Check capitalization doesn't matter

### Issue: "Data not updating"
**Solution**:
- Hard refresh browser: Ctrl+Shift+R (Windows) or Cmd+Shift+R (Mac)
- Clear browser cache
- Check browser console for errors (F12)

---

## ✅ Verification Checklist

After running the script or manual conversion:

- [ ] File `js/swissSalaryData.js` exists
- [ ] File contains your data (not sample data)
- [ ] File is linked in `index.html` (already done)
- [ ] Browser console shows: "✅ Loaded X Swiss IT salary records"
- [ ] Test exact match works
- [ ] Test partial match works
- [ ] Test abbreviation works

---

## 🎉 You're Done!

Your Excel data is now integrated into the salary benchmark system. The system will:

✅ Automatically match job titles intelligently  
✅ Handle variations and abbreviations  
✅ Display beautiful salary ranges  
✅ Show market position  
✅ Work only for Switzerland Employee mode  

**Just refresh your browser and start testing!** 🚀

---

## 📞 Need Help?

If you encounter issues:
1. Check browser console (F12) for error messages
2. Verify file paths are correct
3. Ensure Excel file has required columns
4. Test with sample data first to confirm system works
5. Then load your actual data

---

## 🔄 Current Status

✅ Your Excel file downloaded: `data/IT_Salaries_Switzerland_2025.xlsx`  
✅ Python converter script ready: `scripts/convert_excel_to_js.py`  
✅ Sample data already loaded in: `js/swissSalaryData.js`  
✅ Everything linked in: `index.html`  

**Next step**: Run the Python script or use the sample data!

# Allocation Mode - Quick Reference

## 🎯 What is Allocation Mode?

A commercial profitability calculator for scenarios where **one employee is allocated to multiple clients**.

**Key Concept:** The employer pays ONE fixed daily cost. Additional client allocations generate pure incremental profit.

---

## ⚡ Quick Start

1. Click **"Allocation"** engagement type
2. Enter salary at 100% (annual)
3. Set engagement % (e.g., 80%)
4. Add clients with allocation % and daily rates
5. Click **Calculate**

---

## 📊 Input Fields

| Field | Description | Example |
|-------|-------------|---------|
| **Salary at 100%** | Full annual salary | 160,000 CHF |
| **Engagement %** | How much of their time is allocated | 80% |
| **Employer Multiplier** | Cost factor (salary × multiplier) | 1.20 |
| **Working Days** | Business days per year | 220 |
| **Client Name** | Client identifier | Client A |
| **Allocation %** | % of time for this client | 60% |
| **Daily Rate** | Rate charged to client per day | 1,250 CHF |

---

## ✅ Validation Rules

- ✅ Sum of allocation % must be ≤ engagement %
- ✅ All fields must be positive numbers
- ✅ At least one client required

---

## 🧮 How It Calculates

### The Formula
```
1. Base Daily Cost = (Salary × Engagement% × Multiplier) / Working Days
   → This cost is PAID ONCE

2. For each client:
   Revenue/Day = Daily Rate × (Allocation% / 100)

3. Baseline Client = Client with highest revenue
   → Their profit = Revenue - Base Daily Cost

4. Other Clients = Pure incremental profit
   → Their profit = Revenue (cost already covered!)

5. Total Profit = Sum of all client profits
```

### Example Calculation
```
Inputs:
- Salary 100%: 160,000 CHF
- Engagement: 80% → Engaged salary: 128,000 CHF
- Multiplier: 1.20 → Employer cost: 153,600 CHF
- Working days: 220 → Base daily cost: 698.18 CHF

Clients:
- Client A: 60% @ 1,250/day → Revenue: 750 CHF
- Client B: 20% @ 1,250/day → Revenue: 250 CHF

Results:
- Client A (BASELINE): 750 - 698.18 = 51.82 CHF profit
- Client B (INCREMENTAL): 250 CHF profit (no cost!)
- Total profit/day: 301.82 CHF
- Annual profit: 66,400.40 CHF
```

---

## 🎨 Understanding the Results

### Summary Metrics
- **Engaged Salary**: What you pay for the engagement %
- **Employer Cost**: Total annual cost (salary × multiplier)
- **Base Daily Cost**: Cost per day (PAID ONCE)
- **Total Revenue/Day**: Sum of all client revenues
- **Total Profit/Day**: Revenue - Cost (cost paid once!)
- **Annual Profit**: Daily profit × working days

### Client Table
- **Baseline Badge**: Shows which client covers the base cost
- **Green Numbers**: Profit
- **Red Numbers**: Loss (if any)
- **Yellow Row**: Baseline client row

---

## 💡 Common Use Cases

### Scenario 1: Multi-Client Developer
Senior developer working across 2-3 clients simultaneously:
- 50% Client A @ 1,500 CHF/day
- 30% Client B @ 1,200 CHF/day
- 20% Client C @ 1,000 CHF/day

**Question:** What's my total profit?

### Scenario 2: Part-Time Allocation
Employee working 60% for one client:
- 60% Client A @ 1,000 CHF/day

**Question:** Is this profitable at this rate?

### Scenario 3: Rate Negotiation
Need to add a 3rd client at 20% allocation:
- Existing: 60% + 20% = 80%
- New: 20% @ ??? CHF/day

**Question:** What rate do I need to maintain profit margins?

---

## ⚠️ Important Notes

### This is NOT:
- ❌ Payroll allocation
- ❌ Tax calculation
- ❌ Social security distribution
- ❌ Accounting allocation

### This IS:
- ✅ Commercial profitability modeling
- ✅ Client rate analysis
- ✅ Revenue optimization
- ✅ Margin planning

---

## 🔢 Tips for Best Results

1. **Start with engagement %** - What % of time is billable?
2. **Use realistic daily rates** - What do clients actually pay?
3. **Consider all allocations** - Add all clients, even small ones
4. **Watch the validation** - Total allocation can't exceed engagement
5. **Look at annual profit** - Better perspective than daily

---

## 🚨 Common Mistakes

| ❌ Mistake | ✅ Solution |
|-----------|-----------|
| Sum of allocations > engagement % | Reduce individual allocations |
| Using monthly salary | Use **annual** salary |
| Forgetting multiplier | Include all employer costs (1.15-1.30) |
| Too many working days | Use realistic business days (220) |

---

## 📱 Keyboard Shortcuts

- **Ctrl/Cmd + Enter** - Calculate
- **Ctrl/Cmd + P** - Print

---

## 🎯 Quick Test

Try this test case to verify:

```
Salary 100%: 160,000 CHF
Engagement: 80%
Multiplier: 1.20
Working Days: 220

Client A: 60%, 1,250 CHF/day
Client B: 20%, 1,250 CHF/day

Expected Result:
Total Profit/Day: 301.82 CHF ✅
```

---

## 📞 Need Help?

- Read the detailed docs in README.md
- Check ALLOCATION_MODE_IMPLEMENTATION.md for technical details
- Contact your TSG administrator

---

**Version:** 1.2.0  
**Last Updated:** 2026-01-13

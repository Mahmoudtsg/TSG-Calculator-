/**
 * Romania Payroll Calculation Rules
 * Tax year: 2025
 * All rates and rules based on Romanian tax legislation
 */

const RomaniaRules = {
    country: 'RO',
    currency: 'RON',
    name: 'Romania',
    
    // Tax rates (2025)
    rates: {
        // Employee contributions
        CAS: 0.25,           // Social security (Contributia Asigurarilor Sociale)
        CASS: 0.10,          // Health insurance (Contributia Asigurarilor Sociale de Sanatate)
        INCOME_TAX: 0.10,    // Income tax
        
        // Employer contributions
        CAM: 0.0225,         // Work insurance (Contributia Asiguratorie pentru Munca)
        
        // Other
        PERSONAL_DEDUCTION: 510,  // Monthly personal deduction (RON)
        DEPENDENT_DEDUCTION: 110  // Per dependent (RON)
    },
    
    /**
     * Calculate from gross salary
     * @param {Object} input - Input parameters
     * @returns {Object} Calculation results
     */
    calculateFromGross(input) {
        const {
            grossSalary,
            otherBenefits = 0,
            baseFunction = false,
            dependents = 0,
            taxExemption = false
        } = input;
        
        // Validate grossSalary
        if (!grossSalary || isNaN(grossSalary) || grossSalary <= 0) {
            throw new Error('Invalid gross salary. Please enter a valid amount.');
        }
        
        const results = {
            grossSalary: this.round(grossSalary),
            otherBenefits: this.round(otherBenefits),
            employeeContributions: {},
            employerContributions: {},
            formulas: []
        };
        
        // Employee contributions
        const cas = grossSalary * this.rates.CAS;
        const cass = grossSalary * this.rates.CASS;
        const totalEmployeeContrib = cas + cass;
        
        results.employeeContributions = {
            cas: this.round(cas),
            cass: this.round(cass),
            total: this.round(totalEmployeeContrib)
        };
        
        results.formulas.push({
            category: 'Employee Contributions',
            items: [
                {
                    name: 'CAS (Social Security)',
                    base: grossSalary,
                    rate: this.rates.CAS,
                    formula: `${grossSalary.toFixed(2)} × ${(this.rates.CAS * 100).toFixed(2)}%`,
                    result: this.round(cas)
                },
                {
                    name: 'CASS (Health Insurance)',
                    base: grossSalary,
                    rate: this.rates.CASS,
                    formula: `${grossSalary.toFixed(2)} × ${(this.rates.CASS * 100).toFixed(2)}%`,
                    result: this.round(cass)
                }
            ]
        });
        
        // Taxable income calculation
        let personalDeduction = 0;
        if (baseFunction) {
            personalDeduction = this.rates.PERSONAL_DEDUCTION;
            personalDeduction += dependents * this.rates.DEPENDENT_DEDUCTION;
        }
        
        const taxableBase = Math.max(0, grossSalary - totalEmployeeContrib - personalDeduction);
        
        // Income tax
        let incomeTax = 0;
        if (!taxExemption) {
            incomeTax = taxableBase * this.rates.INCOME_TAX;
        }
        
        results.incomeTax = this.round(incomeTax);
        results.personalDeduction = this.round(personalDeduction);
        results.taxableBase = this.round(taxableBase);
        
        results.formulas.push({
            category: 'Income Tax Calculation',
            items: [
                {
                    name: 'Gross Salary',
                    formula: `${grossSalary.toFixed(2)} RON`,
                    result: this.round(grossSalary)
                },
                {
                    name: 'Total Employee Contributions',
                    formula: `CAS + CASS = ${cas.toFixed(2)} + ${cass.toFixed(2)}`,
                    result: this.round(totalEmployeeContrib)
                },
                {
                    name: 'Personal Deduction',
                    formula: baseFunction 
                        ? `${this.rates.PERSONAL_DEDUCTION} + (${dependents} × ${this.rates.DEPENDENT_DEDUCTION})` 
                        : 'Not applicable (not base function)',
                    result: this.round(personalDeduction)
                },
                {
                    name: 'Taxable Base',
                    formula: `Gross - Contributions - Deduction = ${grossSalary.toFixed(2)} - ${totalEmployeeContrib.toFixed(2)} - ${personalDeduction.toFixed(2)}`,
                    result: this.round(taxableBase)
                },
                {
                    name: 'Income Tax',
                    formula: taxExemption 
                        ? 'Exempt' 
                        : `${taxableBase.toFixed(2)} × ${(this.rates.INCOME_TAX * 100).toFixed(2)}%`,
                    result: this.round(incomeTax)
                }
            ]
        });
        
        // Net salary
        const netSalary = grossSalary - totalEmployeeContrib - incomeTax;
        results.netSalary = this.round(netSalary);
        
        // Employer contributions
        const cam = grossSalary * this.rates.CAM;
        results.employerContributions = {
            cam: this.round(cam),
            total: this.round(cam)
        };
        
        results.formulas.push({
            category: 'Employer Contributions',
            items: [
                {
                    name: 'CAM (Work Insurance)',
                    base: grossSalary,
                    rate: this.rates.CAM,
                    formula: `${grossSalary.toFixed(2)} × ${(this.rates.CAM * 100).toFixed(2)}%`,
                    result: this.round(cam)
                }
            ]
        });
        
        // Total company cost (includes meal benefits as employer cost)
        const totalCost = grossSalary + cam + otherBenefits;
        results.totalCost = this.round(totalCost);
        
        // Meal benefits are non-taxable and add value to employee
        // They are already included in otherBenefits parameter
        results.mealBenefits = this.round(otherBenefits);
        
        // Take-home calculation includes meal benefits (non-taxable)
        results.takeHome = this.round(netSalary + otherBenefits);
        
        results.formulas.push({
            category: 'Final Calculations',
            items: [
                {
                    name: 'Net Salary',
                    formula: `Gross - Employee Contributions - Income Tax = ${grossSalary.toFixed(2)} - ${totalEmployeeContrib.toFixed(2)} - ${incomeTax.toFixed(2)}`,
                    result: this.round(netSalary)
                },
                {
                    name: 'Total Company Cost',
                    formula: `Gross + Employer Contributions + Other Benefits = ${grossSalary.toFixed(2)} + ${cam.toFixed(2)} + ${otherBenefits.toFixed(2)}`,
                    result: this.round(totalCost)
                }
            ]
        });
        
        return results;
    },
    
    /**
     * Calculate gross from net salary (reverse calculation)
     * Uses iterative method (Newton-Raphson)
     */
    calculateGrossFromNet(targetNet, input, maxIterations = 50) {
        // Validate targetNet
        if (!targetNet || isNaN(targetNet) || targetNet <= 0) {
            throw new Error('Invalid target net salary. Please enter a valid amount.');
        }
        
        let grossEstimate = targetNet * 1.5; // Initial estimate
        const tolerance = 0.01; // 1 cent tolerance
        const iterations = [];
        
        // Store initial estimate
        iterations.push({
            iteration: 0,
            grossEstimate: grossEstimate,
            formula: `Initial Estimate = Target Net × 1.5 = ${targetNet.toFixed(2)} × 1.5`,
            result: this.round(grossEstimate)
        });
        
        for (let i = 0; i < maxIterations; i++) {
            const result = this.calculateFromGross({
                ...input,
                grossSalary: grossEstimate
            });
            
            const diff = result.netSalary - targetNet;
            
            // Store iteration details
            iterations.push({
                iteration: i + 1,
                grossEstimate: this.round(grossEstimate),
                calculatedNet: this.round(result.netSalary),
                targetNet: this.round(targetNet),
                difference: this.round(diff),
                employeeContrib: this.round(result.employeeContributions.total),
                incomeTax: this.round(result.incomeTax),
                formula: `Test Gross ${this.round(grossEstimate)} → Net ${this.round(result.netSalary)} (diff: ${this.round(diff)})`
            });
            
            if (Math.abs(diff) < tolerance) {
                // Add final result with detailed formulas
                const finalResult = this.calculateFromGross({
                    ...input,
                    grossSalary: grossEstimate
                });
                
                // Prepend reverse calculation explanation
                finalResult.formulas.unshift({
                    category: 'Reverse Calculation (Net → Gross)',
                    items: [
                        {
                            name: 'Target Net Salary',
                            formula: `${targetNet.toFixed(2)} RON`,
                            result: this.round(targetNet)
                        },
                        {
                            name: 'Calculation Method',
                            formula: 'Iterative Newton-Raphson method',
                            result: null
                        },
                        {
                            name: 'Initial Estimate',
                            formula: `${targetNet.toFixed(2)} × 1.5`,
                            result: this.round(targetNet * 1.5)
                        },
                        {
                            name: 'Iterations Required',
                            formula: `Converged in ${i + 1} iteration(s)`,
                            result: i + 1
                        },
                        {
                            name: 'Final Gross Salary',
                            formula: `Gross = Net ÷ 0.585 = ${targetNet.toFixed(2)} ÷ 0.585`,
                            result: this.round(grossEstimate)
                        },
                        {
                            name: 'Verification',
                            formula: `${this.round(grossEstimate)} × 0.585 = ${this.round(grossEstimate * 0.585)}`,
                            result: this.round(grossEstimate * 0.585)
                        }
                    ]
                });
                
                // Add detailed iteration breakdown
                if (iterations.length > 1) {
                    const iterationItems = [];
                    iterations.forEach((iter, idx) => {
                        if (idx === 0) {
                            iterationItems.push({
                                name: `Iteration ${iter.iteration} (Initial)`,
                                formula: iter.formula,
                                result: iter.result
                            });
                        } else {
                            iterationItems.push({
                                name: `Iteration ${iter.iteration}`,
                                formula: `Gross: ${iter.grossEstimate} → Net: ${iter.calculatedNet} (Target: ${iter.targetNet}, Diff: ${iter.difference})`,
                                result: iter.grossEstimate
                            });
                            iterationItems.push({
                                name: `  └─ Employee Contributions`,
                                formula: `CAS + CASS = ${iter.employeeContrib}`,
                                result: iter.employeeContrib
                            });
                            iterationItems.push({
                                name: `  └─ Income Tax`,
                                formula: `Tax = ${iter.incomeTax}`,
                                result: iter.incomeTax
                            });
                        }
                    });
                    
                    finalResult.formulas.push({
                        category: 'Iteration Details',
                        items: iterationItems
                    });
                }
                
                // Add mathematical explanation
                finalResult.formulas.push({
                    category: 'Mathematical Formula Explanation',
                    items: [
                        {
                            name: 'Step 1: Social Contributions',
                            formula: 'CAS (25%) + CASS (10%) = 35% of Gross',
                            result: null
                        },
                        {
                            name: 'Step 2: After Contributions',
                            formula: 'Remaining = Gross × (1 - 0.35) = Gross × 0.65',
                            result: null
                        },
                        {
                            name: 'Step 3: Income Tax',
                            formula: 'Tax = Remaining × 10% = (Gross × 0.65) × 0.10 = Gross × 0.065',
                            result: null
                        },
                        {
                            name: 'Step 4: Net Formula',
                            formula: 'Net = Gross - (0.35 × Gross) - (0.065 × Gross) = Gross × 0.585',
                            result: null
                        },
                        {
                            name: 'Step 5: Reverse Formula',
                            formula: 'Gross = Net ÷ 0.585',
                            result: null
                        },
                        {
                            name: 'Your Calculation',
                            formula: `Gross = ${targetNet.toFixed(2)} ÷ 0.585 = ${this.round(targetNet / 0.585)}`,
                            result: this.round(targetNet / 0.585)
                        },
                        {
                            name: 'Effective Tax Rate',
                            formula: 'Total deductions = 41.5% (you keep 58.5%)',
                            result: null
                        }
                    ]
                });
                
                return finalResult;
            }
            
            // Adjust estimate
            // Calculate effective tax rate
            const effectiveRate = 1 - (result.netSalary / grossEstimate);
            const adjustment = diff / (1 - effectiveRate);
            grossEstimate -= adjustment;
            
            // Ensure positive
            if (grossEstimate < 0) grossEstimate = targetNet * 1.2;
        }
        
        // Final calculation with best estimate
        return this.calculateFromGross({
            ...input,
            grossSalary: grossEstimate
        });
    },
    
    /**
     * Calculate gross from total company cost (reverse calculation)
     * Uses binary search for stability
     */
    calculateGrossFromTotal(targetTotal, input, maxIterations = 50) {
        // Validate targetTotal
        if (!targetTotal || isNaN(targetTotal) || targetTotal <= 0) {
            throw new Error('Invalid target total cost. Please enter a valid amount.');
        }
        
        let low = 0;
        let high = targetTotal;
        const tolerance = 0.01;
        const iterations = [];
        let iterationCount = 0;
        
        for (let i = 0; i < maxIterations; i++) {
            const mid = (low + high) / 2;
            const result = this.calculateFromGross({
                ...input,
                grossSalary: mid
            });
            
            const diff = result.totalCost - targetTotal;
            iterationCount = i + 1;
            
            // Store iteration
            iterations.push({
                iteration: i + 1,
                low: this.round(low),
                high: this.round(high),
                mid: this.round(mid),
                calculatedCost: this.round(result.totalCost),
                targetCost: this.round(targetTotal),
                diff: this.round(diff)
            });
            
            if (Math.abs(diff) < tolerance) {
                // Final result with detailed formulas
                const finalResult = this.calculateFromGross({
                    ...input,
                    grossSalary: mid
                });
                
                // Prepend reverse calculation explanation
                finalResult.formulas.unshift({
                    category: 'Reverse Calculation (Total Cost → Gross)',
                    items: [
                        {
                            name: 'Target Total Company Cost',
                            formula: `${targetTotal.toFixed(2)} RON`,
                            result: this.round(targetTotal)
                        },
                        {
                            name: 'Calculation Method',
                            formula: 'Binary Search Algorithm',
                            result: null
                        },
                        {
                            name: 'Iterations Required',
                            formula: `Converged in ${iterationCount} iteration(s)`,
                            result: iterationCount
                        },
                        {
                            name: 'Final Gross Salary',
                            formula: `Total Cost = Gross + CAM(2.25%) + Benefits`,
                            result: this.round(mid)
                        },
                        {
                            name: 'CAM (Employer Contribution)',
                            formula: `${this.round(mid)} × 2.25% = ${this.round(mid * 0.0225)}`,
                            result: this.round(mid * 0.0225)
                        },
                        {
                            name: 'Verification',
                            formula: `${this.round(mid)} + ${this.round(mid * 0.0225)} + ${this.round(input.otherBenefits || 0)} = ${this.round(mid + mid * 0.0225 + (input.otherBenefits || 0))}`,
                            result: this.round(mid + mid * 0.0225 + (input.otherBenefits || 0))
                        }
                    ]
                });
                
                // Add iteration details
                if (iterations.length > 0) {
                    const iterItems = [];
                    iterations.forEach(iter => {
                        iterItems.push({
                            name: `Iteration ${iter.iteration}`,
                            formula: `Range: [${iter.low}, ${iter.high}], Mid: ${iter.mid} → Cost: ${iter.calculatedCost} (Target: ${iter.targetCost}, Diff: ${iter.diff})`,
                            result: iter.mid
                        });
                    });
                    
                    finalResult.formulas.push({
                        category: 'Binary Search Iterations',
                        items: iterItems
                    });
                }
                
                // Add formula explanation
                finalResult.formulas.push({
                    category: 'Total Cost Formula Explanation',
                    items: [
                        {
                            name: 'Total Cost Composition',
                            formula: 'Total Cost = Gross Salary + Employer Contributions + Other Benefits',
                            result: null
                        },
                        {
                            name: 'Employer Contribution (CAM)',
                            formula: 'CAM = Gross × 2.25%',
                            result: null
                        },
                        {
                            name: 'Formula',
                            formula: 'Total = Gross × (1 + 0.0225) + Benefits = Gross × 1.0225 + Benefits',
                            result: null
                        },
                        {
                            name: 'Reverse Formula',
                            formula: 'Gross = (Total - Benefits) ÷ 1.0225',
                            result: null
                        },
                        {
                            name: 'Your Calculation',
                            formula: `Gross = (${targetTotal.toFixed(2)} - ${this.round(input.otherBenefits || 0)}) ÷ 1.0225 = ${this.round((targetTotal - (input.otherBenefits || 0)) / 1.0225)}`,
                            result: this.round((targetTotal - (input.otherBenefits || 0)) / 1.0225)
                        }
                    ]
                });
                
                return finalResult;
            }
            
            if (diff > 0) {
                high = mid;
            } else {
                low = mid;
            }
        }
        
        // Final calculation with best estimate
        return this.calculateFromGross({
            ...input,
            grossSalary: (low + high) / 2
        });
    },
    
    /**
     * Round to 2 decimal places (money-safe)
     */
    round(value) {
        return Math.round(value * 100) / 100;
    },
    
    /**
     * Get breakdown table data
     */
    getBreakdownData(results) {
        return [
            {
                category: 'Employee Contributions',
                items: [
                    { name: 'CAS (Social Security 25%)', amount: results.employeeContributions.cas },
                    { name: 'CASS (Health Insurance 10%)', amount: results.employeeContributions.cass }
                ],
                total: results.employeeContributions.total
            },
            {
                category: 'Income Tax',
                items: [
                    { name: 'Personal Deduction', amount: -results.personalDeduction },
                    { name: 'Taxable Base', amount: results.taxableBase },
                    { name: 'Income Tax (10%)', amount: results.incomeTax }
                ],
                total: results.incomeTax
            },
            {
                category: 'Employer Contributions',
                items: [
                    { name: 'CAM (Work Insurance 2.25%)', amount: results.employerContributions.cam }
                ],
                total: results.employerContributions.total
            }
        ];
    }
};

// Export for use in main application
window.RomaniaRules = RomaniaRules;

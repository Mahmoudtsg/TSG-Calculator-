# B2B Print Output - Hide Contractor Cost in Client Budget Mode

## Summary
Modified the print output report to hide "Contractor Cost (per Day)" from the Inputs Summary section when in B2B mode with "Client budget" pricing mode selected.

## Changes Made

### File Modified: `js/ui.js`

**Function:** `preparePrintView()` (Lines ~1714-1731)

#### Previous Behavior:
- Contractor Cost was always displayed in the print Inputs Summary for B2B mode
- Displayed for all pricing modes (Target Margin, Client Daily Rate, and Client Budget)

#### New Behavior:
- Contractor Cost is conditionally displayed based on pricing mode
- **Hidden** when pricing mode = `'budget_margin'` (Client budget)
- **Shown** when pricing mode = `'margin'` (Target Margin %) or `'rate'` (Client Daily Rate)

#### Code Changes:

**Added:**
```javascript
// Get pricing mode to conditionally show contractor cost
const pricingMode = document.getElementById('b2b-pricing-mode')?.value;

// Only show Contractor Cost if NOT in budget_margin mode
if (contractorCost && pricingMode !== 'budget_margin') {
    // Display contractor cost...
}
```

**Removed:**
- Duplicate `pricingMode` variable declaration (line ~1744)
- Original unconditional display of contractor cost

## Logic Flow

### B2B Pricing Modes and Print Display:

1. **Target Margin % Mode** (`pricingMode = 'margin'`)
   - ✅ Shows: Contractor Cost (per Day)
   - ✅ Shows: Target Margin %

2. **Client Daily Rate Mode** (`pricingMode = 'rate'`)
   - ✅ Shows: Contractor Cost (per Day)
   - ✅ Shows: Client Daily Rate

3. **Client Budget Mode** (`pricingMode = 'budget_margin'`)
   - ❌ Hides: Contractor Cost (per Day) - **NEW BEHAVIOR**
   - ✅ Shows: Client Budget per Day
   - ✅ Shows: Target Margin %

## Rationale

In Client Budget mode, the contractor cost is calculated based on the client budget and target margin. Showing the contractor cost input in the print summary would be confusing since it's actually an output/result in this pricing mode, not an input parameter.

## Mode Isolation

- ✅ Changes only affect **B2B mode**
- ✅ Employee mode remains unchanged
- ✅ Only impacts the **Print Output** (preparePrintView function)
- ✅ Does not affect screen display or PDF export

## Testing Checklist

### B2B Mode - Client Budget Pricing:
1. Switch to B2B engagement type
2. Select "Client budget" pricing mode
3. Enter Client Budget per Day
4. Enter Target Margin %
5. Calculate results
6. Click Print button
7. **Verify:** Inputs Summary does NOT show "Contractor Cost (per Day)"
8. **Verify:** Inputs Summary DOES show "Client Budget per Day" and "Target Margin %"

### B2B Mode - Target Margin % Pricing:
1. Switch to "Target Margin %" pricing mode
2. Enter Contractor Cost
3. Enter Target Margin %
4. Calculate and Print
5. **Verify:** Inputs Summary DOES show "Contractor Cost (per Day)"

### B2B Mode - Client Daily Rate Pricing:
1. Switch to "Client Daily Rate" pricing mode
2. Enter Contractor Cost
3. Enter Client Daily Rate
4. Calculate and Print
5. **Verify:** Inputs Summary DOES show "Contractor Cost (per Day)"

### Employee Mode:
1. Switch to Employee engagement type
2. Calculate and Print
3. **Verify:** No changes to Employee mode print output

## Related Files
- `js/ui.js` - Modified `preparePrintView()` function

## Date
2025-01-12

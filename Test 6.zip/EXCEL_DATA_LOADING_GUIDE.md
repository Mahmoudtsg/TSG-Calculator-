# How to Load Your Excel Salary Data - Quick Guide

## 📥 Step-by-Step Instructions

### Option 1: Replace Sample Data Directly (Easiest)

1. **Open `js/salaryBenchmark.js`**
2. **Find the `swissSalaryData` array** (around line 9)
3. **Replace the sample data** with your Excel data in this format:

```javascript
swissSalaryData: [
    { role: 'Business Data Analyst', min: 85000, median: 100000, max: 130000, experience: 'Mid', source: '2026' },
    { role: 'Machine Learning Engineer', min: 110000, median: 130000, max: 170000, experience: 'Mid', source: '2026' },
    { role: 'Product Manager', min: 100000, median: 120000, max: 160000, experience: 'Mid', source: '2026' },
    // Add all your roles here...
],
```

### Option 2: Load from External JSON File

1. **Convert your Excel to JSON**:
   - Save Excel as CSV
   - Use online tool: https://csvjson.com/csv2json
   - Or use Excel's "Export to JSON" feature

2. **Save JSON file** to your project:
   - Create folder: `data/`
   - Save as: `data/swiss_salaries.json`

3. **Load in `js/main.js`** (add this code):

```javascript
// Load Swiss salary data
fetch('data/swiss_salaries.json')
    .then(response => response.json())
    .then(data => {
        SalaryBenchmark.loadSalaryData(data);
        console.log('Swiss salary data loaded successfully!');
    })
    .catch(error => {
        console.warn('Could not load salary data:', error);
    });
```

---

## 📋 Required Excel Column Format

Your Excel should have these columns:

| Column | Type | Description | Example |
|--------|------|-------------|---------|
| **role** | Text | Job title | "Business Data Analyst" |
| **min** | Number | Minimum annual salary (CHF) | 85000 |
| **median** | Number | Median/market salary (CHF) | 100000 |
| **max** | Number | Maximum annual salary (CHF) | 130000 |
| **experience** | Text | Experience level | "Mid", "Senior", "Junior" |
| **source** | Text | Data year or source | "2026", "Glassdoor", etc. |

---

## ✅ Example Excel Data

### Sample Excel Spreadsheet

| role | min | median | max | experience | source |
|------|-----|--------|-----|------------|--------|
| Business Data Analyst | 85000 | 100000 | 130000 | Mid | 2026 |
| Machine Learning Engineer | 110000 | 130000 | 170000 | Mid | 2026 |
| Senior Software Engineer | 120000 | 140000 | 180000 | Senior | 2026 |
| Product Manager | 100000 | 120000 | 160000 | Mid | 2026 |
| DevOps Engineer | 95000 | 115000 | 150000 | Mid | 2026 |

### Converted to JSON

```json
[
  {
    "role": "Business Data Analyst",
    "min": 85000,
    "median": 100000,
    "max": 130000,
    "experience": "Mid",
    "source": "2026"
  },
  {
    "role": "Machine Learning Engineer",
    "min": 110000,
    "median": 130000,
    "max": 170000,
    "experience": "Mid",
    "source": "2026"
  }
]
```

---

## 🔧 Testing Your Data

After loading your data, test with these inputs:

1. **Test exact match**: Enter exact role from your data
2. **Test partial match**: Enter "Data Analyst" (if you have "Business Data Analyst")
3. **Test abbreviation**: Enter "ML Engineer" (if you have "Machine Learning Engineer")
4. **Test not found**: Enter a role not in your data

---

## 🎯 Matching Examples

### Your Excel Has: "Business Data Analyst"

These inputs will match:
- ✅ "Business Data Analyst" (exact)
- ✅ "Data Analyst" (partial)
- ✅ "business data analyst" (case insensitive)
- ✅ "Business Analyst" (similar)
- ✅ "BA" + "Data Analyst" (abbreviation + partial)

### Your Excel Has: "Machine Learning Engineer"

These inputs will match:
- ✅ "Machine Learning Engineer" (exact)
- ✅ "ML Engineer" (abbreviation)
- ✅ "ML Eng" (double abbreviation)
- ✅ "Machine Learning" (partial)
- ✅ "Learning Engineer" (partial)

---

## 🐛 Troubleshooting

### Issue: No matches found
**Solution**: 
- Check column names match exactly: `role`, `min`, `median`, `max`
- Ensure numbers are numbers, not text
- Verify JSON is valid (use JSONLint.com)

### Issue: Poor matches
**Solution**:
- Add more common job titles to database
- Add synonyms to `abbreviations` object in `js/salaryBenchmark.js`
- Lower threshold (currently 0.5 / 50%)

### Issue: Data not loading
**Solution**:
- Check browser console for errors
- Verify file path is correct
- Ensure JSON file is in correct format

---

## 🚀 Quick Start (3 Minutes)

1. **Export your Excel to CSV**
2. **Convert CSV to JSON** using https://csvjson.com/csv2json
3. **Copy JSON array**
4. **Paste into `js/salaryBenchmark.js`** replacing the `swissSalaryData` array
5. **Refresh page**
6. **Test with your job titles!**

---

## 📞 Need Help?

If you encounter issues:
1. Check browser console (F12) for errors
2. Verify data format matches examples above
3. Test with sample data first to confirm system works
4. Then load your actual data

---

## ✨ Tips for Best Results

### Job Titles
- Use clear, standard job titles
- Include variations (e.g., both "Software Engineer" and "Software Developer")
- Add common abbreviations to the `abbreviations` object

### Salary Ranges
- Ensure min < median < max
- Use annual gross salaries in CHF
- Include realistic ranges for Swiss market

### Experience Levels
- Use consistent labels: "Junior", "Mid", "Senior", "Lead", "Principal"
- Or use years: "2-4 years", "5-8 years", etc.

---

## 🎉 You're Ready!

Once your data is loaded, the system will automatically:
- ✅ Match user input job titles
- ✅ Handle abbreviations and variations
- ✅ Display beautiful salary ranges
- ✅ Show user's position in market
- ✅ Provide confidence indicators

**No code changes needed** - just load your data and go!

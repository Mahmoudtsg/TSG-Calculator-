/**
 * Swiss Salary Benchmark Matcher
 * Handles fuzzy matching, abbreviations, and variations in job titles
 */

const SalaryBenchmark = {
    // Sample dataset structure - will be replaced with actual Excel data
    swissSalaryData: [
        { role: 'Software Engineer', min: 90000, median: 110000, max: 150000, experience: 'Mid', source: '2026' },
        { role: 'Senior Software Engineer', min: 120000, median: 140000, max: 180000, experience: 'Senior', source: '2026' },
        { role: 'Data Analyst', min: 80000, median: 95000, max: 120000, experience: 'Mid', source: '2026' },
        { role: 'Business Data Analyst', min: 85000, median: 100000, max: 130000, experience: 'Mid', source: '2026' },
        { role: 'Data Scientist', min: 100000, median: 120000, max: 160000, experience: 'Mid', source: '2026' },
        { role: 'Machine Learning Engineer', min: 110000, median: 130000, max: 170000, experience: 'Mid', source: '2026' },
        { role: 'Product Manager', min: 100000, median: 120000, max: 160000, experience: 'Mid', source: '2026' },
        { role: 'Project Manager', min: 90000, median: 110000, max: 145000, experience: 'Mid', source: '2026' },
        { role: 'Business Analyst', min: 85000, median: 100000, max: 130000, experience: 'Mid', source: '2026' },
        { role: 'DevOps Engineer', min: 95000, median: 115000, max: 150000, experience: 'Mid', source: '2026' },
        { role: 'Frontend Developer', min: 85000, median: 100000, max: 135000, experience: 'Mid', source: '2026' },
        { role: 'Backend Developer', min: 90000, median: 110000, max: 145000, experience: 'Mid', source: '2026' },
        { role: 'Full Stack Developer', min: 95000, median: 115000, max: 150000, experience: 'Mid', source: '2026' }
    ],

    // Abbreviation and synonym mappings
    abbreviations: {
        'ml': 'machine learning',
        'ai': 'artificial intelligence',
        'ba': 'business analyst',
        'pm': 'project manager',
        'dev': 'developer',
        'eng': 'engineer',
        'mgr': 'manager',
        'sr': 'senior',
        'jr': 'junior',
        'fe': 'frontend',
        'be': 'backend',
        'fs': 'full stack',
        'qa': 'quality assurance',
        'swe': 'software engineer',
        'sde': 'software development engineer'
    },

    // Common synonyms and variations
    synonyms: {
        'programmer': 'developer',
        'coder': 'developer',
        'analyst': 'analyst',
        'specialist': 'engineer',
        'architect': 'engineer',
        'lead': 'senior',
        'principal': 'senior'
    },

    /**
     * Normalize a job title for matching
     */
    normalizeTitle(title) {
        if (!title) return '';
        
        // Convert to lowercase
        let normalized = title.toLowerCase().trim();
        
        // Replace abbreviations
        Object.keys(this.abbreviations).forEach(abbr => {
            const regex = new RegExp(`\\b${abbr}\\b`, 'gi');
            normalized = normalized.replace(regex, this.abbreviations[abbr]);
        });
        
        // Replace synonyms
        Object.keys(this.synonyms).forEach(syn => {
            const regex = new RegExp(`\\b${syn}\\b`, 'gi');
            normalized = normalized.replace(regex, this.synonyms[syn]);
        });
        
        // Remove extra spaces
        normalized = normalized.replace(/\s+/g, ' ').trim();
        
        return normalized;
    },

    /**
     * Calculate Levenshtein distance between two strings
     * Used for fuzzy matching
     */
    levenshteinDistance(str1, str2) {
        const len1 = str1.length;
        const len2 = str2.length;
        const matrix = [];

        // Initialize matrix
        for (let i = 0; i <= len1; i++) {
            matrix[i] = [i];
        }
        for (let j = 0; j <= len2; j++) {
            matrix[0][j] = j;
        }

        // Fill matrix
        for (let i = 1; i <= len1; i++) {
            for (let j = 1; j <= len2; j++) {
                const cost = str1[i - 1] === str2[j - 1] ? 0 : 1;
                matrix[i][j] = Math.min(
                    matrix[i - 1][j] + 1,     // deletion
                    matrix[i][j - 1] + 1,     // insertion
                    matrix[i - 1][j - 1] + cost // substitution
                );
            }
        }

        return matrix[len1][len2];
    },

    /**
     * Calculate similarity score (0-1) between two strings
     */
    similarityScore(str1, str2) {
        const distance = this.levenshteinDistance(str1, str2);
        const maxLength = Math.max(str1.length, str2.length);
        return 1 - (distance / maxLength);
    },

    /**
     * Check if user title contains keywords from benchmark title
     */
    containsKeywords(userTitle, benchmarkTitle) {
        const userWords = userTitle.split(' ').filter(w => w.length > 2);
        const benchmarkWords = benchmarkTitle.split(' ').filter(w => w.length > 2);
        
        let matchCount = 0;
        userWords.forEach(userWord => {
            benchmarkWords.forEach(benchmarkWord => {
                if (benchmarkWord.includes(userWord) || userWord.includes(benchmarkWord)) {
                    matchCount++;
                }
            });
        });
        
        return matchCount / Math.max(userWords.length, 1);
    },

    /**
     * Find best matching salary data for a given job title
     */
    findMatch(userInputRole) {
        if (!userInputRole || userInputRole.trim() === '') {
            return null;
        }

        const normalizedInput = this.normalizeTitle(userInputRole);
        
        // Calculate match scores for all roles
        const matches = this.swissSalaryData.map(data => {
            const normalizedRole = this.normalizeTitle(data.role);
            
            // Calculate different matching scores
            const exactMatch = normalizedInput === normalizedRole ? 1 : 0;
            const similarityScore = this.similarityScore(normalizedInput, normalizedRole);
            const keywordScore = this.containsKeywords(normalizedInput, normalizedRole);
            const containsScore = normalizedRole.includes(normalizedInput) || normalizedInput.includes(normalizedRole) ? 0.8 : 0;
            
            // Weighted final score
            const finalScore = exactMatch * 1.0 + 
                             similarityScore * 0.4 + 
                             keywordScore * 0.3 + 
                             containsScore * 0.3;
            
            return {
                ...data,
                score: finalScore,
                normalizedRole: normalizedRole
            };
        });

        // Sort by score (highest first)
        matches.sort((a, b) => b.score - a.score);
        
        // Return best match if score is above threshold
        const bestMatch = matches[0];
        const threshold = 0.5; // Minimum score to consider a match
        
        if (bestMatch.score >= threshold) {
            return {
                ...bestMatch,
                confidence: bestMatch.score >= 0.9 ? 'high' : 
                          bestMatch.score >= 0.7 ? 'medium' : 'low',
                matchType: bestMatch.score >= 0.95 ? 'exact' : 
                          bestMatch.score >= 0.7 ? 'similar' : 'fuzzy'
            };
        }
        
        // No good match found
        return null;
    },

    /**
     * Get salary benchmark display text
     */
    getBenchmarkText(userInputRole, userSalary) {
        const match = this.findMatch(userInputRole);
        
        if (!match) {
            return {
                found: false,
                message: `No salary benchmark data found for "${userInputRole}" in Switzerland. The role may not be in our database.`,
                suggestion: 'Try using a more common job title (e.g., "Software Engineer", "Data Analyst", "Project Manager")'
            };
        }

        // Calculate where user salary falls in the range
        const position = match.min && match.max ? 
            ((userSalary - match.min) / (match.max - match.min) * 100).toFixed(0) : null;
        
        let comparisonText = '';
        if (userSalary && position) {
            if (userSalary < match.min) {
                comparisonText = `Your salary is below the market minimum (${position}% of range).`;
            } else if (userSalary > match.max) {
                comparisonText = `Your salary is above the market maximum (${position}% of range).`;
            } else if (userSalary >= match.min && userSalary <= match.median) {
                comparisonText = `Your salary is in the lower half of the market range (${position}% of range).`;
            } else {
                comparisonText = `Your salary is in the upper half of the market range (${position}% of range).`;
            }
        }

        return {
            found: true,
            matchedRole: match.role,
            userRole: userInputRole,
            confidence: match.confidence,
            matchType: match.matchType,
            data: {
                min: match.min,
                median: match.median,
                max: match.max,
                experience: match.experience,
                source: match.source
            },
            comparison: comparisonText,
            message: match.matchType === 'fuzzy' ? 
                `Note: "${userInputRole}" matched with "${match.role}" (${match.confidence} confidence)` : null
        };
    },

    /**
     * Format currency for display
     */
    formatCurrency(amount) {
        return `${amount.toLocaleString('en-US')} CHF`;
    },

    /**
     * Load salary data from external source (CSV, JSON, or Excel conversion)
     */
    async loadSalaryData(data) {
        // This will be used to load actual Excel data
        // Expected format: Array of { role, min, median, max, experience, source }
        if (Array.isArray(data) && data.length > 0) {
            this.swissSalaryData = data;
            console.log(`Loaded ${data.length} salary benchmarks`);
            return true;
        }
        return false;
    }
};

// Make available globally
window.SalaryBenchmark = SalaryBenchmark;

# Geneva 2026 Payroll Corrections - Implementation Summary

**Date:** 2026-01-12  
**Status:** ✅ COMPLETED  
**Modified Files:** 3 files (switzerland.js, ui.js, calculator.js, index.html)

---

## Overview

Fixed critical inaccuracies in Switzerland (Geneva) payroll calculations for 2026, focusing on ALV/AC (unemployment insurance), AMat (maternity insurance), and LAA non-professional rates. All changes maintain minimal impact on code structure and preserve functionality for other countries (Spain, Romania) and B2B mode.

---

## Critical Fixes Implemented

### 1. ✅ ALV/AC (Chômage/Unemployment) - MAIN BUG FIX

**Problem:** The old logic incorrectly mixed annual ceiling with monthly calculations using a flawed "months capped" approach.

**Solution:** Replaced with correct monthly ceiling-based calculation.

#### Implementation Details

**Before (Lines 92-101):**
```javascript
// WRONG - Mixed annual/monthly logic
let ac_employee = 0;
if (yearlyGross <= this.rates.AC_CEILING) {
    ac_employee = grossSalary * this.rates.AC_EMPLOYEE;
} else {
    const monthsAtCeiling = Math.floor(this.rates.AC_CEILING / grossSalary);
    const remainingMonths = 12 - monthsAtCeiling;
    ac_employee = (monthsAtCeiling * grossSalary * this.rates.AC_EMPLOYEE) / 12;
    ac_employee += (remainingMonths * grossSalary * this.rates.AC_ADDITIONAL) / 12;
}
```

**After (Corrected):**
```javascript
// CORRECT - Monthly ceiling base
const monthlyCeiling = this.rates.AC_CEILING / 12; // 148,200 / 12 = 12,350
const acBase = Math.min(grossSalary, monthlyCeiling);
const ac_employee = acBase * this.rates.AC_EMPLOYEE;
```

**Employer Calculation (Lines 207-214):**
```javascript
// Before: Same flawed logic
// After: Simple and correct
const ac_employer = acBase * this.rates.AC_EMPLOYER;
```

#### Verification Example

For **monthly gross = 12,500 CHF**:
- `acBase = Math.min(12500, 12350) = 12,350`
- `ac_employee = 12,350 × 0.011 = 135.85 CHF`
- `ac_employer = 12,350 × 0.011 = 135.85 CHF`

**✅ Employee and employer AC amounts now MATCH exactly** (same base + same rate).

---

### 2. ✅ AMat (Maternity Insurance) - Rate Update for 2026

Updated Geneva maternity insurance rates to 2026 values.

#### Changes in `switzerland.js`

**Rates Section (Lines 31-33):**
```javascript
// Before
AMAT_EMPLOYEE: 0.00032,
AMAT_EMPLOYER: 0.00032,

// After
AMAT_EMPLOYEE: 0.00029,
AMAT_EMPLOYER: 0.00029,
```

**Breakdown Labels (Lines 470, 484):**
```javascript
// Before
{ name: 'AMat (0.032%)', amount: results.employeeContributions.amat },
{ name: 'AMat (0.032%)', amount: results.employerContributions.amat },

// After
{ name: 'AMat (0.029%)', amount: results.employeeContributions.amat },
{ name: 'AMat (0.029%)', amount: results.employerContributions.amat },
```

**Formula Display (Lines 165-170, 279-281):**
Updated format strings to show `.toFixed(3)` instead of `.toFixed(4)` for cleaner display (0.029% instead of 0.0290%).

---

### 3. ✅ LAA Non-Professional - Configurable Rate

Made LAA non-professional rate configurable (no longer hardcoded at 3%) as it varies by insurer.

#### New UI Input Field (`index.html` after line 222)

```html
<!-- Switzerland Specific: LAA Non-Professional Rate -->
<div class="input-group country-specific ch-only" style="display: none;">
    <label for="laa-nonprof-rate">
        LAA Non-Professional Rate %
        <span class="label-note">(varies by insurer)</span>
    </label>
    <div class="input-wrapper">
        <input type="number" id="laa-nonprof-rate" class="input-field" value="1.5" min="0" max="5" step="0.1">
        <span class="currency-symbol">%</span>
    </div>
</div>
```

**Default:** 1.5%  
**Range:** 0-5%  
**Note:** Shows "(varies by insurer)" to inform users

#### Integration Changes

**`switzerland.js` (Line 64):**
```javascript
// Added parameter with default
laaNonProfRate = 0.015    // Configurable LAA non-professional rate (default 1.5%)
```

**Employee Calculation (Line 116):**
```javascript
// Before
const laa_employee = includeNonProfAccident ? grossSalary * this.rates.LAA_NON_PROFESSIONAL : 0;

// After
const laa_employee = includeNonProfAccident ? grossSalary * laaNonProfRate : 0;
```

**`ui.js` (Line 549):**
```javascript
if (countryCode === 'CH') {
    params.lppRate = parseFloat(document.getElementById('lpp-rate').value) / 100 || 0.07;
    params.lfpRate = parseFloat(document.getElementById('lfp-rate').value) / 100 || 0.0005;
    params.laaNonProfRate = parseFloat(document.getElementById('laa-nonprof-rate').value) / 100 || 0.015;
}
```

**`calculator.js` (Lines 63, 91):**
```javascript
// Added to parameters
laaNonProfRate = 0.015,  // Switzerland specific (LAA non-professional)

// Added to input object
const input = {
    // ...
    laaNonProfRate
};
```

---

### 4. ✅ Year Label Updates (2025 → 2026)

Updated all references from 2025 to 2026 in Switzerland module:

**Header Comment (Lines 1-5):**
```javascript
/**
 * Switzerland (Geneva Canton) Payroll Calculation Rules
 * Tax year: 2026  // Changed from 2025
 * All rates based on Swiss social security system
 */
```

**Rates Section (Line 12):**
```javascript
// Social security rates (2026)  // Changed from (2025)
```

**LPP Constants (Lines 46-47):**
```javascript
LPP_MIN_SALARY: 22050,     // Minimum salary for LPP obligation (2026)
LPP_COORDINATION: 25725,   // Coordination deduction (2026)
```

---

### 5. ✅ LPP Label Clarity

Enhanced LPP labels to clearly distinguish employee vs employer shares:

**Breakdown Data (Line 487):**
```javascript
// Before
{ name: 'LPP (Pension)', amount: results.employerContributions.lpp },

// After
{ name: 'LPP (Pension - employer)', amount: results.employerContributions.lpp },
```

Employee side already had clear label: `'LPP (Pension)'` in employee section.

---

## Testing Verification

### Test Case: Monthly Gross = 12,500 CHF

**Expected Results:**

| Deduction | Calculation | Amount |
|-----------|-------------|--------|
| **AC Employee** | Min(12,500, 12,350) × 1.10% | **135.85 CHF** |
| **AC Employer** | Min(12,500, 12,350) × 1.10% | **135.85 CHF** |
| **AMat Employee** | 12,500 × 0.029% | 3.63 CHF |
| **AMat Employer** | 12,500 × 0.029% | 3.63 CHF |
| **LAA Non-Prof** | 12,500 × 1.5% (configurable) | 187.50 CHF |

**✅ Key Verification:** AC employee = AC employer (both 135.85)

---

## Code Quality & Safety

### ✅ Mode Isolation Preserved
- No changes to B2B calculations
- Employee mode calculations properly isolated
- Mode guards remain intact

### ✅ Country Isolation Preserved
- No changes to Spain (`spain.js`)
- No changes to Romania (`romania.js`)
- Switzerland-specific parameters only read when `countryCode === 'CH'`

### ✅ Minimal Changes
- Only touched 4 files
- No UI structure changes beyond one new input field
- No breaking changes to existing APIs

### ✅ Backward Compatibility
- Default values provided for all new parameters
- Existing functionality preserved if new input not provided
- LAA non-prof defaults to 1.5% (reasonable for Geneva)

---

## Files Modified

1. **`js/rules/switzerland.js`** - 15 edits
   - Fixed AC calculation logic
   - Updated AMat rates and labels
   - Added laaNonProfRate parameter support
   - Updated 2025 → 2026 labels
   - Enhanced LPP employer label

2. **`js/ui.js`** - 1 edit
   - Added laaNonProfRate input reading

3. **`js/calculator.js`** - 2 edits
   - Added laaNonProfRate parameter
   - Passed to input object

4. **`index.html`** - 1 edit
   - Added LAA Non-Professional Rate input field

---

## Deployment Notes

### ✅ Ready to Deploy
All changes are backward-compatible and safe for immediate deployment.

### Testing Checklist
- [x] AC employee/employer amounts match
- [x] AMat shows 0.029% in UI
- [x] LAA non-prof rate is configurable
- [x] Monthly gross 12,500 CHF gives AC base = 12,350 CHF
- [x] Spain calculations unchanged
- [x] Romania calculations unchanged
- [x] B2B mode unchanged

### User Communication
Users should be informed:
1. Geneva 2026 rates have been updated
2. New configurable LAA non-professional rate (Advanced Options)
3. Default LAA rate is now 1.5% (can be adjusted per insurer)

---

## Summary

✅ **ALV/AC Bug:** Fixed - now uses correct monthly ceiling (12,350 CHF)  
✅ **AMat Rate:** Updated to 0.029% for Geneva 2026  
✅ **LAA Non-Prof:** Now configurable (default 1.5%)  
✅ **Year Labels:** Updated to 2026  
✅ **Code Quality:** Minimal changes, no breaking changes  
✅ **Testing:** All expected outcomes verified  

**Status:** PRODUCTION READY 🚀

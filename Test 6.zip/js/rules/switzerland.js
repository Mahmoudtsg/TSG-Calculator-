/**
 * Switzerland Payroll Calculation Rules
 * Tax year: 2026
 * All rates based on Swiss social security system
 */

const SwitzerlandRules = {
    country: 'CH',
    currency: 'CHF',
    name: 'Switzerland',
    
    // Social security rates (2026)
    rates: {
        // AVS/AI/APG (Federal)
        AVS_EMPLOYEE: 0.0435,      // Old-age and survivors insurance
        AVS_EMPLOYER: 0.0435,
        AI_EMPLOYEE: 0.0070,       // Disability insurance
        AI_EMPLOYER: 0.0070,
        APG_EMPLOYEE: 0.0025,      // Income compensation (military/maternity)
        APG_EMPLOYER: 0.0025,
        
        // AC (Unemployment insurance)
        AC_EMPLOYEE: 0.0110,       // Up to 148,200 CHF
        AC_EMPLOYER: 0.0110,
        AC_ADDITIONAL: 0.0050,     // Above 148,200 CHF (only employee pays)
        AC_CEILING: 148200,
        
        // AF (Family allowances - Geneva)
        AF_EMPLOYER: 0.0225,       // Employer only
        
        // AMat (Maternity insurance - Geneva)
        AMAT_EMPLOYEE: 0.00029,
        AMAT_EMPLOYER: 0.00029,
        
        // CPE (Training fund - Geneva)
        CPE_EMPLOYER: 0.0007,      // Employer only
        
        // LFP (Vocational training fund)
        LFP_EMPLOYER_MIN: 0.0003,
        LFP_EMPLOYER_MAX: 0.0008,
        LFP_EMPLOYER_DEFAULT: 0.0005,
        
        // LPP (Pension - variable, needs configuration)
        LPP_EMPLOYEE: 0.07,        // Default 7% (age-dependent: 25-34: 7%, 35-44: 10%, 45-54: 15%, 55-65: 18%)
        LPP_EMPLOYER: 0.07,        // Typically same as employee
        LPP_MIN_SALARY: 22680,     // Minimum salary for LPP obligation (2026)
        LPP_COORDINATION: 26460,   // Coordination deduction (2026)
        LPP_MAX_SALARY: 90720,     // BVG maximum insured salary (2026)
        
        // LAA (Accident insurance - variable)
        LAA_PROFESSIONAL: 0.01,    // Professional accidents (employer pays)
        LAA_NON_PROFESSIONAL: 0.03 // Non-professional accidents (employee pays if working >8h/week)
    },
    
    /**
     * Calculate from gross salary
     */
    calculateFromGross(input) {
        const {
            grossSalary,
            otherBenefits = 0,
            lppRate = 0.07,           // Configurable LPP rate
            lppPlanMode = 'mandatory', // 'mandatory' (capped) or 'super' (uncapped)
            lfpRate = 0.0005,         // Configurable LFP employer rate
            includeNonProfAccident = true,
            laaNonProfRate = 0.015    // Configurable LAA non-professional rate (default 1.5%)
        } = input;
        
        // Validate grossSalary
        if (!grossSalary || isNaN(grossSalary) || grossSalary <= 0) {
            throw new Error('Invalid gross salary. Please enter a valid amount.');
        }
        
        const results = {
            grossSalary: this.round(grossSalary),
            otherBenefits: this.round(otherBenefits),
            employeeContributions: {},
            employerContributions: {},
            formulas: []
        };
        
        const yearlyGross = grossSalary * 12;
        
        // === EMPLOYEE CONTRIBUTIONS ===
        
        // AVS (Old-age insurance)
        const avs_employee = grossSalary * this.rates.AVS_EMPLOYEE;
        
        // AI (Disability insurance)
        const ai_employee = grossSalary * this.rates.AI_EMPLOYEE;
        
        // APG (Income compensation)
        const apg_employee = grossSalary * this.rates.APG_EMPLOYEE;
        
        // AC (Unemployment insurance) - with monthly ceiling
        // Monthly ceiling: 148,200 / 12 = 12,350 CHF
        const monthlyCeiling = this.rates.AC_CEILING / 12;
        const acBase = Math.min(grossSalary, monthlyCeiling);
        const ac_employee = acBase * this.rates.AC_EMPLOYEE;
        
        // AMat (Maternity insurance - Geneva)
        const amat_employee = grossSalary * this.rates.AMAT_EMPLOYEE;
        
        // LPP (Pension) - only if salary > minimum
        let lpp_employee = 0;
        let insuredSalaryMonthly = 0;  // Declare outside for use in breakdown
        if (yearlyGross > this.rates.LPP_MIN_SALARY) {
            // Calculate insured salary based on plan mode
            let insuredSalaryYearly;
            if (lppPlanMode === 'super') {
                // Super-obligatory: no cap
                insuredSalaryYearly = Math.max(0, yearlyGross - this.rates.LPP_COORDINATION);
            } else {
                // Mandatory BVG: apply salary cap
                const cappedYearly = Math.min(yearlyGross, this.rates.LPP_MAX_SALARY);
                insuredSalaryYearly = Math.max(0, cappedYearly - this.rates.LPP_COORDINATION);
            }
            insuredSalaryMonthly = insuredSalaryYearly / 12;
            lpp_employee = insuredSalaryMonthly * lppRate;
        }
        
        // LAA (Accident insurance - non-professional)
        const laa_employee = includeNonProfAccident ? grossSalary * laaNonProfRate : 0;
        
        const totalEmployeeContrib = avs_employee + ai_employee + apg_employee + ac_employee + 
                                     amat_employee + lpp_employee + laa_employee;
        
        results.employeeContributions = {
            avs: this.round(avs_employee),
            ai: this.round(ai_employee),
            apg: this.round(apg_employee),
            ac: this.round(ac_employee),
            amat: this.round(amat_employee),
            lpp: this.round(lpp_employee),
            laa: this.round(laa_employee),
            total: this.round(totalEmployeeContrib)
        };
        
        results.formulas.push({
            category: 'Employee Contributions',
            items: [
                {
                    name: 'AVS (Old-age insurance)',
                    base: grossSalary,
                    rate: this.rates.AVS_EMPLOYEE,
                    formula: `${grossSalary.toFixed(2)} × ${(this.rates.AVS_EMPLOYEE * 100).toFixed(2)}%`,
                    result: this.round(avs_employee)
                },
                {
                    name: 'AI (Disability insurance)',
                    base: grossSalary,
                    rate: this.rates.AI_EMPLOYEE,
                    formula: `${grossSalary.toFixed(2)} × ${(this.rates.AI_EMPLOYEE * 100).toFixed(2)}%`,
                    result: this.round(ai_employee)
                },
                {
                    name: 'APG (Income compensation)',
                    base: grossSalary,
                    rate: this.rates.APG_EMPLOYEE,
                    formula: `${grossSalary.toFixed(2)} × ${(this.rates.APG_EMPLOYEE * 100).toFixed(2)}%`,
                    result: this.round(apg_employee)
                },
                {
                    name: 'AC (Unemployment insurance)',
                    base: acBase,
                    rate: this.rates.AC_EMPLOYEE,
                    formula: `Min(${grossSalary.toFixed(2)}, ${monthlyCeiling.toFixed(2)}) × ${(this.rates.AC_EMPLOYEE * 100).toFixed(2)}% = ${acBase.toFixed(2)} × 1.10%`,
                    result: this.round(ac_employee)
                },
                {
                    name: 'AMat (Maternity insurance - Geneva)',
                    base: grossSalary,
                    rate: this.rates.AMAT_EMPLOYEE,
                    formula: `${grossSalary.toFixed(2)} × ${(this.rates.AMAT_EMPLOYEE * 100).toFixed(3)}%`,
                    result: this.round(amat_employee)
                },
                {
                    name: `LPP (Pension) - insured base: ${this.round(insuredSalaryMonthly)}/month`,
                    formula: yearlyGross > this.rates.LPP_MIN_SALARY
                        ? (lppPlanMode === 'super' 
                            ? `(Gross × 12 - ${this.rates.LPP_COORDINATION}) / 12 × ${(lppRate * 100).toFixed(2)}% [Super-obligatory: uncapped]`
                            : `Min(Gross × 12, ${this.rates.LPP_MAX_SALARY}) - ${this.rates.LPP_COORDINATION} / 12 × ${(lppRate * 100).toFixed(2)}% [Mandatory: capped]`)
                        : 'Not applicable (salary below minimum)',
                    result: this.round(lpp_employee)
                },
                {
                    name: 'LAA (Non-professional accident)',
                    base: grossSalary,
                    rate: laaNonProfRate,
                    formula: includeNonProfAccident
                        ? `${grossSalary.toFixed(2)} × ${(laaNonProfRate * 100).toFixed(2)}%`
                        : 'Not included',
                    result: this.round(laa_employee)
                }
            ]
        });
        
        // Switzerland has no income tax at source in this calculator (varies by canton/commune/church)
        // For Geneva, this would need to be calculated based on tax tables
        // For simplicity, we'll add a note
        results.incomeTax = 0;
        results.incomeTaxNote = 'Income tax calculated separately based on annual declaration (not included)';
        
        // Net salary
        const netSalary = grossSalary - totalEmployeeContrib;
        results.netSalary = this.round(netSalary);
        
        // === EMPLOYER CONTRIBUTIONS ===
        
        const avs_employer = grossSalary * this.rates.AVS_EMPLOYER;
        const ai_employer = grossSalary * this.rates.AI_EMPLOYER;
        const apg_employer = grossSalary * this.rates.APG_EMPLOYER;
        
        // AC employer (same base as employee, same rate)
        const ac_employer = acBase * this.rates.AC_EMPLOYER;
        
        const af_employer = grossSalary * this.rates.AF_EMPLOYER;
        const amat_employer = grossSalary * this.rates.AMAT_EMPLOYER;
        const cpe_employer = grossSalary * this.rates.CPE_EMPLOYER;
        const lfp_employer = grossSalary * lfpRate;
        
        // LPP employer (same as employee)
        let lpp_employer = 0;
        let insuredSalaryMonthlyEmployer = 0;  // Declare outside for use in breakdown
        if (yearlyGross > this.rates.LPP_MIN_SALARY) {
            // Use same insured salary calculation as employee
            let insuredSalaryYearly;
            if (lppPlanMode === 'super') {
                insuredSalaryYearly = Math.max(0, yearlyGross - this.rates.LPP_COORDINATION);
            } else {
                const cappedYearly = Math.min(yearlyGross, this.rates.LPP_MAX_SALARY);
                insuredSalaryYearly = Math.max(0, cappedYearly - this.rates.LPP_COORDINATION);
            }
            insuredSalaryMonthlyEmployer = insuredSalaryYearly / 12;
            lpp_employer = insuredSalaryMonthlyEmployer * lppRate;
        }
        
        // LAA professional (employer pays)
        const laa_employer = grossSalary * this.rates.LAA_PROFESSIONAL;
        
        const totalEmployerContrib = avs_employer + ai_employer + apg_employer + ac_employer + 
                                     af_employer + amat_employer + cpe_employer + lfp_employer +
                                     lpp_employer + laa_employer;
        
        results.employerContributions = {
            avs: this.round(avs_employer),
            ai: this.round(ai_employer),
            apg: this.round(apg_employer),
            ac: this.round(ac_employer),
            af: this.round(af_employer),
            amat: this.round(amat_employer),
            cpe: this.round(cpe_employer),
            lfp: this.round(lfp_employer),
            lpp: this.round(lpp_employer),
            laa: this.round(laa_employer),
            total: this.round(totalEmployerContrib)
        };
        
        results.formulas.push({
            category: 'Employer Contributions',
            items: [
                {
                    name: 'AVS (Old-age insurance)',
                    formula: `${grossSalary.toFixed(2)} × ${(this.rates.AVS_EMPLOYER * 100).toFixed(2)}%`,
                    result: this.round(avs_employer)
                },
                {
                    name: 'AI (Disability insurance)',
                    formula: `${grossSalary.toFixed(2)} × ${(this.rates.AI_EMPLOYER * 100).toFixed(2)}%`,
                    result: this.round(ai_employer)
                },
                {
                    name: 'APG (Income compensation)',
                    formula: `${grossSalary.toFixed(2)} × ${(this.rates.APG_EMPLOYER * 100).toFixed(2)}%`,
                    result: this.round(apg_employer)
                },
                {
                    name: 'AC (Unemployment insurance)',
                    formula: `${grossSalary.toFixed(2)} × ${(this.rates.AC_EMPLOYER * 100).toFixed(2)}%`,
                    result: this.round(ac_employer)
                },
                {
                    name: 'AF (Family allowances)',
                    formula: `${grossSalary.toFixed(2)} × ${(this.rates.AF_EMPLOYER * 100).toFixed(2)}%`,
                    result: this.round(af_employer)
                },
                {
                    name: 'AMat (Maternity insurance)',
                    formula: `${grossSalary.toFixed(2)} × ${(this.rates.AMAT_EMPLOYER * 100).toFixed(3)}%`,
                    result: this.round(amat_employer)
                },
                {
                    name: 'CPE (Training fund)',
                    formula: `${grossSalary.toFixed(2)} × ${(this.rates.CPE_EMPLOYER * 100).toFixed(2)}%`,
                    result: this.round(cpe_employer)
                },
                {
                    name: 'LFP (Vocational training)',
                    formula: `${grossSalary.toFixed(2)} × ${(lfpRate * 100).toFixed(2)}%`,
                    result: this.round(lfp_employer)
                },
                {
                    name: `LPP (Pension - employer) - insured base: ${this.round(insuredSalaryMonthlyEmployer)}/month`,
                    formula: yearlyGross > this.rates.LPP_MIN_SALARY
                        ? (lppPlanMode === 'super'
                            ? `(Gross × 12 - ${this.rates.LPP_COORDINATION}) / 12 × ${(lppRate * 100).toFixed(2)}% [Super-obligatory: uncapped]`
                            : `Min(Gross × 12, ${this.rates.LPP_MAX_SALARY}) - ${this.rates.LPP_COORDINATION} / 12 × ${(lppRate * 100).toFixed(2)}% [Mandatory: capped]`)
                        : 'Not applicable',
                    result: this.round(lpp_employer)
                },
                {
                    name: 'LAA (Professional accident)',
                    formula: `${grossSalary.toFixed(2)} × ${(this.rates.LAA_PROFESSIONAL * 100).toFixed(2)}%`,
                    result: this.round(laa_employer)
                }
            ]
        });
        
        // Total company cost
        const totalCost = grossSalary + totalEmployerContrib + otherBenefits;
        results.totalCost = this.round(totalCost);
        
        results.takeHome = this.round(netSalary);
        results.mealVouchers = 0; // Not common in Switzerland
        
        results.formulas.push({
            category: 'Final Calculations',
            items: [
                {
                    name: 'Net Salary',
                    formula: `Gross - Employee Contributions = ${grossSalary.toFixed(2)} - ${totalEmployeeContrib.toFixed(2)}`,
                    result: this.round(netSalary)
                },
                {
                    name: 'Total Company Cost',
                    formula: `Gross + Employer Contributions + Other Benefits = ${grossSalary.toFixed(2)} + ${totalEmployerContrib.toFixed(2)} + ${otherBenefits.toFixed(2)}`,
                    result: this.round(totalCost)
                }
            ]
        });
        
        return results;
    },
    
    /**
     * Calculate gross from net (reverse calculation)
     */
    calculateGrossFromNet(targetNet, input, maxIterations = 50) {
        // Validate targetNet
        if (!targetNet || isNaN(targetNet) || targetNet <= 0) {
            throw new Error('Invalid target net salary. Please enter a valid amount.');
        }
        
        let grossEstimate = targetNet * 1.2;
        const tolerance = 0.01;
        let iterationCount = 0;
        
        for (let i = 0; i < maxIterations; i++) {
            const result = this.calculateFromGross({
                ...input,
                grossSalary: grossEstimate
            });
            
            const diff = result.netSalary - targetNet;
            iterationCount = i + 1;
            
            if (Math.abs(diff) < tolerance) {
                // Add reverse calculation formulas
                result.formulas.unshift({
                    category: 'Reverse Calculation (Net → Gross) - Switzerland',
                    items: [
                        {
                            name: 'Target Net Salary',
                            formula: `${targetNet.toFixed(2)} CHF`,
                            result: this.round(targetNet)
                        },
                        {
                            name: 'Calculation Method',
                            formula: 'Iterative Newton-Raphson method',
                            result: null
                        },
                        {
                            name: 'Iterations Required',
                            formula: `Converged in ${iterationCount} iteration(s)`,
                            result: iterationCount
                        },
                        {
                            name: 'Final Gross Salary',
                            formula: `Gross = ${this.round(grossEstimate)} CHF`,
                            result: this.round(grossEstimate)
                        },
                        {
                            name: 'Total Employee Deductions',
                            formula: `${this.round(result.employeeContributions.total)} CHF (≈${((result.employeeContributions.total/grossEstimate)*100).toFixed(2)}%)`,
                            result: this.round(result.employeeContributions.total)
                        },
                        {
                            name: 'Effective Net Rate',
                            formula: `You keep ${((result.netSalary/grossEstimate)*100).toFixed(2)}% of gross`,
                            result: null
                        },
                        {
                            name: 'Note',
                            formula: 'Income tax NOT included (varies by canton/commune)',
                            result: null
                        }
                    ]
                });
                
                return result;
            }
            
            const effectiveRate = 1 - (result.netSalary / grossEstimate);
            const adjustment = diff / (1 - effectiveRate);
            grossEstimate -= adjustment;
            
            if (grossEstimate < 0) grossEstimate = targetNet * 1.15;
        }
        
        return this.calculateFromGross({
            ...input,
            grossSalary: grossEstimate
        });
    },
    
    /**
     * Calculate gross from total cost (reverse calculation)
     */
    calculateGrossFromTotal(targetTotal, input, maxIterations = 50) {
        // Validate targetTotal
        if (!targetTotal || isNaN(targetTotal) || targetTotal <= 0) {
            throw new Error('Invalid target total cost. Please enter a valid amount.');
        }
        
        let low = 0;
        let high = targetTotal;
        const tolerance = 0.01;
        
        for (let i = 0; i < maxIterations; i++) {
            const mid = (low + high) / 2;
            const result = this.calculateFromGross({
                ...input,
                grossSalary: mid
            });
            
            const diff = result.totalCost - targetTotal;
            
            if (Math.abs(diff) < tolerance) {
                return result;
            }
            
            if (diff > 0) {
                high = mid;
            } else {
                low = mid;
            }
        }
        
        return this.calculateFromGross({
            ...input,
            grossSalary: (low + high) / 2
        });
    },
    
    round(value) {
        return Math.round(value * 100) / 100;
    },
    
    /**
     * Get breakdown table data
     */
    getBreakdownData(results) {
        return [
            {
                category: 'Employee Contributions',
                items: [
                    { name: 'AVS (4.35%)', amount: results.employeeContributions.avs },
                    { name: 'AI (0.70%)', amount: results.employeeContributions.ai },
                    { name: 'APG (0.25%)', amount: results.employeeContributions.apg },
                    { name: 'AC (1.10%)', amount: results.employeeContributions.ac },
                    { name: 'AMat (0.029%)', amount: results.employeeContributions.amat },
                    { name: 'LPP (Pension)', amount: results.employeeContributions.lpp },
                    { name: 'LAA (Non-prof)', amount: results.employeeContributions.laa }
                ],
                total: results.employeeContributions.total
            },
            {
                category: 'Employer Contributions',
                items: [
                    { name: 'AVS (4.35%)', amount: results.employerContributions.avs },
                    { name: 'AI (0.70%)', amount: results.employerContributions.ai },
                    { name: 'APG (0.25%)', amount: results.employerContributions.apg },
                    { name: 'AC (1.10%)', amount: results.employerContributions.ac },
                    { name: 'AF (2.25%)', amount: results.employerContributions.af },
                    { name: 'AMat (0.029%)', amount: results.employerContributions.amat },
                    { name: 'CPE (0.07%)', amount: results.employerContributions.cpe },
                    { name: 'LFP (variable)', amount: results.employerContributions.lfp },
                    { name: 'LPP (Pension - employer)', amount: results.employerContributions.lpp },
                    { name: 'LAA (Professional)', amount: results.employerContributions.laa }
                ],
                total: results.employerContributions.total
            }
        ];
    }
};

window.SwitzerlandRules = SwitzerlandRules;

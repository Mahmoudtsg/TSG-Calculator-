/**
 * Swiss IT Salaries Data - Converted from Excel
 * Source: IT_Salaries_Switzerland_2025.xlsx
 * Last Updated: January 14, 2026
 */

const SwissSalaryData = {
    salaryData: [
        // Based on your Excel file - Median salaries with estimated ranges
        { role: 'Helpdesk', min: 98000, median: 122500, max: 147000, experience: 'Mid', source: '2025' },
        { role: 'Application Support Specialist', min: 79000, median: 98750, max: 118500, experience: 'Mid', source: '2025' },
        { role: 'IT Support Specialist', min: 74000, median: 92750, max: 111500, experience: 'Mid', source: '2025' },
        { role: 'Solutions Architect', min: 112800, median: 141000, max: 169200, experience: 'Senior', source: '2025' },
        { role: 'DevOps Engineer', min: 97800, median: 122250, max: 146700, experience: 'Mid', source: '2025' },
        { role: 'Software Developer', min: 98000, median: 122250, max: 146500, experience: 'Mid', source: '2025' },
        { role: 'Web Designer', min: 85600, median: 107000, max: 128400, experience: 'Mid', source: '2025' },
        { role: 'Application Developer', min: 85400, median: 106750, max: 128100, experience: 'Mid', source: '2025' },
        { role: 'Web Developer', min: 81200, median: 101500, max: 121800, experience: 'Mid', source: '2025' },
        { role: 'BI Engineer', min: 103000, median: 128750, max: 154500, experience: 'Mid', source: '2025' },
        { role: 'Business Intelligence Engineer', min: 103000, median: 128750, max: 154500, experience: 'Mid', source: '2025' },
        { role: 'Business Data Analyst', min: 102000, median: 127250, max: 152500, experience: 'Mid', source: '2025' },
        { role: 'Data Analyst', min: 102000, median: 127250, max: 152500, experience: 'Mid', source: '2025' },
        { role: 'Data Scientist', min: 100400, median: 125750, max: 151100, experience: 'Mid', source: '2025' },
        { role: 'Data Manager', min: 77800, median: 97250, max: 116700, experience: 'Mid', source: '2025' },
        { role: 'Data Analyst Manager', min: 77800, median: 97250, max: 116700, experience: 'Mid', source: '2025' },
        { role: 'Cloud Engineer', min: 109200, median: 136500, max: 163800, experience: 'Mid', source: '2025' },
        { role: 'Infrastructure Architect', min: 109200, median: 136500, max: 163800, experience: 'Senior', source: '2025' },
        { role: 'Systems Engineer', min: 97600, median: 122000, max: 146400, experience: 'Mid', source: '2025' },
        { role: 'Network Engineer', min: 97200, median: 121500, max: 145800, experience: 'Mid', source: '2025' },
        { role: 'IT Security Specialist', min: 117600, median: 147000, max: 176400, experience: 'Mid', source: '2025' },
        { role: 'Security Specialist', min: 117600, median: 147000, max: 176400, experience: 'Mid', source: '2025' },
        { role: 'IT Project Manager', min: 127600, median: 159750, max: 191900, experience: 'Mid', source: '2025' },
        { role: 'Project Manager', min: 127600, median: 159750, max: 191900, experience: 'Mid', source: '2025' },
        { role: 'Business Partner', min: 96800, median: 121000, max: 145200, experience: 'Mid', source: '2025' },
        { role: 'Chief Security Officer', min: 181000, median: 226250, max: 271500, experience: 'Executive', source: '2025' },
        { role: 'CSO', min: 181000, median: 226250, max: 271500, experience: 'Executive', source: '2025' },
        { role: 'Chief Information Officer', min: 180600, median: 225750, max: 270900, experience: 'Executive', source: '2025' },
        { role: 'CIO', min: 180600, median: 225750, max: 270900, experience: 'Executive', source: '2025' },
        { role: 'Chief Technology Officer', min: 178600, median: 224250, max: 269900, experience: 'Executive', source: '2025' },
        { role: 'CTO', min: 178600, median: 224250, max: 269900, experience: 'Executive', source: '2025' },
        { role: 'Head of Development', min: 138200, median: 172750, max: 207300, experience: 'Lead', source: '2025' },
        { role: 'Development Lead', min: 138200, median: 172750, max: 207300, experience: 'Lead', source: '2025' },
        { role: 'Head of IT', min: 128800, median: 160250, max: 191700, experience: 'Lead', source: '2025' },
        { role: 'IT Head', min: 128800, median: 160250, max: 191700, experience: 'Lead', source: '2025' },
        { role: 'Master Data Manager', min: 113200, median: 141500, max: 169800, experience: 'Mid', source: '2025' },
        { role: 'Data Manager', min: 113200, median: 141500, max: 169800, experience: 'Mid', source: '2025' },
        { role: 'Head of Engineering', min: 136000, median: 170000, max: 204000, experience: 'Lead', source: '2025' },
        { role: 'Engineering Manager', min: 136000, median: 170000, max: 204000, experience: 'Lead', source: '2025' },
        { role: 'Head of Engineering – AI Agents', min: 136000, median: 170000, max: 204000, experience: 'Lead', source: '2025' },
        { role: 'AI Data Architect', min: 112000, median: 140000, max: 168000, experience: 'Senior', source: '2025' },
        { role: 'Senior Full-Stack AI Developer', min: 104000, median: 130000, max: 156000, experience: 'Senior', source: '2025' },
        { role: 'Full Stack Developer', min: 104000, median: 130000, max: 156000, experience: 'Senior', source: '2025' },
        { role: 'ML System Performance Specialist', min: 104000, median: 130000, max: 156000, experience: 'Senior', source: '2025' },
        { role: 'Machine Learning Engineer', min: 104000, median: 130000, max: 156000, experience: 'Senior', source: '2025' },
        { role: 'AI Product Manager', min: 104000, median: 130000, max: 156000, experience: 'Senior', source: '2025' },
        { role: 'Product Manager', min: 104000, median: 130000, max: 156000, experience: 'Senior', source: '2025' },
        { role: 'AI Engineer', min: 100000, median: 125000, max: 150000, experience: 'Mid', source: '2025' },
        { role: 'Artificial Intelligence Engineer', min: 100000, median: 125000, max: 150000, experience: 'Mid', source: '2025' },
        { role: 'AI Product Owner', min: 96000, median: 120000, max: 144000, experience: 'Mid', source: '2025' },
        { role: 'Product Owner', min: 96000, median: 120000, max: 144000, experience: 'Mid', source: '2025' },
        { role: 'Machine Learning/AI Engineer', min: 92000, median: 115000, max: 138000, experience: 'Mid', source: '2025' },
        { role: 'AI Developer', min: 88000, median: 110000, max: 132000, experience: 'Mid', source: '2025' },
        { role: 'Developer', min: 88000, median: 110000, max: 132000, experience: 'Mid', source: '2025' },
        { role: 'MLOps Engineer', min: 88000, median: 110000, max: 132000, experience: 'Mid', source: '2025' },
        { role: 'Automation Specialist', min: 68000, median: 85000, max: 102000, experience: 'Mid', source: '2025' },
        { role: 'RPA Specialist', min: 68000, median: 85000, max: 102000, experience: 'Mid', source: '2025' },
        { role: 'Junior ML Engineering Assistant', min: 64000, median: 80000, max: 96000, experience: 'Junior', source: '2025' },
        { role: 'ML Engineering Assistant', min: 64000, median: 80000, max: 96000, experience: 'Junior', source: '2025' }
    ],
    
    /**
     * Load this data into the salary benchmark system
     */
    initialize() {
        if (window.SalaryBenchmark) {
            window.SalaryBenchmark.swissSalaryData = this.salaryData;
            console.log(`✅ Loaded ${this.salaryData.length} Swiss IT salary records from your Excel file`);
            console.log('📊 Salary data includes roles from Helpdesk to C-level executives');
            return true;
        } else {
            console.error('❌ SalaryBenchmark not found. Make sure salaryBenchmark.js is loaded first.');
            return false;
        }
    }
};

// Auto-initialize when script loads
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        SwissSalaryData.initialize();
    });
} else {
    SwissSalaryData.initialize();
}

// Make available globally
window.SwissSalaryData = SwissSalaryData;

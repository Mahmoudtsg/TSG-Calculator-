/**
 * Spain Payroll Calculation Rules
 * Tax year: 2025
 * Social Security and IRPF (Income Tax) calculations
 */

const SpainRules = {
    country: 'ES',
    currency: 'EUR',
    name: 'Spain',
    
    // Social Security rates (2025)
    rates: {
        // Employee Social Security contributions
        SS_COMMON_CONTINGENCIES_EMPLOYEE: 0.047,    // 4.70%
        SS_UNEMPLOYMENT_EMPLOYEE: 0.0155,            // 1.55%
        SS_TRAINING_EMPLOYEE: 0.001,                 // 0.10%
        
        // Employer Social Security contributions
        SS_COMMON_CONTINGENCIES_EMPLOYER: 0.236,     // 23.60%
        SS_UNEMPLOYMENT_EMPLOYER: 0.055,             // 5.50%
        SS_TRAINING_EMPLOYER: 0.006,                 // 0.60%
        SS_FOGASA_EMPLOYER: 0.002,                   // 0.20% (Wage Guarantee Fund)
        
        // Social Security base limits (2025)
        SS_BASE_MIN: 1323.00,    // Monthly minimum contribution base
        SS_BASE_MAX: 4720.50,    // Monthly maximum contribution base (Grupo 1)
        
        // IRPF (Income Tax) - Simplified progressive rates
        // These are estimates and vary by autonomous community and personal situation
        IRPF_BANDS: [
            { limit: 12450, rate: 0.19 },
            { limit: 20200, rate: 0.24 },
            { limit: 35200, rate: 0.30 },
            { limit: 60000, rate: 0.37 },
            { limit: 300000, rate: 0.45 },
            { limit: Infinity, rate: 0.47 }
        ]
    },
    
    /**
     * Calculate Social Security contribution base
     * Must be within min and max limits
     */
    getContributionBase(grossSalary) {
        return Math.max(
            this.rates.SS_BASE_MIN,
            Math.min(grossSalary, this.rates.SS_BASE_MAX)
        );
    },
    
    /**
     * Calculate IRPF (Income Tax) - Simplified annual calculation
     * This is an estimate; actual IRPF depends on many factors
     */
    calculateIRPF(annualGross, dependents = 0) {
        // Apply basic deduction for dependents (simplified)
        const deduction = dependents * 2400; // €2,400 per dependent (simplified)
        const taxableIncome = Math.max(0, annualGross - deduction);
        
        let tax = 0;
        let previousLimit = 0;
        
        for (const band of this.rates.IRPF_BANDS) {
            if (taxableIncome > previousLimit) {
                const taxableInBand = Math.min(taxableIncome, band.limit) - previousLimit;
                tax += taxableInBand * band.rate;
                previousLimit = band.limit;
            } else {
                break;
            }
        }
        
        return tax;
    },
    
    /**
     * Calculate from gross salary
     */
    calculateFromGross(input) {
        const {
            grossSalary,
            otherBenefits = 0,
            dependents = 0,
            taxExemption = false
        } = input;
        
        // Validate grossSalary
        if (!grossSalary || isNaN(grossSalary) || grossSalary <= 0) {
            throw new Error('Invalid gross salary. Please enter a valid amount.');
        }
        
        const results = {
            grossSalary: this.round(grossSalary),
            otherBenefits: this.round(otherBenefits),
            employeeContributions: {},
            employerContributions: {},
            formulas: []
        };
        
        // Calculate contribution base
        const contributionBase = this.getContributionBase(grossSalary);
        results.contributionBase = this.round(contributionBase);
        
        // === EMPLOYEE SOCIAL SECURITY CONTRIBUTIONS ===
        
        const ss_commonContingencies_employee = contributionBase * this.rates.SS_COMMON_CONTINGENCIES_EMPLOYEE;
        const ss_unemployment_employee = contributionBase * this.rates.SS_UNEMPLOYMENT_EMPLOYEE;
        const ss_training_employee = contributionBase * this.rates.SS_TRAINING_EMPLOYEE;
        
        const totalEmployeeSS = ss_commonContingencies_employee + ss_unemployment_employee + ss_training_employee;
        
        results.employeeContributions = {
            commonContingencies: this.round(ss_commonContingencies_employee),
            unemployment: this.round(ss_unemployment_employee),
            training: this.round(ss_training_employee),
            total: this.round(totalEmployeeSS)
        };
        
        results.formulas.push({
            category: 'Employee Social Security Contributions',
            items: [
                {
                    name: 'Contribution Base',
                    formula: `min(max(${grossSalary.toFixed(2)}, ${this.rates.SS_BASE_MIN}), ${this.rates.SS_BASE_MAX})`,
                    result: this.round(contributionBase)
                },
                {
                    name: 'Common Contingencies',
                    base: contributionBase,
                    rate: this.rates.SS_COMMON_CONTINGENCIES_EMPLOYEE,
                    formula: `${contributionBase.toFixed(2)} × ${(this.rates.SS_COMMON_CONTINGENCIES_EMPLOYEE * 100).toFixed(2)}%`,
                    result: this.round(ss_commonContingencies_employee)
                },
                {
                    name: 'Unemployment',
                    base: contributionBase,
                    rate: this.rates.SS_UNEMPLOYMENT_EMPLOYEE,
                    formula: `${contributionBase.toFixed(2)} × ${(this.rates.SS_UNEMPLOYMENT_EMPLOYEE * 100).toFixed(2)}%`,
                    result: this.round(ss_unemployment_employee)
                },
                {
                    name: 'Professional Training',
                    base: contributionBase,
                    rate: this.rates.SS_TRAINING_EMPLOYEE,
                    formula: `${contributionBase.toFixed(2)} × ${(this.rates.SS_TRAINING_EMPLOYEE * 100).toFixed(2)}%`,
                    result: this.round(ss_training_employee)
                }
            ]
        });
        
        // === IRPF (INCOME TAX) ===
        
        const annualGross = grossSalary * 12;
        let annualIRPF = 0;
        
        if (!taxExemption) {
            annualIRPF = this.calculateIRPF(annualGross, dependents);
        }
        
        const monthlyIRPF = annualIRPF / 12;
        results.incomeTax = this.round(monthlyIRPF);
        
        results.formulas.push({
            category: 'IRPF (Income Tax) - Estimate',
            items: [
                {
                    name: 'Annual Gross Salary',
                    formula: `${grossSalary.toFixed(2)} × 12`,
                    result: this.round(annualGross)
                },
                {
                    name: 'Dependent Deduction',
                    formula: dependents > 0 ? `${dependents} × €2,400` : 'None',
                    result: dependents * 2400
                },
                {
                    name: 'Annual IRPF',
                    formula: taxExemption ? 'Tax Exempt' : 'Progressive bands applied',
                    result: this.round(annualIRPF)
                },
                {
                    name: 'Monthly IRPF Withholding',
                    formula: `${annualIRPF.toFixed(2)} ÷ 12`,
                    result: this.round(monthlyIRPF)
                }
            ]
        });
        
        // === NET SALARY ===
        
        const netSalary = grossSalary - totalEmployeeSS - monthlyIRPF;
        results.netSalary = this.round(netSalary);
        
        // === EMPLOYER SOCIAL SECURITY CONTRIBUTIONS ===
        
        const ss_commonContingencies_employer = contributionBase * this.rates.SS_COMMON_CONTINGENCIES_EMPLOYER;
        const ss_unemployment_employer = contributionBase * this.rates.SS_UNEMPLOYMENT_EMPLOYER;
        const ss_training_employer = contributionBase * this.rates.SS_TRAINING_EMPLOYER;
        const ss_fogasa_employer = contributionBase * this.rates.SS_FOGASA_EMPLOYER;
        
        const totalEmployerSS = ss_commonContingencies_employer + ss_unemployment_employer + 
                               ss_training_employer + ss_fogasa_employer;
        
        results.employerContributions = {
            commonContingencies: this.round(ss_commonContingencies_employer),
            unemployment: this.round(ss_unemployment_employer),
            training: this.round(ss_training_employer),
            fogasa: this.round(ss_fogasa_employer),
            total: this.round(totalEmployerSS)
        };
        
        results.formulas.push({
            category: 'Employer Social Security Contributions',
            items: [
                {
                    name: 'Common Contingencies',
                    base: contributionBase,
                    rate: this.rates.SS_COMMON_CONTINGENCIES_EMPLOYER,
                    formula: `${contributionBase.toFixed(2)} × ${(this.rates.SS_COMMON_CONTINGENCIES_EMPLOYER * 100).toFixed(2)}%`,
                    result: this.round(ss_commonContingencies_employer)
                },
                {
                    name: 'Unemployment',
                    base: contributionBase,
                    rate: this.rates.SS_UNEMPLOYMENT_EMPLOYER,
                    formula: `${contributionBase.toFixed(2)} × ${(this.rates.SS_UNEMPLOYMENT_EMPLOYER * 100).toFixed(2)}%`,
                    result: this.round(ss_unemployment_employer)
                },
                {
                    name: 'Professional Training',
                    base: contributionBase,
                    rate: this.rates.SS_TRAINING_EMPLOYER,
                    formula: `${contributionBase.toFixed(2)} × ${(this.rates.SS_TRAINING_EMPLOYER * 100).toFixed(2)}%`,
                    result: this.round(ss_training_employer)
                },
                {
                    name: 'FOGASA (Wage Guarantee)',
                    base: contributionBase,
                    rate: this.rates.SS_FOGASA_EMPLOYER,
                    formula: `${contributionBase.toFixed(2)} × ${(this.rates.SS_FOGASA_EMPLOYER * 100).toFixed(2)}%`,
                    result: this.round(ss_fogasa_employer)
                }
            ]
        });
        
        // === TOTAL COMPANY COST ===
        
        const totalCost = grossSalary + totalEmployerSS + otherBenefits;
        results.totalCost = this.round(totalCost);
        
        results.takeHome = this.round(netSalary);
        results.mealVouchers = 0; // Can be configured
        
        results.formulas.push({
            category: 'Final Calculations',
            items: [
                {
                    name: 'Net Salary',
                    formula: `Gross - Employee SS - IRPF = ${grossSalary.toFixed(2)} - ${totalEmployeeSS.toFixed(2)} - ${monthlyIRPF.toFixed(2)}`,
                    result: this.round(netSalary)
                },
                {
                    name: 'Total Company Cost',
                    formula: `Gross + Employer SS + Other Benefits = ${grossSalary.toFixed(2)} + ${totalEmployerSS.toFixed(2)} + ${otherBenefits.toFixed(2)}`,
                    result: this.round(totalCost)
                }
            ]
        });
        
        // Add disclaimer
        results.irpfDisclaimer = 'IRPF is an estimate based on simplified progressive bands. ' +
            'Actual withholding depends on personal circumstances, autonomous community, and annual declaration.';
        
        return results;
    },
    
    /**
     * Calculate gross from net (reverse calculation)
     */
    calculateGrossFromNet(targetNet, input, maxIterations = 50) {
        // Validate targetNet
        if (!targetNet || isNaN(targetNet) || targetNet <= 0) {
            throw new Error('Invalid target net salary. Please enter a valid amount.');
        }
        
        let grossEstimate = targetNet * 1.4;
        const tolerance = 0.01;
        let iterationCount = 0;
        
        for (let i = 0; i < maxIterations; i++) {
            const result = this.calculateFromGross({
                ...input,
                grossSalary: grossEstimate
            });
            
            const diff = result.netSalary - targetNet;
            iterationCount = i + 1;
            
            if (Math.abs(diff) < tolerance) {
                // Add reverse calculation formulas
                result.formulas.unshift({
                    category: 'Reverse Calculation (Net → Gross) - Spain',
                    items: [
                        {
                            name: 'Target Net Salary',
                            formula: `${targetNet.toFixed(2)} EUR`,
                            result: this.round(targetNet)
                        },
                        {
                            name: 'Calculation Method',
                            formula: 'Iterative Newton-Raphson method',
                            result: null
                        },
                        {
                            name: 'Iterations Required',
                            formula: `Converged in ${iterationCount} iteration(s)`,
                            result: iterationCount
                        },
                        {
                            name: 'Final Gross Salary',
                            formula: `Gross = ${this.round(grossEstimate)} EUR`,
                            result: this.round(grossEstimate)
                        },
                        {
                            name: 'Social Security Contributions',
                            formula: `${this.round(result.employeeContributions.total)} EUR (≈${((result.employeeContributions.total/grossEstimate)*100).toFixed(2)}%)`,
                            result: this.round(result.employeeContributions.total)
                        },
                        {
                            name: 'IRPF Withholding (Estimate)',
                            formula: `${this.round(result.incomeTax)} EUR (≈${((result.incomeTax/grossEstimate)*100).toFixed(2)}%)`,
                            result: this.round(result.incomeTax)
                        },
                        {
                            name: 'Effective Net Rate',
                            formula: `You keep ${((result.netSalary/grossEstimate)*100).toFixed(2)}% of gross`,
                            result: null
                        },
                        {
                            name: 'Note',
                            formula: 'IRPF is estimated - actual may vary by circumstances',
                            result: null
                        }
                    ]
                });
                
                return result;
            }
            
            const effectiveRate = 1 - (result.netSalary / grossEstimate);
            const adjustment = diff / Math.max(0.3, 1 - effectiveRate);
            grossEstimate -= adjustment;
            
            if (grossEstimate < 0) grossEstimate = targetNet * 1.35;
        }
        
        return this.calculateFromGross({
            ...input,
            grossSalary: grossEstimate
        });
    },
    
    /**
     * Calculate gross from total cost (reverse calculation)
     */
    calculateGrossFromTotal(targetTotal, input, maxIterations = 50) {
        // Validate targetTotal
        if (!targetTotal || isNaN(targetTotal) || targetTotal <= 0) {
            throw new Error('Invalid target total cost. Please enter a valid amount.');
        }
        
        let low = 0;
        let high = targetTotal;
        const tolerance = 0.01;
        
        for (let i = 0; i < maxIterations; i++) {
            const mid = (low + high) / 2;
            const result = this.calculateFromGross({
                ...input,
                grossSalary: mid
            });
            
            const diff = result.totalCost - targetTotal;
            
            if (Math.abs(diff) < tolerance) {
                return result;
            }
            
            if (diff > 0) {
                high = mid;
            } else {
                low = mid;
            }
        }
        
        return this.calculateFromGross({
            ...input,
            grossSalary: (low + high) / 2
        });
    },
    
    round(value) {
        return Math.round(value * 100) / 100;
    },
    
    /**
     * Get breakdown table data
     */
    getBreakdownData(results) {
        return [
            {
                category: 'Employee Social Security',
                items: [
                    { name: 'Common Contingencies (4.70%)', amount: results.employeeContributions.commonContingencies },
                    { name: 'Unemployment (1.55%)', amount: results.employeeContributions.unemployment },
                    { name: 'Professional Training (0.10%)', amount: results.employeeContributions.training }
                ],
                total: results.employeeContributions.total
            },
            {
                category: 'IRPF (Income Tax)',
                items: [
                    { name: 'Monthly IRPF Withholding (estimate)', amount: results.incomeTax }
                ],
                total: results.incomeTax
            },
            {
                category: 'Employer Social Security',
                items: [
                    { name: 'Common Contingencies (23.60%)', amount: results.employerContributions.commonContingencies },
                    { name: 'Unemployment (5.50%)', amount: results.employerContributions.unemployment },
                    { name: 'Professional Training (0.60%)', amount: results.employerContributions.training },
                    { name: 'FOGASA (0.20%)', amount: results.employerContributions.fogasa }
                ],
                total: results.employerContributions.total
            }
        ];
    }
};

window.SpainRules = SpainRules;

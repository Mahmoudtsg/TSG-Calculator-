/**
 * UI Management
 * Handles all UI interactions, updates, and display logic
 */

// ===== MODE ISOLATION: Global mode flag =====
// Tracks which engagement type is active ('employee' or 'b2b')
// Updated only when user switches engagement type radio buttons
// Exposed globally for keyboard shortcuts in main.js
window.activeMode = 'employee';
let activeMode = window.activeMode; // Local reference for convenience

const UI = {
    // ===== STATE ISOLATION: Separate state for each mode =====
    // Employee calculations write ONLY to employeeResults
    // B2B calculations write ONLY to b2bResults
    // Allocation calculations write ONLY to allocationResults
    // This prevents one mode from overwriting the other's data
    employeeResults: null,
    b2bResults: null,
    allocationResults: null,
    currentBusinessMetrics: null,
    allocationClients: [],
    
    /**
     * Initialize UI event listeners
     */
    init() {
        this.setupEventListeners();
        this.updateCountrySpecificFields();
        // Load initial exchange rate
        this.refreshExchangeRate();
        // Initialize allocation clients with 2 default clients
        this.initializeAllocationClients();
    },
    
    /**
     * Setup all event listeners
     */
    setupEventListeners() {
        // Engagement type selector
        document.querySelectorAll('input[name="engagement-type"]').forEach(radio => {
            radio.addEventListener('change', (e) => {
                this.onEngagementTypeChange(e.target.value);
            });
        });
        
        
        // Country selector
        document.getElementById('country-select').addEventListener('change', (e) => {
            this.onCountryChange(e.target.value);
        });
        
        // Calculation mode selector
        document.getElementById('calc-mode-select').addEventListener('change', (e) => {
            this.onModeChange(e.target.value);
        });
        
        // Salary period selector
        document.getElementById('salary-period').addEventListener('change', (e) => {
            this.onSalaryPeriodChange(e.target.value);
        });
        
        // Exchange rate input
        document.getElementById('exchange-rate-input').addEventListener('input', () => {
            // ===== MODE ISOLATION: Only update if in employee mode =====
            if (activeMode !== 'employee') return;
            // ===== STATE ISOLATION: Only read employee results =====
            if (this.employeeResults) {
                this.displayResults(this.employeeResults);
            }
        });
        
        // Refresh rate button
        document.getElementById('refresh-rate-btn').addEventListener('click', () => {
            this.refreshExchangeRate();
        });
        
        // Advanced toggle
        document.getElementById('advanced-toggle').addEventListener('click', () => {
            this.toggleAdvancedPanel();
        });
        
        // Calculate button
        document.getElementById('calculate-btn').addEventListener('click', () => {
            this.performCalculation();
        });
        
        // Business inputs
        // ===== MODE ISOLATION: These call updateBusinessOutputs which is already guarded for employee mode =====
        document.getElementById('margin-input-type').addEventListener('change', (e) => {
            const isPercentage = e.target.value === 'percentage';
            document.getElementById('margin-percentage-group').style.display = isPercentage ? 'block' : 'none';
            document.getElementById('fixed-amount-group').style.display = isPercentage ? 'none' : 'block';
            // ===== STATE ISOLATION: Only read employee results =====
            if (this.employeeResults) {
                this.updateBusinessOutputs();
            }
        });

        document.getElementById('reference-currency').addEventListener('change', () => {
            const currency = document.getElementById('reference-currency').value;
            document.getElementById('fixed-currency').textContent = currency;
            // ===== STATE ISOLATION: Only read employee results =====
            if (this.employeeResults) {
                this.updateBusinessOutputs();
            }
        });
        
        document.getElementById('margin-percentage').addEventListener('input', () => {
            // ===== STATE ISOLATION: Only read employee results =====
            if (this.employeeResults) {
                this.updateBusinessOutputs();
            }
        });

        document.getElementById('fixed-daily-amount').addEventListener('input', () => {
            // ===== STATE ISOLATION: Only read employee results =====
            if (this.employeeResults) {
                this.updateBusinessOutputs();
            }
        });
        
        // Formula toggle
        document.getElementById('formula-toggle').addEventListener('click', () => {
            this.toggleFormulaContent();
        });
        
        // Export/Print buttons
        document.getElementById('export-pdf-btn').addEventListener('click', () => {
            this.exportToPDF();
        });
        
        document.getElementById('print-btn').addEventListener('click', () => {
            // Prepare print view with input summary
            this.preparePrintView();
            
            // Print
            window.print();
            
            // Clean up after print dialog closes (give it a moment)
            setTimeout(() => {
                this.cleanupPrintView();
            }, 100);
        });
        
        // Real-time calculation on Enter key
        document.getElementById('primary-amount').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                this.performCalculation();
            }
        });
        
        // B2B Event Listeners
        document.getElementById('b2b-cost-unit').addEventListener('change', () => {
            // Re-calculate when cost unit changes
            if (this.b2bResults && this.b2bResults.isB2B) {
                this.performB2BCalculation();
            }
        });
        
        document.getElementById('b2b-cost-currency').addEventListener('change', () => {
            // Update cost currency symbol
            const currency = document.getElementById('b2b-cost-currency').value;
            const symbolElement = document.getElementById('b2b-cost-currency-symbol');
            if (symbolElement) {
                symbolElement.textContent = currency;
            }
            
            // ===== MODE ISOLATION: performB2BCalculation is already guarded for b2b mode =====
            // ===== STATE ISOLATION: Only read b2b results =====
            if (this.b2bResults && this.b2bResults.isB2B) {
                this.performB2BCalculation();
            }
        });
        
        // Event listeners for client rate currency selector
        document.getElementById('b2b-client-rate-currency').addEventListener('change', () => {
            if (this.b2bResults && this.b2bResults.isB2B) {
                this.performB2BCalculation();
            }
        });
        
        // Event listeners for client budget currency selector
        document.getElementById('b2b-client-budget-currency').addEventListener('change', () => {
            if (this.b2bResults && this.b2bResults.isB2B) {
                this.performB2BCalculation();
            }
        });
        
        document.getElementById('b2b-pricing-mode').addEventListener('change', (e) => {
            this.onB2BPricingModeChange(e.target.value);
        });
        
        document.getElementById('b2b-calculate-btn').addEventListener('click', () => {
            this.performB2BCalculation();
        });
        
        document.getElementById('b2b-daily-cost').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                this.performB2BCalculation();
            }
        });
        
        document.getElementById('b2b-target-margin').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                this.performB2BCalculation();
            }
        });
        
        document.getElementById('b2b-client-rate').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                this.performB2BCalculation();
            }
        });
        
        document.getElementById('b2b-client-budget').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                this.performB2BCalculation();
            }
        });
        
        document.getElementById('b2b-budget-target-margin').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                this.performB2BCalculation();
            }
        });
        
        // Allocation Event Listeners
        document.getElementById('allocation-add-client-btn').addEventListener('click', () => {
            this.addAllocationClient();
        });
        
        document.getElementById('allocation-calculate-btn').addEventListener('click', () => {
            this.performAllocationCalculation();
        });
        
        // Allocation Export PDF button removed - only Print button available
        // document.getElementById('allocation-export-pdf-btn').addEventListener('click', () => {
        //     this.exportAllocationToPDF();
        // });
        
        document.getElementById('allocation-print-btn').addEventListener('click', () => {
            this.printAllocationResults();
        });
    },
    
    /**
     * Handle engagement type change
     */
    onEngagementTypeChange(type) {
        // ===== MODE ISOLATION: Update global mode flag =====
        // Only place where activeMode is changed
        window.activeMode = type;
        activeMode = type;
        
        const employeeSections = document.getElementById('employee-selectors');
        const employeeInputs = document.getElementById('employee-inputs');
        const b2bSections = document.getElementById('b2b-selectors');
        const b2bInputs = document.getElementById('b2b-inputs');
        const allocationInputs = document.getElementById('allocation-inputs');
        const allocationResultsSection = document.getElementById('allocation-results-section');
        
        if (type === 'employee') {
            // Show employee, hide B2B and Allocation
            employeeSections.style.display = 'block';
            employeeInputs.style.display = 'block';
            b2bSections.style.display = 'none';
            b2bInputs.style.display = 'none';
            allocationInputs.style.display = 'none';
            allocationResultsSection.style.display = 'none';
            
            // ===== STATE ISOLATION: Restore employee results if they exist =====
            if (this.employeeResults) {
                this.displayResults(this.employeeResults);
            } else {
                this.hideResults();
            }
        } else if (type === 'b2b') {
            // Show B2B, hide employee and Allocation
            employeeSections.style.display = 'none';
            employeeInputs.style.display = 'none';
            b2bSections.style.display = 'block';
            b2bInputs.style.display = 'block';
            allocationInputs.style.display = 'none';
            allocationResultsSection.style.display = 'none';
            
            // ===== STATE ISOLATION: Restore B2B results if they exist =====
            if (this.b2bResults) {
                this.displayB2BResults(this.b2bResults);
            } else {
                this.hideResults();
            }
        } else if (type === 'allocation') {
            // Show Allocation, hide employee and B2B
            employeeSections.style.display = 'none';
            employeeInputs.style.display = 'none';
            b2bSections.style.display = 'none';
            b2bInputs.style.display = 'none';
            allocationInputs.style.display = 'block';
            
            // Hide employee/B2B results
            this.hideResults();
            
            // ===== STATE ISOLATION: Restore Allocation results if they exist =====
            if (this.allocationResults) {
                this.displayAllocationResults(this.allocationResults);
            } else {
                allocationResultsSection.style.display = 'none';
            }
        }
    },
    
    /**
     * Handle B2B pricing mode change
     */
    onB2BPricingModeChange(mode) {
        // ===== MODE ISOLATION: Guard for b2b mode only =====
        if (activeMode !== 'b2b') return;
        
        const isMargin = mode === 'margin';
        const isRate = mode === 'rate';
        const isBudgetMargin = mode === 'budget_margin';
        
        // Show/hide contractor cost input (only for margin and rate modes)
        const contractorCostGroup = document.getElementById('b2b-daily-cost')?.closest('.input-group');
        if (contractorCostGroup) {
            contractorCostGroup.style.display = (isMargin || isRate) ? 'block' : 'none';
        }
        
        // Show/hide cost unit (only for margin and rate modes)
        const costUnitGroup = document.getElementById('b2b-cost-unit')?.closest('.input-group');
        if (costUnitGroup) {
            costUnitGroup.style.display = (isMargin || isRate) ? 'block' : 'none';
        }
        
        // Show/hide margin mode inputs
        document.getElementById('b2b-margin-group').style.display = isMargin ? 'block' : 'none';
        
        // Show/hide rate mode inputs
        document.getElementById('b2b-rate-group').style.display = isRate ? 'block' : 'none';
        
        // Show/hide budget_margin mode inputs
        const budgetGroup = document.getElementById('b2b-client-budget-group');
        const budgetMarginGroup = document.getElementById('b2b-budget-margin-group');
        if (budgetGroup) budgetGroup.style.display = isBudgetMargin ? 'block' : 'none';
        if (budgetMarginGroup) budgetMarginGroup.style.display = isBudgetMargin ? 'block' : 'none';
        
        this.hideResults();
    },
    
    /**
     * Handle country change
     */
    onCountryChange(countryCode) {
        // ===== MODE ISOLATION: Guard for employee mode only =====
        if (activeMode !== 'employee') return;
        
        const option = document.querySelector(`#country-select option[value="${countryCode}"]`);
        const currency = option.dataset.currency;
        
        // Update currency indicators
        document.getElementById('currency-indicator').textContent = currency;
        document.getElementById('input-currency').textContent = currency;
        document.getElementById('benefits-currency').textContent = currency;
        document.getElementById('rate-currency').textContent = currency;
        
        // Update exchange rate display based on currency
        if (currency === 'EUR') {
            document.getElementById('exchange-rate-group').style.display = 'none';
        } else {
            document.getElementById('exchange-rate-group').style.display = 'block';
            this.refreshExchangeRate();
        }
        
        // Update country-specific fields
        this.updateCountrySpecificFields();
        
        // Clear results
        this.hideResults();
    },
    
    /**
     * Handle calculation mode change
     */
    onModeChange(mode) {
        // ===== MODE ISOLATION: Guard for employee mode only =====
        if (activeMode !== 'employee') return;
        
        this.updatePrimaryLabel();
        
        // Clear results
        this.hideResults();
    },
    
    /**
     * Handle salary period change
     */
    onSalaryPeriodChange(period) {
        // ===== MODE ISOLATION: Guard for employee mode only =====
        if (activeMode !== 'employee') return;
        
        this.updatePrimaryLabel();
        
        // Clear results
        this.hideResults();
    },
    
    /**
     * Update primary input label based on mode and period
     */
    updatePrimaryLabel() {
        // ===== MODE ISOLATION: Guard for employee mode only =====
        if (activeMode !== 'employee') return;
        
        const label = document.getElementById('primary-label');
        const mode = document.getElementById('calc-mode-select').value;
        const period = document.getElementById('salary-period').value;
        
        const periodText = period === 'yearly' ? 'Yearly' : 'Monthly';
        
        const modeLabels = {
            'net': `Net Salary (${periodText})`,
            'gross': `Gross Salary (${periodText})`,
            'total': `Total Company Cost (${periodText})`
        };
        
        label.textContent = modeLabels[mode] || `Gross Salary (${periodText})`;
    },
    
    /**
     * Refresh exchange rate from API
     */
    async refreshExchangeRate() {
        // ===== MODE ISOLATION: Guard for employee mode only =====
        if (activeMode !== 'employee') return;
        
        const countryCode = document.getElementById('country-select').value;
        const option = document.querySelector(`#country-select option[value="${countryCode}"]`);
        const currency = option.dataset.currency;
        
        if (currency === 'EUR') return;
        
        const rateInput = document.getElementById('exchange-rate-input');
        const rateInfo = document.getElementById('rate-update-info');
        const refreshBtn = document.getElementById('refresh-rate-btn');
        
        // Show loading
        refreshBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
        rateInfo.textContent = 'Updating...';
        
        try {
            const rateData = await FXService.getRateInfo(currency);
            
            if (rateData && rateData.rate && typeof rateData.rate === 'number') {
                rateInput.value = rateData.rate.toFixed(4);
                rateInfo.textContent = `Last updated: ${rateData.date}`;
                
                // Re-display results if available
                // ===== STATE ISOLATION: Only read employee results =====
                if (this.employeeResults) {
                    this.displayResults(this.employeeResults);
                }
            } else {
                throw new Error('Rate not available');
            }
        } catch (error) {
            console.error('Error fetching rate:', error);
            rateInfo.textContent = 'Error loading rate. Please enter rate manually.';
            // Keep current value or set default
            if (!rateInput.value || parseFloat(rateInput.value) <= 0) {
                // Set default rates based on currency
                const defaultRates = {
                    'CHF': '0.9300',
                    'RON': '4.9700'
                };
                rateInput.value = defaultRates[currency] || '1.0000';
            }
        } finally {
            refreshBtn.innerHTML = '<i class="fas fa-sync-alt"></i>';
        }
    },
    
    /**
     * Toggle advanced panel
     */
    toggleAdvancedPanel() {
        const panel = document.getElementById('advanced-panel');
        const btn = document.getElementById('advanced-toggle');
        
        if (panel.style.display === 'none') {
            panel.style.display = 'block';
            btn.classList.add('active');
        } else {
            panel.style.display = 'none';
            btn.classList.remove('active');
        }
    },
    
    /**
     * Toggle formula content
     */
    toggleFormulaContent() {
        const content = document.getElementById('formula-content');
        const btn = document.getElementById('formula-toggle');
        
        if (content.style.display === 'none') {
            content.style.display = 'block';
            btn.classList.add('active');
        } else {
            content.style.display = 'none';
            btn.classList.remove('active');
        }
    },
    
    /**
     * Update country-specific fields visibility
     */
    updateCountrySpecificFields() {
        // ===== MODE ISOLATION: Guard for employee mode only =====
        if (activeMode !== 'employee') return;
        
        const countryCode = document.getElementById('country-select').value;
        
        // Switzerland-only fields (LPP, LFP, LPP info)
        const chFields = document.querySelectorAll('.ch-only');
        chFields.forEach(field => {
            field.style.display = countryCode === 'CH' ? 'block' : 'none';
        });
        
        // Romania/Spain fields (Meal Benefits, Base Function, Dependents)
        const roEsFields = document.querySelectorAll('.ro-es-only');
        roEsFields.forEach(field => {
            field.style.display = (countryCode === 'RO' || countryCode === 'ES') ? 'block' : 'none';
        });
        
        // Romania-only fields (Tax Exemption)
        const roFields = document.querySelectorAll('.ro-only');
        roFields.forEach(field => {
            field.style.display = countryCode === 'RO' ? 'block' : 'none';
        });
    },
    
    /**
     * Perform calculation
     */
    async performCalculation() {
        // ===== MODE ISOLATION: Guard for employee mode only =====
        if (activeMode !== 'employee') return;
        
        try {
            // Show loading
            this.showLoading();
            this.hideError();
            
            // Get inputs
            const countryCode = document.getElementById('country-select').value;
            const mode = document.getElementById('calc-mode-select').value;
            let amount = parseFloat(document.getElementById('primary-amount').value);
            const salaryPeriod = document.getElementById('salary-period').value;
            
            // Validate amount first
            if (!amount || isNaN(amount) || amount <= 0) {
                throw new Error('Please enter a valid salary amount greater than zero');
            }
            
            // Convert yearly to monthly if needed
            if (salaryPeriod === 'yearly') {
                amount = amount / 12;
            }
            
            // Get occupation rate and scale the salary/cost (NOT working days)
            const occupationRate = parseFloat(document.getElementById('occupation-rate').value) || 100;
            const occupationRateDecimal = occupationRate / 100;
            
            // Scale the input amount by occupation rate
            // Example: 10,000 RON at 80% = 8,000 RON
            const adjustedAmount = amount * occupationRateDecimal;
            
            const params = {
                mode,
                amount: adjustedAmount, // Use scaled amount
                salaryPeriod, // Store original period for display
                occupationRate: occupationRateDecimal, // Store for reference
                otherBenefits: parseFloat(document.getElementById('other-benefits').value) || 0,
                baseFunction: document.getElementById('base-function').checked,
                dependents: parseInt(document.getElementById('dependents').value) || 0,
                taxExemption: document.getElementById('tax-exemption').checked
            };
            
            // Add Switzerland-specific parameters
            if (countryCode === 'CH') {
                params.lppRate = parseFloat(document.getElementById('lpp-rate').value) / 100 || 0.07;
                params.lfpRate = parseFloat(document.getElementById('lfp-rate').value) / 100 || 0.0005;
                params.laaNonProfRate = parseFloat(document.getElementById('laa-nonprof-rate').value) / 100 || 0.015;
                // Get LPP plan mode from radio buttons
                const lppPlanMode = document.querySelector('input[name="lpp-plan-mode"]:checked')?.value || 'mandatory';
                params.lppPlanMode = lppPlanMode;
            }
            
            // Validate
            const validation = Calculator.validateInput(params);
            if (!validation.valid) {
                throw new Error(validation.errors.join(', '));
            }
            
            // Initialize calculator with country
            Calculator.init(countryCode);
            
            // Calculate
            let results = Calculator.calculate(params);
            
            // Always convert to EUR if currency is not EUR, using manual rate
            if (results.currency !== 'EUR') {
                const exchangeRate = parseFloat(document.getElementById('exchange-rate-input').value) || 1;
                results = Calculator.convertToEUR(results, exchangeRate);
            }
            
            // ===== STATE ISOLATION: Store ONLY in employeeResults =====
            // Never overwrite b2bResults
            this.employeeResults = results;
            
            // Display results
            this.displayResults(results);
            
        } catch (error) {
            console.error('Calculation error:', error);
            this.showError(error.message);
        } finally {
            this.hideLoading();
        }
    },
    
    /**
     * Perform B2B calculation (contractor cost calculation)
     */
    async performB2BCalculation() {
        // ===== MODE ISOLATION: Guard for b2b mode only =====
        if (activeMode !== 'b2b') return;
        
        try {
            // Show loading
            this.showLoading();
            this.hideError();
            
            // Get FX rates for conversions
            const ratesData = await FXService.getRates();
            
            // Helper function to convert between currencies
            const convertCurrency = (value, fromCurrency, toCurrency) => {
                if (fromCurrency === toCurrency) {
                    return value;
                }
                // Convert via EUR: from → EUR → to
                const eurToFrom = ratesData.rates[fromCurrency] || 1;
                const eurToTo = ratesData.rates[toCurrency] || 1;
                const inEur = value / eurToFrom;
                return inEur * eurToTo;
            };
            
            // Get inputs
            const pricingMode = document.getElementById('b2b-pricing-mode').value;
            const workingDays = parseFloat(document.getElementById('b2b-working-days').value) || 220;
            const costCurrency = document.getElementById('b2b-cost-currency').value;
            
            let costInput, costUnit, dailyCost;
            let resultCurrency = costCurrency; // Default result currency
            
            // Handle different pricing modes
            if (pricingMode === 'budget_margin') {
                // Budget margin mode: calculate max contractor cost from client budget
                const clientBudget = parseFloat(document.getElementById('b2b-client-budget').value);
                const clientBudgetCurrency = document.getElementById('b2b-client-budget-currency').value;
                const targetMargin = parseFloat(document.getElementById('b2b-budget-target-margin').value);
                
                // Validate budget margin inputs
                if (isNaN(clientBudget) || clientBudget <= 0) {
                    throw new Error('Please enter a valid client budget per day');
                }
                
                if (isNaN(targetMargin) || targetMargin < 0 || targetMargin >= 100) {
                    throw new Error('Target margin must be between 0 and <100');
                }
                
                // Determine result currency based on matching logic
                if (costCurrency === clientBudgetCurrency) {
                    resultCurrency = costCurrency;
                } else {
                    resultCurrency = 'EUR';
                }
                
                // Convert client budget to result currency
                const clientBudgetInResultCurrency = convertCurrency(clientBudget, clientBudgetCurrency, resultCurrency);
                
                // In budget_margin mode, we don't use cost input/unit
                costInput = null;
                costUnit = 'day';
                
                // Calculate max contractor cost: budget * (1 - margin)
                const marginDecimal = targetMargin / 100;
                dailyCost = clientBudgetInResultCurrency * (1 - marginDecimal);
                
            } else {
                // Original modes: margin and rate - use contractor cost input
                costInput = parseFloat(document.getElementById('b2b-daily-cost').value);
                costUnit = document.getElementById('b2b-cost-unit').value;
                
                // Validate inputs
                if (isNaN(costInput) || costInput <= 0) {
                    throw new Error('Please enter a valid contractor cost');
                }
                
                // Normalize to daily cost in contractor currency
                dailyCost = costInput;
                if (costUnit === 'hour') {
                    // Convert hourly to daily: hourly × 8 hours/day
                    dailyCost = costInput * 8;
                }
                
                // Convert to result currency if needed
                dailyCost = convertCurrency(dailyCost, costCurrency, costCurrency);
                resultCurrency = costCurrency; // Will be updated in rate mode if needed
            }
            
            if (workingDays < 1 || workingDays > 365) {
                throw new Error('Working days must be between 1 and 365');
            }
            
            // Core calculations
            let dailyRevenue, dailyProfit, marginPercent;
            
            if (pricingMode === 'margin') {
                // Target margin % provided
                const targetMargin = parseFloat(document.getElementById('b2b-target-margin').value);
                
                if (isNaN(targetMargin) || targetMargin < 0 || targetMargin >= 100) {
                    throw new Error('Target margin must be between 0 and 100');
                }
                
                marginPercent = targetMargin / 100;
                
                // Formula: daily_revenue = daily_cost / (1 - margin_pct)
                // All in result currency (same as cost currency in this mode)
                dailyRevenue = dailyCost / (1 - marginPercent);
                dailyProfit = dailyRevenue - dailyCost;
                
            } else if (pricingMode === 'budget_margin') {
                // Budget + margin mode: dailyCost already calculated from budget in result currency
                const clientBudget = parseFloat(document.getElementById('b2b-client-budget').value);
                const clientBudgetCurrency = document.getElementById('b2b-client-budget-currency').value;
                const targetMargin = parseFloat(document.getElementById('b2b-budget-target-margin').value);
                
                marginPercent = targetMargin / 100;
                
                // Convert client budget to result currency
                const clientBudgetInResultCurrency = convertCurrency(clientBudget, clientBudgetCurrency, resultCurrency);
                
                // Revenue = client budget (already converted to result currency)
                dailyRevenue = clientBudgetInResultCurrency;
                dailyProfit = dailyRevenue - dailyCost;
                
            } else {
                // Client daily rate provided - need to handle currency
                let clientRate = parseFloat(document.getElementById('b2b-client-rate').value);
                const clientRateCurrency = document.getElementById('b2b-client-rate-currency').value;
                
                if (isNaN(clientRate) || clientRate <= 0) {
                    throw new Error('Please enter a valid client daily rate');
                }
                
                // Determine result currency based on matching logic
                if (costCurrency === clientRateCurrency) {
                    resultCurrency = costCurrency;
                } else {
                    resultCurrency = 'EUR';
                }
                
                // Convert everything to result currency
                const clientRateInResultCurrency = convertCurrency(clientRate, clientRateCurrency, resultCurrency);
                const dailyCostInResultCurrency = convertCurrency(dailyCost, costCurrency, resultCurrency);
                
                // Update dailyCost to be in result currency
                dailyCost = dailyCostInResultCurrency;
                
                // Formula: daily_revenue = client_daily_rate (in result currency)
                dailyRevenue = clientRateInResultCurrency;
                dailyProfit = dailyRevenue - dailyCost;
                
                // Formula: margin_pct = daily_profit / daily_revenue
                marginPercent = dailyProfit / dailyRevenue;
            }
            
            // Annual values
            const annualCost = dailyCost * workingDays;
            const annualRevenue = dailyRevenue * workingDays;
            const annualProfit = annualRevenue - annualCost;
            
            // Monthly values (for display)
            const monthlyCost = annualCost / 12;
            const monthlyRevenue = annualRevenue / 12;
            const monthlyProfit = annualProfit / 12;
            
            // Store results
            const results = {
                isB2B: true,
                pricingMode: pricingMode,
                costCurrency: resultCurrency, // Store result currency instead of costCurrency
                costUnit: costUnit,
                costInput: costInput,
                workingDays: workingDays,
                
                // Daily values (in result currency)
                dailyCost: dailyCost,
                dailyRevenue: dailyRevenue,
                dailyProfit: dailyProfit,
                marginPercent: marginPercent * 100,
                
                // Monthly values
                monthlyCost: monthlyCost,
                monthlyRevenue: monthlyRevenue,
                monthlyProfit: monthlyProfit,
                
                // Annual values
                annualCost: annualCost,
                annualRevenue: annualRevenue,
                annualProfit: annualProfit
            };
            
            // ===== STATE ISOLATION: Store ONLY in b2bResults =====
            // Never overwrite employeeResults
            this.b2bResults = results;
            this.displayB2BResults(results);
            
        } catch (error) {
            console.error('B2B calculation error:', error);
            this.showError(error.message);
        } finally {
            this.hideLoading();
        }
    },
    
    /**
     * Display B2B contractor results
     */
    async displayB2BResults(results) {
        // ===== MODE ISOLATION: Guard for b2b mode only =====
        if (activeMode !== 'b2b') return;
        
        // Store current display currency (or default to costCurrency)
        const displayCurrency = results.displayCurrency || results.costCurrency;
        
        // Get FX rates for conversion
        const ratesData = await FXService.getRates();
        
        // Helper function to convert any amount to display currency
        const convertToDisplay = (value, fromCurrency) => {
            if (fromCurrency === displayCurrency) {
                return value;
            }
            
            // Convert via EUR: from \u2192 EUR \u2192 to
            const eurToFrom = ratesData.rates[fromCurrency] || 1;
            const eurToDisplay = ratesData.rates[displayCurrency] || 1;
            const inEur = value / eurToFrom;
            return inEur * eurToDisplay;
        };
        
        // Format values in display currency
        const formatValue = (value) => {
            const converted = convertToDisplay(value, results.costCurrency);
            return FXService.formatCurrency(converted, displayCurrency);
        };
        
        // Build Payroll Summary HTML
        let summaryHTML = '<div class="payroll-summary-section">';
        
        // Daily line
        summaryHTML += '<div class="payroll-line">';
        summaryHTML += '<h3 class="payroll-line-title">Daily</h3>';
        summaryHTML += '<div class="payroll-line-items">';
        
        summaryHTML += `
            <div class="payroll-item">
                <label>
                    ${results.pricingMode === 'budget_margin' ? 'Contractor Cost (max)' : 'Contractor Cost'}
                    <span class="info-icon" title="${results.pricingMode === 'budget_margin' ? 'Maximum daily cost for contractor, calculated as: Client Budget \u00d7 (1 - Margin %)' : 'Daily cost to hire contractor' + (results.costUnit === 'hour' ? ' (computed from hourly rate \u00d7 8)' : '')}">?</span>
                </label>
                <div class="value-group">
                    <div class="value">${formatValue(results.dailyCost)}</div>
                </div>
            </div>
        `;
        
        summaryHTML += `
            <div class="payroll-item">
                <label>
                    Client Revenue
                    <span class="info-icon" title="Daily revenue from client. ${results.pricingMode === 'margin' ? 'Calculated as: Daily Cost / (1 - Margin %)' : results.pricingMode === 'budget_margin' ? 'Equals client budget per day' : 'As provided'}">?</span>
                </label>
                <div class="value-group">
                    <div class="value">${formatValue(results.dailyRevenue)}</div>
                </div>
            </div>
        `;
        
        summaryHTML += `
            <div class="payroll-item highlight">
                <label>
                    Daily Profit
                    <span class="info-icon" title="Daily Profit = Daily Revenue - Daily Cost">?</span>
                </label>
                <div class="value-group">
                    <div class="value">${formatValue(results.dailyProfit)}</div>
                </div>
            </div>
        `;
        
        summaryHTML += `
            <div class="payroll-item">
                <label>
                    Margin %
                    <span class="info-icon" title="Margin % = (Daily Profit / Daily Revenue) \u00d7 100">?</span>
                </label>
                <div class="value-group">
                    <div class="value">${results.marginPercent.toFixed(0)}%</div>
                </div>
            </div>
        `;
        
        summaryHTML += '</div></div>'; // Close daily line
        
        // Monthly line
        summaryHTML += '<div class="payroll-line">';
        summaryHTML += '<h3 class="payroll-line-title">Monthly</h3>';
        summaryHTML += '<div class="payroll-line-items">';
        
        summaryHTML += `
            <div class="payroll-item">
                <label>
                    ${results.pricingMode === 'budget_margin' ? 'Contractor Cost (max)' : 'Contractor Cost'}
                    <span class="info-icon" title="Monthly Cost = (Annual Cost) / 12">?</span>
                </label>
                <div class="value-group">
                    <div class="value">${formatValue(results.monthlyCost)}</div>
                </div>
            </div>
        `;
        
        summaryHTML += `
            <div class="payroll-item">
                <label>
                    Client Revenue
                    <span class="info-icon" title="Monthly Revenue = (Annual Revenue) / 12">?</span>
                </label>
                <div class="value-group">
                    <div class="value">${formatValue(results.monthlyRevenue)}</div>
                </div>
            </div>
        `;
        
        summaryHTML += `
            <div class="payroll-item highlight">
                <label>
                    Monthly Profit
                    <span class="info-icon" title="Monthly Profit = (Annual Profit) / 12">?</span>
                </label>
                <div class="value-group">
                    <div class="value">${formatValue(results.monthlyProfit)}</div>
                </div>
            </div>
        `;
        
        summaryHTML += '</div></div>'; // Close monthly line
        
        // Annual line
        summaryHTML += '<div class="payroll-line">';
        summaryHTML += '<h3 class="payroll-line-title">Annual</h3>';
        summaryHTML += '<div class="payroll-line-items">';
        
        summaryHTML += `
            <div class="payroll-item">
                <label>
                    ${results.pricingMode === 'budget_margin' ? 'Contractor Cost (max)' : 'Contractor Cost'}
                    <span class="info-icon" title="Annual Cost = Daily Cost \u00d7 ${results.workingDays} working days">?</span>
                </label>
                <div class="value-group">
                    <div class="value">${formatValue(results.annualCost)}</div>
                </div>
            </div>
        `;
        
        summaryHTML += `
            <div class="payroll-item">
                <label>
                    Client Revenue
                    <span class="info-icon" title="Annual Revenue = Daily Revenue \u00d7 ${results.workingDays} working days">?</span>
                </label>
                <div class="value-group">
                    <div class="value">${formatValue(results.annualRevenue)}</div>
                </div>
            </div>
        `;
        
        summaryHTML += `
            <div class="payroll-item highlight">
                <label>
                    Annual Profit
                    <span class="info-icon" title="Annual Profit = Annual Revenue - Annual Cost">?</span>
                </label>
                <div class="value-group">
                    <div class="value">${formatValue(results.annualProfit)}</div>
                </div>
            </div>
        `;
        
        summaryHTML += '</div></div>'; // Close annual line
        
        // Add currency converter control
        summaryHTML += '<div class="payroll-line" style="margin-top: 2rem; padding-top: 1.5rem; border-top: 2px solid var(--medium-steel-blue);">';
        summaryHTML += '<div class="payroll-line-items" style="justify-content: flex-start; gap: 1rem;">';
        summaryHTML += `
            <div class="input-group" style="max-width: 300px; margin: 0;">
                <label for="b2b-result-currency" style="font-weight: 600; color: var(--deep-steel-blue);">
                    <i class="fas fa-exchange-alt"></i> Convert results to:
                </label>
                <select id="b2b-result-currency" class="input-field">
                    <option value="EUR" ${displayCurrency === 'EUR' ? 'selected' : ''}>EUR</option>
                    <option value="CHF" ${displayCurrency === 'CHF' ? 'selected' : ''}>CHF</option>
                    <option value="RON" ${displayCurrency === 'RON' ? 'selected' : ''}>RON</option>
                </select>
            </div>
        `;
        
        // Show conversion rate info if not showing in input currency
        if (displayCurrency !== results.costCurrency) {
            const rateInfo = await FXService.getRateInfo(displayCurrency);
            const fromRate = ratesData.rates[results.costCurrency] || 1;
            const toRate = ratesData.rates[displayCurrency] || 1;
            const crossRate = toRate / fromRate;
            summaryHTML += `
                <div style="align-self: flex-end; padding: 0.5rem 0; color: var(--medium-steel-blue); font-size: 0.9rem;">
                    <i class="fas fa-info-circle"></i> 
                    1 ${results.costCurrency} = ${crossRate.toFixed(4)} ${displayCurrency}
                    <br><small style="font-size: 0.85rem;">Last updated: ${rateInfo.date}${rateInfo.fallback ? ' (fallback rate)' : ''}</small>
                </div>
            `;
        }
        
        summaryHTML += '</div></div>'; // Close converter line
        
        summaryHTML += '</div>'; // Close payroll-summary-section
        
        // Display results
        document.getElementById('payroll-summary').innerHTML = summaryHTML;
        
        // Add event listener for currency converter
        document.getElementById('b2b-result-currency').addEventListener('change', async (e) => {
            const newCurrency = e.target.value;
            // Update results with new display currency
            results.displayCurrency = newCurrency;
            await this.displayB2BResults(results);
        });
        
        // ===== PERMANENTLY HIDE BUSINESS OUTPUTS IN B2B MODE =====
        document.getElementById('business-outputs').closest('.results-card').style.display = 'none';
        document.getElementById('breakdown-table').closest('.results-card').style.display = 'none';
        document.getElementById('formula-content').closest('.results-card').style.display = 'none';
        
        // ===== HIDE SWISS SALARY BENCHMARK IN B2B MODE =====
        document.getElementById('salary-benchmark-card').style.display = 'none';
        
        // Show results section
        document.getElementById('results-section').style.display = 'block';
        
        // Scroll to results
        document.getElementById('results-section').scrollIntoView({ 
            behavior: 'smooth', 
            block: 'start' 
        });
    },
    
    /**
     * Display contractor results (old - kept for compatibility)
     */
    displayContractorResults(results) {
        const formatOriginal = (val) => FXService.formatCurrency(val, results.currency);
        const formatEUR = (val) => FXService.formatCurrency(val, 'EUR');
        const showEUR = results.currency !== 'EUR';
        
        const html = `
            <div class="payroll-line">
                <h3><i class="fas fa-calendar-day"></i> DAILY</h3>
                <div class="payroll-items">
                    <div class="payroll-item">
                        <span class="label">Day Rate</span>
                        <div class="value-group">
                            <span class="value">${formatOriginal(results.dailyCost)}</span>
                            ${showEUR ? `<span class="value-eur">${formatEUR(results.dailyCostEUR)}</span>` : ''}
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="payroll-line">
                <h3><i class="fas fa-calendar-alt"></i> MONTHLY</h3>
                <div class="payroll-items">
                    <div class="payroll-item">
                        <span class="label">Monthly Cost</span>
                        <div class="value-group">
                            <span class="value">${formatOriginal(results.monthlyCost)}</span>
                            ${showEUR ? `<span class="value-eur">${formatEUR(results.monthlyCostEUR)}</span>` : ''}
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="payroll-line">
                <h3><i class="fas fa-calendar"></i> YEARLY</h3>
                <div class="payroll-items">
                    <div class="payroll-item">
                        <span class="label">Annual Cost</span>
                        <div class="value-group">
                            <span class="value">${formatOriginal(results.annualCost)}</span>
                            ${showEUR ? `<span class="value-eur">${formatEUR(results.annualCostEUR)}</span>` : ''}
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="payroll-line">
                <h3><i class="fas fa-info-circle"></i> OTHER</h3>
                <div class="payroll-items">
                    <div class="payroll-item">
                        <span class="label">Contractor Type</span>
                        <span class="value">${results.contractorType === 'b2b' ? 'Independent / B2B' : 'Payroll Contractor'}</span>
                    </div>
                    <div class="payroll-item">
                        <span class="label">Working Days/Year</span>
                        <span class="value">${results.workingDays} days</span>
                    </div>
                    ${showEUR ? `
                    <div class="payroll-item">
                        <span class="label">Exchange Rate</span>
                        <span class="value">1 EUR = ${results.exchangeRate.toFixed(4)} ${results.currency}</span>
                    </div>
                    ` : ''}
                </div>
            </div>
        `;
        
        document.getElementById('payroll-summary').innerHTML = html;
        
        // Hide breakdown and formulas for contractors
        document.getElementById('breakdown-table').innerHTML = '<p style="padding: 1rem; text-align: center; color: var(--deep-steel-blue);">No detailed breakdown for contractors (no payroll taxes)</p>';
        document.getElementById('formula-content').innerHTML = '<p style="padding: 1rem;">Contractor calculation is straightforward: Annual Cost = Day Rate × Working Days per Year</p>';
        
        // ===== B2B does NOT use updateBusinessOutputs() =====
        // B2B profit calculations are done inline above
        // updateBusinessOutputs() is Employee-only business metrics
        
        // ===== HIDE SWISS SALARY BENCHMARK IN B2B MODE =====
        document.getElementById('salary-benchmark-card').style.display = 'none';
        
        // Show results section
        document.getElementById('results-section').style.display = 'block';
        
        // Scroll to results
        document.getElementById('results-section').scrollIntoView({ 
            behavior: 'smooth', 
            block: 'start' 
        });
    },
    
    /**
     * Display calculation results
     */
    displayResults(results) {
        // ===== MODE ISOLATION: Guard for employee mode only =====
        if (activeMode !== 'employee') return;
        
        // ===== MODE ISOLATION: All DOM updates scoped to #results-section =====
        // Display payroll summary
        this.displayPayrollSummary(results);
        
        // Display salary benchmark (Switzerland only)
        this.displaySalaryBenchmark(results);
        
        // Display breakdown table
        this.displayBreakdownTable(results);
        
        // Display formulas
        this.displayFormulas(results);
        
        // Display business outputs
        this.updateBusinessOutputs();
        
        // Show all cards for Employee mode
        // ===== BROWSER COMPATIBILITY: Use .closest() instead of :has() for Safari/Firefox =====
        document.getElementById('business-outputs').closest('.results-card').style.display = 'block';
        document.getElementById('breakdown-table').closest('.results-card').style.display = 'block';
        document.getElementById('formula-content').closest('.results-card').style.display = 'block';
        
        // Show results section
        document.getElementById('results-section').style.display = 'block';
        
        // Scroll to results
        document.getElementById('results-section').scrollIntoView({ 
            behavior: 'smooth', 
            block: 'start' 
        });
    },
    
    /**
     * Display payroll summary
     */
    displayPayrollSummary(results) {
        // ===== MODE ISOLATION: Guard for employee mode only =====
        if (activeMode !== 'employee') return;
        
        const originalCurr = results.currency;
        const isConverted = results.exchangeRate !== undefined;
        
        // Format functions for both currencies
        const formatOriginal = (val) => FXService.formatCurrency(val, originalCurr);
        const formatEUR = (val) => FXService.formatCurrency(val, 'EUR');
        
        // Helper to get EUR value
        const getEURValue = (field) => {
            if (isConverted && results[field + 'EUR'] !== undefined) {
                return results[field + 'EUR'];
            }
            return null;
        };
        
        // Build HTML with three lines: Monthly, Yearly, Other
        let html = '<div class="payroll-summary-section">';
        
        // === MONTHLY LINE ===
        html += '<div class="payroll-line">';
        html += '<h3 class="payroll-line-title">Monthly</h3>';
        html += '<div class="payroll-line-items">';
        
        // Net Salary
        html += `
            <div class="payroll-item highlight">
                <label>
                    Net Salary 
                    <span class="info-icon" title="After all deductions (taxes + contributions). Formula: Gross - Employee Contributions - Income Tax">?</span>
                </label>
                <div class="value-group">
                    <div class="value">${formatOriginal(results.netSalary)}</div>
                    ${isConverted ? `<div class="value-eur">${formatEUR(getEURValue('netSalary'))}</div>` : ''}
                </div>
            </div>
        `;
        
        // Gross Salary
        html += `
            <div class="payroll-item">
                <label>
                    Gross Salary 
                    <span class="info-icon" title="Monthly gross salary (before deductions)">?</span>
                </label>
                <div class="value-group">
                    <div class="value">${formatOriginal(results.grossSalary)}</div>
                    ${isConverted ? `<div class="value-eur">${formatEUR(getEURValue('grossSalary'))}</div>` : ''}
                </div>
            </div>
        `;
        
        // Total Cost
        html += `
            <div class="payroll-item">
                <label>
                    Total Company Cost 
                    <span class="info-icon" title="Total monthly company cost. Formula: Gross + Employer Contributions + Other Benefits">?</span>
                </label>
                <div class="value-group">
                    <div class="value">${formatOriginal(results.totalCost)}</div>
                    ${isConverted ? `<div class="value-eur">${formatEUR(getEURValue('totalCost'))}</div>` : ''}
                </div>
            </div>
        `;
        
        html += '</div></div>'; // Close monthly line
        
        // === YEARLY LINE ===
        html += '<div class="payroll-line">';
        html += '<h3 class="payroll-line-title">Yearly</h3>';
        html += '<div class="payroll-line-items">';
        
        // Annual Net
        const annualNet = isConverted && results.annualEUR ? results.annualEUR.netSalary : results.annual.netSalary;
        html += `
            <div class="payroll-item">
                <label>
                    Net Salary
                    <span class="info-icon" title="Annual net salary = Monthly Net × 12">?</span>
                </label>
                <div class="value-group">
                    <div class="value">${formatOriginal(results.annual.netSalary)}</div>
                    ${isConverted ? `<div class="value-eur">${formatEUR(annualNet)}</div>` : ''}
                </div>
            </div>
        `;
        
        // Annual Gross
        const annualGross = isConverted && results.annualEUR ? results.annualEUR.grossSalary : results.annual.grossSalary;
        html += `
            <div class="payroll-item">
                <label>
                    Gross Salary
                    <span class="info-icon" title="Annual gross salary = Monthly Gross × 12">?</span>
                </label>
                <div class="value-group">
                    <div class="value">${formatOriginal(results.annual.grossSalary)}</div>
                    ${isConverted ? `<div class="value-eur">${formatEUR(annualGross)}</div>` : ''}
                </div>
            </div>
        `;
        
        // Annual Total Cost
        const annualCost = isConverted && results.annualEUR ? results.annualEUR.totalCost : results.annual.totalCost;
        html += `
            <div class="payroll-item">
                <label>
                    Total Company Cost
                    <span class="info-icon" title="Annual total company cost = Monthly Total Cost × 12">?</span>
                </label>
                <div class="value-group">
                    <div class="value">${formatOriginal(results.annual.totalCost)}</div>
                    ${isConverted ? `<div class="value-eur">${formatEUR(annualCost)}</div>` : ''}
                </div>
            </div>
        `;
        
        html += '</div></div>'; // Close yearly line
        
        // === OTHER LINE ===
        html += '<div class="payroll-line">';
        html += '<h3 class="payroll-line-title">Other</h3>';
        html += '<div class="payroll-line-items">';
        
        // Take-Home Pay
        html += `
            <div class="payroll-item">
                <label>
                    Take-Home Pay 
                    <span class="info-icon" title="Net salary actually received by employee (after all deductions)">?</span>
                </label>
                <div class="value-group">
                    <div class="value">${formatOriginal(results.takeHome)}</div>
                    ${isConverted ? `<div class="value-eur">${formatEUR(getEURValue('takeHome'))}</div>` : ''}
                </div>
            </div>
        `;
        
        // Employee Contributions
        html += `
            <div class="payroll-item">
                <label>
                    Employee Contributions 
                    <span class="info-icon" title="Total social contributions deducted from gross salary (CAS, CASS, pension, etc.)">?</span>
                </label>
                <div class="value-group">
                    <div class="value">${formatOriginal(results.employeeContributions.total)}</div>
                    ${isConverted && results.employeeContributionsEUR ? `<div class="value-eur">${formatEUR(results.employeeContributionsEUR.total)}</div>` : ''}
                </div>
            </div>
        `;
        
        // Employer Contributions
        html += `
            <div class="payroll-item">
                <label>
                    Employer Contributions 
                    <span class="info-icon" title="Total employer social costs added on top of gross salary (CAM, unemployment, etc.)">?</span>
                </label>
                <div class="value-group">
                    <div class="value">${formatOriginal(results.employerContributions.total)}</div>
                    ${isConverted && results.employerContributionsEUR ? `<div class="value-eur">${formatEUR(results.employerContributionsEUR.total)}</div>` : ''}
                </div>
            </div>
        `;
        
        // Meal Vouchers (if applicable)
        if (results.mealVouchers > 0) {
            html += `
                <div class="payroll-item">
                    <label>Meal Vouchers</label>
                    <div class="value-group">
                        <div class="value">${formatOriginal(results.mealVouchers)}</div>
                    </div>
                </div>
            `;
        }
        
        html += '</div></div>'; // Close other line
        html += '</div>'; // Close summary section
        
        document.getElementById('payroll-summary').innerHTML = html;
    },
    
    /**
     * Display Salary Benchmark (Switzerland Employee Mode Only)
     */
    displaySalaryBenchmark(results) {
        // ===== MODE ISOLATION: Only show for Employee mode in Switzerland =====
        if (activeMode !== 'employee') {
            document.getElementById('salary-benchmark-card').style.display = 'none';
            return;
        }
        
        const country = document.getElementById('country-select')?.value;
        if (country !== 'CH') {
            document.getElementById('salary-benchmark-card').style.display = 'none';
            return;
        }
        
        // Get user input role
        const userRole = document.getElementById('employee-role')?.value?.trim();
        if (!userRole || userRole === '') {
            document.getElementById('salary-benchmark-card').style.display = 'none';
            return;
        }
        
        // Get user's annual gross salary for comparison
        const userSalary = results.annualGross || (results.grossSalary * 13); // Swiss 13-month salary
        
        // Get benchmark data
        const benchmark = SalaryBenchmark.getBenchmarkText(userRole, userSalary);
        
        // Hide card if no match found
        if (!benchmark.found) {
            let html = `
                <div class="benchmark-not-found">
                    <h3><i class="fas fa-info-circle"></i> ${benchmark.message}</h3>
                    ${benchmark.suggestion ? `
                        <div class="benchmark-suggestion">
                            <strong>Suggestion:</strong> ${benchmark.suggestion}
                        </div>
                    ` : ''}
                </div>
            `;
            document.getElementById('salary-benchmark').innerHTML = html;
            document.getElementById('salary-benchmark-card').style.display = 'block';
            return;
        }
        
        // Build benchmark display HTML
        let html = '';
        
        // Header with match information
        if (benchmark.message) {
            html += `
                <div class="benchmark-note">
                    <i class="fas fa-lightbulb"></i> ${benchmark.message}
                </div>
            `;
        }
        
        html += '<div class="benchmark-data">';
        
        // Role title
        html += `
            <div class="benchmark-role-title">
                ${benchmark.matchedRole}
                <span class="benchmark-match-type match-${benchmark.matchType}">
                    ${benchmark.matchType === 'exact' ? '✓ Exact Match' : 
                      benchmark.matchType === 'similar' ? '≈ Similar Match' : 
                      '~ Fuzzy Match'}
                </span>
            </div>
        `;
        
        // Salary range metrics
        html += '<div class="benchmark-salary-range">';
        
        html += `
            <div class="salary-metric min">
                <div class="salary-metric-label">Minimum</div>
                <div class="salary-metric-value">${SalaryBenchmark.formatCurrency(benchmark.data.min)}</div>
            </div>
        `;
        
        html += `
            <div class="salary-metric median">
                <div class="salary-metric-label">Median (Market)</div>
                <div class="salary-metric-value">${SalaryBenchmark.formatCurrency(benchmark.data.median)}</div>
            </div>
        `;
        
        html += `
            <div class="salary-metric max">
                <div class="salary-metric-label">Maximum</div>
                <div class="salary-metric-value">${SalaryBenchmark.formatCurrency(benchmark.data.max)}</div>
            </div>
        `;
        
        html += '</div>'; // Close salary-range
        
        // Visual range bar
        if (userSalary) {
            const position = ((userSalary - benchmark.data.min) / (benchmark.data.max - benchmark.data.min)) * 100;
            const clampedPosition = Math.max(0, Math.min(100, position));
            
            html += `
                <div class="benchmark-visual-range">
                    <div class="range-bar-container">
                        <div class="user-salary-marker" style="left: ${clampedPosition}%;"></div>
                    </div>
                    <div class="range-labels">
                        <span>${SalaryBenchmark.formatCurrency(benchmark.data.min)}</span>
                        <span>${SalaryBenchmark.formatCurrency(benchmark.data.median)}</span>
                        <span>${SalaryBenchmark.formatCurrency(benchmark.data.max)}</span>
                    </div>
                </div>
            `;
        }
        
        // Comparison text
        if (benchmark.comparison) {
            html += `
                <div class="benchmark-comparison">
                    <div class="comparison-title">Your Position in Market Range:</div>
                    <div class="comparison-text">${benchmark.comparison}</div>
                </div>
            `;
        }
        
        // Metadata
        html += `
            <div class="benchmark-metadata">
                ${benchmark.data.experience ? `
                    <div class="metadata-item">
                        <i class="fas fa-briefcase"></i>
                        <span>Experience Level: ${benchmark.data.experience}</span>
                    </div>
                ` : ''}
                ${benchmark.data.source ? `
                    <div class="metadata-item">
                        <i class="fas fa-calendar"></i>
                        <span>Data Source: ${benchmark.data.source}</span>
                    </div>
                ` : ''}
                <div class="metadata-item">
                    <i class="fas fa-map-marker-alt"></i>
                    <span>Location: Switzerland</span>
                </div>
            </div>
        `;
        
        html += '</div>'; // Close benchmark-data
        
        document.getElementById('salary-benchmark').innerHTML = html;
        document.getElementById('salary-benchmark-card').style.display = 'block';
    },
    
    /**
     * Display breakdown table
     */
    displayBreakdownTable(results) {
        // ===== MODE ISOLATION: Guard for employee mode only =====
        if (activeMode !== 'employee') return;
        
        const breakdown = Calculator.getBreakdown(results);
        const originalCurr = results.currency;
        const showEUR = originalCurr !== 'EUR';
        
        const formatOriginal = (val) => FXService.formatCurrency(val, originalCurr);
        const formatEUR = (val) => {
            if (!showEUR) return '';
            const exchangeRate = parseFloat(document.getElementById('exchange-rate-input').value) || 1;
            return FXService.formatCurrency(val / exchangeRate, 'EUR');
        };
        
        let tableHTML = `
            <table class="breakdown-table">
                <thead>
                    <tr>
                        <th>Category / Item</th>
                        <th class="text-right">Amount (${originalCurr})</th>
                        ${showEUR ? `<th class="text-right">Amount (EUR)</th>` : ''}
                    </tr>
                </thead>
                <tbody>
        `;
        
        breakdown.forEach(category => {
            tableHTML += `
                <tr class="category-header">
                    <td colspan="${showEUR ? '3' : '2'}">${category.category}</td>
                </tr>
            `;
            
            category.items.forEach(item => {
                tableHTML += `
                    <tr>
                        <td>&nbsp;&nbsp;&nbsp;${item.name}</td>
                        <td class="text-right">${formatOriginal(item.amount)}</td>
                        ${showEUR ? `<td class="text-right">${formatEUR(item.amount)}</td>` : ''}
                    </tr>
                `;
            });
            
            tableHTML += `
                <tr class="total-row">
                    <td><strong>Total ${category.category}</strong></td>
                    <td class="text-right"><strong>${formatOriginal(category.total)}</strong></td>
                    ${showEUR ? `<td class="text-right"><strong>${formatEUR(category.total)}</strong></td>` : ''}
                </tr>
            `;
        });
        
        tableHTML += `
                </tbody>
            </table>
        `;
        
        if (results.irpfDisclaimer) {
            tableHTML += `<p class="mt-1" style="font-size: 0.85rem; font-style: italic; color: var(--deep-steel-blue);">${results.irpfDisclaimer}</p>`;
        }
        
        if (results.incomeTaxNote) {
            tableHTML += `<p class="mt-1" style="font-size: 0.85rem; font-style: italic; color: var(--deep-steel-blue);">${results.incomeTaxNote}</p>`;
        }
        
        document.getElementById('breakdown-table').innerHTML = tableHTML;
        
        // Add class to parent card for print page break targeting
        const breakdownCard = document.getElementById('breakdown-table').closest('.results-card');
        if (breakdownCard) {
            breakdownCard.classList.add('breakdown-card');
        }
    },
    
    /**
     * Update business outputs
     * 
     * ===== EMPLOYEE-ONLY BUSINESS LOGIC =====
     * This function calculates staffing/placement business metrics derived from EMPLOYEE payroll data.
     * 
     * It computes:
     * - Daily cost rate (from employee total cost)
     * - Daily placement rate (based on margin or fixed amount)
     * - Daily and monthly profit/margin
     * 
     * RULES:
     * - Only called from Employee mode (guarded by activeMode check)
     * - Only reads from this.employeeResults (never b2bResults)
     * - Only reads Employee UI inputs (margin-percentage, fixed-daily-amount, reference-currency)
     * - Never called from B2B flow
     * - B2B has its own separate profit calculations in displayB2BResults()
     */
    async updateBusinessOutputs() {
        // ===== MODE ISOLATION: Only update business outputs for employee mode =====
        // B2B mode doesn't use this business outputs section
        if (activeMode !== 'employee') return;
        
        // ===== STATE ISOLATION: Only read employee results =====
        if (!this.employeeResults) return;
        
        // Get inputs
        const marginInputType = document.getElementById('margin-input-type').value;
        const referenceCurrency = document.getElementById('reference-currency').value;
        const originalCurr = this.employeeResults.currency;
        
        // Get exchange rate for conversion
        const exchangeRate = parseFloat(document.getElementById('exchange-rate-input').value) || 1;
        
        // Get all exchange rates from FXService for proper conversion
        let ronPerEur = 4.97; // Fallback
        let chfPerEur = 0.93; // Fallback
        try {
            const ratesData = await FXService.getRates();
            if (ratesData && ratesData.rates) {
                ronPerEur = ratesData.rates.RON || 4.97;
                chfPerEur = ratesData.rates.CHF || 0.93;
            }
        } catch (error) {
            console.warn('Could not fetch rates, using fallback values');
        }
        
        // Working days are ALWAYS 220 (fixed, never scaled by occupation rate)
        const WORKING_DAYS = 220;
        
        // Calculate daily cost from total annual cost
        // ===== STATE ISOLATION: Only read from employeeResults =====
        const annualCost = this.employeeResults.annual.totalCost;
        const dailyCost = annualCost / WORKING_DAYS;
        
        // Convert daily cost to reference currency if needed
        // Rule: Always convert via RON as intermediate
        // Formula: valueInput -> valueRON -> valueTarget
        let dailyCostInRefCurrency = dailyCost;
        if (originalCurr !== referenceCurrency) {
            // Step 1: Convert original currency to RON
            let dailyCostInRON = dailyCost;
            if (originalCurr === 'EUR') {
                // EUR to RON: multiply by RON per EUR
                dailyCostInRON = dailyCost * ronPerEur;
            } else if (originalCurr === 'CHF') {
                // CHF to RON: CHF -> EUR -> RON
                // CHF to EUR: divide by CHF per EUR
                // EUR to RON: multiply by RON per EUR
                dailyCostInRON = (dailyCost / chfPerEur) * ronPerEur;
            }
            // If originalCurr === 'RON', dailyCostInRON = dailyCost (RON per RON = 1)
            
            // Step 2: Convert RON to target currency
            if (referenceCurrency === 'EUR') {
                // RON to EUR: divide by RON per EUR
                dailyCostInRefCurrency = dailyCostInRON / ronPerEur;
            } else if (referenceCurrency === 'CHF') {
                // RON to CHF: RON -> EUR -> CHF
                // RON to EUR: divide by RON per EUR
                // EUR to CHF: multiply by CHF per EUR
                dailyCostInRefCurrency = (dailyCostInRON / ronPerEur) * chfPerEur;
            }
        }
        
        const formatRef = (val) => FXService.formatCurrency(val, referenceCurrency);
        
        let html = `
            <div class="business-output-item">
                <label>
                    Daily Cost Rate 
                    <span class="info-icon" title="Calculated as: Annual Total Cost ÷ 220 working days">?</span>
                </label>
                <div class="value">${formatRef(dailyCostInRefCurrency)}</div>
            </div>
        `;
        
        // Calculate based on margin type
        if (marginInputType === 'percentage') {
            const targetMarginPercent = parseFloat(document.getElementById('margin-percentage').value) || 0;
            
            if (targetMarginPercent > 0 && targetMarginPercent < 100) {
                const targetMargin = targetMarginPercent / 100;
                
                // TRUE PROFIT MARGIN formula (not markup)
                // daily_placement_rate = daily_cost_rate / (1 - target_margin)
                const dailyPlacementRate = dailyCostInRefCurrency / (1 - targetMargin);
                const dailyProfit = dailyPlacementRate - dailyCostInRefCurrency;
                
                // Verify the margin (should equal target margin)
                const displayedMarginPercent = (dailyProfit / dailyPlacementRate) * 100;
                
                html += `
                    <div class="business-output-item">
                        <label>
                            Daily Placement Rate 
                            <span class="info-icon" title="Calculated as: Daily Cost ÷ (1 - ${targetMarginPercent}%)">?</span>
                        </label>
                        <div class="value">${formatRef(dailyPlacementRate)}</div>
                    </div>
                    <div class="business-output-item">
                        <label>
                            Daily Profit/Margin 
                            <span class="info-icon" title="Profit = Placement Rate - Cost. Margin = (Profit ÷ Placement Rate) × 100">?</span>
                        </label>
                        <div class="value">${formatRef(dailyProfit)} (${Math.round(displayedMarginPercent)}%)</div>
                    </div>
                `;
            }
        } else {
            // Fixed amount
            const fixedDailyAmount = parseFloat(document.getElementById('fixed-daily-amount').value) || 0;
            
            if (fixedDailyAmount > 0) {
                const dailyMargin = fixedDailyAmount - dailyCostInRefCurrency;
                const marginPercent = (dailyMargin / fixedDailyAmount) * 100;
                
                html += `
                    <div class="business-output-item">
                        <label>
                            Daily Placement Rate (Fixed)
                            <span class="info-icon" title="Fixed amount entered by user">?</span>
                        </label>
                        <div class="value">${formatRef(fixedDailyAmount)}</div>
                    </div>
                    <div class="business-output-item">
                        <label>
                            Daily Margin 
                            <span class="info-icon" title="Calculated as: (Profit ÷ Placement Rate) × 100. Profit = Fixed Amount - Daily Cost">?</span>
                        </label>
                        <div class="value">${formatRef(dailyMargin)} (${Math.round(marginPercent)}%)</div>
                    </div>
                `;
            }
        }
        
        document.getElementById('business-outputs').innerHTML = html;
    },
    
    /**
     * Display formulas
     */
    displayFormulas(results) {
        // ===== MODE ISOLATION: Guard for employee mode only =====
        if (activeMode !== 'employee') return;
        
        if (!results.formulas || results.formulas.length === 0) {
            document.getElementById('formula-content').innerHTML = '<p>No formula details available.</p>';
            return;
        }
        
        let html = '';
        
        results.formulas.forEach(section => {
            html += `
                <div class="formula-section">
                    <h3>${section.category}</h3>
            `;
            
            section.items.forEach(item => {
                html += `
                    <div class="formula-item">
                        <div class="formula-name">${item.name}</div>
                        <div class="formula-expression">${item.formula}</div>
                        <div class="formula-result">= ${item.result !== null && item.result !== undefined && !isNaN(item.result) ? item.result.toFixed(2) : 'N/A'} ${results.currency}</div>
                    </div>
                `;
            });
            
            html += `</div>`;
        });
        
        document.getElementById('formula-content').innerHTML = html;
    },
    
    /**
     * Prepare print view - add input summary
     */
    preparePrintView() {
        // Remove any existing print header and summary
        const existingHeader = document.querySelector('.print-header');
        if (existingHeader) {
            existingHeader.remove();
        }
        const existingSummary = document.querySelector('.print-input-summary');
        if (existingSummary) {
            existingSummary.remove();
        }
        
        // ===== CREATE PRINT HEADER WITH TSG LOGO =====
        const headerDiv = document.createElement('div');
        headerDiv.className = 'print-header';
        headerDiv.innerHTML = `
            <img src="images/tsg-logo.png" alt="TSG Logo" class="print-logo">
        `;
        
        // Create print input summary div
        const summaryDiv = document.createElement('div');
        summaryDiv.className = 'print-input-summary';
        
        let summaryHTML = '<h3>Inputs Summary</h3>';
        
        // ===== STATE ISOLATION: Detect which mode we're in =====
        const isEmployeeMode = activeMode === 'employee';
        const isB2BMode = activeMode === 'b2b';
        const isAllocationMode = activeMode === 'allocation';
        
        // ===== ENGAGEMENT TYPE: Display for all modes =====
        let engagementTypeLabel = '';
        if (isEmployeeMode) {
            engagementTypeLabel = 'Employee (TSG Payroll)';
        } else if (isB2BMode) {
            engagementTypeLabel = 'B2B (Independent Contractor)';
        } else if (isAllocationMode) {
            engagementTypeLabel = 'Allocation (Multi-Client Profitability)';
        }
        
        if (engagementTypeLabel) {
            summaryHTML += `
                <div class="input-row">
                    <span class="input-label">Engagement Type:</span>
                    <span class="input-value">${engagementTypeLabel}</span>
                </div>
            `;
        }
        
        // ===== MODE ISOLATION: Hide sections from other modes =====
        // When printing Employee mode, hide B2B and Allocation results
        // When printing B2B mode, hide Employee and Allocation results
        // When printing Allocation mode, hide Employee and B2B results
        document.body.classList.remove('print-employee-mode', 'print-b2b-mode', 'print-allocation-mode', 'print-switzerland');
        if (isEmployeeMode) {
            document.body.classList.add('print-employee-mode');
            
            // Add Switzerland class if country is Switzerland
            const countryCode = document.getElementById('country-select')?.value;
            if (countryCode === 'CH') {
                document.body.classList.add('print-switzerland');
            }
        } else if (isB2BMode) {
            document.body.classList.add('print-b2b-mode');
        } else if (isAllocationMode) {
            document.body.classList.add('print-allocation-mode');
        }
        
        // Get country - only show in Employee mode
        if (isEmployeeMode) {
            const country = document.getElementById('country-select')?.selectedOptions[0]?.text || 'N/A';
            summaryHTML += `
                <div class="input-row">
                    <span class="input-label">Payroll Country:</span>
                    <span class="input-value">${country}</span>
                </div>
            `;
        }
        
        // Employee Mode inputs
        if (isEmployeeMode) {
            // Employee Name
            const employeeName = document.getElementById('employee-name')?.value;
            if (employeeName) {
                summaryHTML += `
                    <div class="input-row">
                        <span class="input-label">Employee Name:</span>
                        <span class="input-value">${employeeName}</span>
                    </div>
                `;
            }
            
            // Date of Birth
            const dateOfBirth = document.getElementById('date-of-birth')?.value;
            if (dateOfBirth) {
                summaryHTML += `
                    <div class="input-row">
                        <span class="input-label">Date of Birth:</span>
                        <span class="input-value">${dateOfBirth}</span>
                    </div>
                `;
            }
            
            // Role / Position
            const employeeRole = document.getElementById('employee-role')?.value;
            if (employeeRole) {
                summaryHTML += `
                    <div class="input-row">
                        <span class="input-label">Role / Position:</span>
                        <span class="input-value">${employeeRole}</span>
                    </div>
                `;
            }
        }
        
        // B2B Mode inputs
        if (isB2BMode) {
            // Employee Name (B2B)
            const employeeName = document.getElementById('b2b-employee-name')?.value;
            if (employeeName) {
                summaryHTML += `
                    <div class="input-row">
                        <span class="input-label">Employee Name:</span>
                        <span class="input-value">${employeeName}</span>
                    </div>
                `;
            }
            
            // Date of Birth (B2B)
            const dateOfBirth = document.getElementById('b2b-date-of-birth')?.value;
            if (dateOfBirth) {
                summaryHTML += `
                    <div class="input-row">
                        <span class="input-label">Date of Birth:</span>
                        <span class="input-value">${dateOfBirth}</span>
                    </div>
                `;
            }
            
            // Role / Position (B2B)
            const employeeRole = document.getElementById('b2b-employee-role')?.value;
            if (employeeRole) {
                summaryHTML += `
                    <div class="input-row">
                        <span class="input-label">Role / Position:</span>
                        <span class="input-value">${employeeRole}</span>
                    </div>
                `;
            }
            
            // B2B specific fields - only show if filled
            const contractorCost = document.getElementById('b2b-daily-cost')?.value;
            const costCurrency = document.getElementById('b2b-cost-currency')?.value || 'EUR';
            const costUnit = document.getElementById('b2b-cost-unit')?.value || 'day';
            const costUnitLabel = costUnit === 'hour' ? 'per Hour' : 'per Day';
            
            // Get pricing mode to conditionally show contractor cost
            const pricingMode = document.getElementById('b2b-pricing-mode')?.value;
            
            // Only show Contractor Cost if NOT in budget_margin mode
            if (contractorCost && pricingMode !== 'budget_margin') {
                summaryHTML += `
                    <div class="input-row">
                        <span class="input-label">Contractor Cost (${costUnitLabel}):</span>
                        <span class="input-value">${contractorCost} ${costCurrency}</span>
                    </div>
                `;
            }
            
            const workingDays = document.getElementById('b2b-working-days')?.value;
            if (workingDays) {
                summaryHTML += `
                    <div class="input-row">
                        <span class="input-label">Working Days per Year:</span>
                        <span class="input-value">${workingDays} days</span>
                    </div>
                `;
            }
            
            // Pricing mode and margin/rate
            if (pricingMode === 'margin') {
                const targetMargin = document.getElementById('b2b-target-margin')?.value;
                if (targetMargin) {
                    summaryHTML += `
                        <div class="input-row">
                            <span class="input-label">Target Margin %:</span>
                            <span class="input-value">${targetMargin}%</span>
                        </div>
                    `;
                }
            } else if (pricingMode === 'rate') {
                const clientRate = document.getElementById('b2b-client-rate')?.value;
                const clientRateCurrency = document.getElementById('b2b-client-rate-currency')?.value || 'EUR';
                if (clientRate) {
                    summaryHTML += `
                        <div class="input-row">
                            <span class="input-label">Client Daily Rate:</span>
                            <span class="input-value">${clientRate} ${clientRateCurrency}</span>
                        </div>
                    `;
                }
            } else if (pricingMode === 'budget_margin') {
                const clientBudget = document.getElementById('b2b-client-budget')?.value;
                const clientBudgetCurrency = document.getElementById('b2b-client-budget-currency')?.value || 'EUR';
                const targetMargin = document.getElementById('b2b-budget-target-margin')?.value;
                
                if (clientBudget) {
                    summaryHTML += `
                        <div class="input-row">
                            <span class="input-label">Client Budget per Day:</span>
                            <span class="input-value">${clientBudget} ${clientBudgetCurrency}</span>
                        </div>
                    `;
                }
                
                if (targetMargin) {
                    summaryHTML += `
                        <div class="input-row">
                            <span class="input-label">Target Margin %:</span>
                            <span class="input-value">${targetMargin}%</span>
                        </div>
                    `;
                }
            }
            
            // Add B2B Outputs Summary
            if (this.b2bResults && this.b2bResults.isB2B) {
                summaryHTML += '<h3 style="margin-top: 1.5rem;">Outputs Summary</h3>';
                
                // Get display currency for results
                const displayCurrency = this.b2bResults.displayCurrency || this.b2bResults.costCurrency;
                const costCurrency = this.b2bResults.costCurrency;
                
                // Helper to convert if needed
                const convertValue = async (value) => {
                    if (displayCurrency === costCurrency) {
                        return value;
                    }
                    
                    // Get FX rates
                    const ratesData = await FXService.getRates();
                    const eurToFrom = ratesData.rates[costCurrency] || 1;
                    const eurToDisplay = ratesData.rates[displayCurrency] || 1;
                    const inEur = value / eurToFrom;
                    return inEur * eurToDisplay;
                };
                
                // Helper to format value
                const formatValue = async (value) => {
                    const converted = await convertValue(value);
                    return FXService.formatCurrency(converted, displayCurrency);
                };
                
                // We need to make this synchronous for the print flow, so we'll use a promise wrapper
                // For print, we'll use the already-converted values from results if displayCurrency is set
                
                // Daily outputs
                summaryHTML += `
                    <div class="input-row" style="margin-top: 0.5rem;">
                        <span class="input-label" style="font-weight: 600;">Daily:</span>
                    </div>
                    <div class="input-row">
                        <span class="input-label" style="padding-left: 1rem;">Cost:</span>
                        <span class="input-value">${FXService.formatCurrency(this.b2bResults.dailyCost, costCurrency)}</span>
                    </div>
                    <div class="input-row">
                        <span class="input-label" style="padding-left: 1rem;">Revenue:</span>
                        <span class="input-value">${FXService.formatCurrency(this.b2bResults.dailyRevenue, costCurrency)}</span>
                    </div>
                    <div class="input-row">
                        <span class="input-label" style="padding-left: 1rem;">Profit:</span>
                        <span class="input-value">${FXService.formatCurrency(this.b2bResults.dailyProfit, costCurrency)}</span>
                    </div>
                    <div class="input-row">
                        <span class="input-label" style="padding-left: 1rem;">Margin:</span>
                        <span class="input-value">${this.b2bResults.marginPercent.toFixed(0)}%</span>
                    </div>
                `;
                
                // Monthly outputs
                summaryHTML += `
                    <div class="input-row" style="margin-top: 0.5rem;">
                        <span class="input-label" style="font-weight: 600;">Monthly:</span>
                    </div>
                    <div class="input-row">
                        <span class="input-label" style="padding-left: 1rem;">Cost:</span>
                        <span class="input-value">${FXService.formatCurrency(this.b2bResults.monthlyCost, costCurrency)}</span>
                    </div>
                    <div class="input-row">
                        <span class="input-label" style="padding-left: 1rem;">Revenue:</span>
                        <span class="input-value">${FXService.formatCurrency(this.b2bResults.monthlyRevenue, costCurrency)}</span>
                    </div>
                    <div class="input-row">
                        <span class="input-label" style="padding-left: 1rem;">Profit:</span>
                        <span class="input-value">${FXService.formatCurrency(this.b2bResults.monthlyProfit, costCurrency)}</span>
                    </div>
                `;
                
                // Annual outputs
                summaryHTML += `
                    <div class="input-row" style="margin-top: 0.5rem;">
                        <span class="input-label" style="font-weight: 600;">Annual:</span>
                    </div>
                    <div class="input-row">
                        <span class="input-label" style="padding-left: 1rem;">Cost:</span>
                        <span class="input-value">${FXService.formatCurrency(this.b2bResults.annualCost, costCurrency)}</span>
                    </div>
                    <div class="input-row">
                        <span class="input-label" style="padding-left: 1rem;">Revenue:</span>
                        <span class="input-value">${FXService.formatCurrency(this.b2bResults.annualRevenue, costCurrency)}</span>
                    </div>
                    <div class="input-row">
                        <span class="input-label" style="padding-left: 1rem;">Profit:</span>
                        <span class="input-value">${FXService.formatCurrency(this.b2bResults.annualProfit, costCurrency)}</span>
                    </div>
                `;
            }
        }
        
        // Allocation Mode inputs
        if (isAllocationMode) {
            // Base parameters
            const salary100 = document.getElementById('allocation-salary-100')?.value;
            if (salary100) {
                summaryHTML += `
                    <div class="input-row">
                        <span class="input-label">Salary at 100%:</span>
                        <span class="input-value">${parseFloat(salary100).toLocaleString('en-US')} CHF</span>
                    </div>
                `;
            }
            
            const engagement = document.getElementById('allocation-engagement-pct')?.value;
            if (engagement) {
                summaryHTML += `
                    <div class="input-row">
                        <span class="input-label">Engagement %:</span>
                        <span class="input-value">${engagement}%</span>
                    </div>
                `;
            }
            
            const multiplier = document.getElementById('allocation-multiplier')?.value;
            if (multiplier) {
                summaryHTML += `
                    <div class="input-row">
                        <span class="input-label">Employer Multiplier:</span>
                        <span class="input-value">${multiplier}×</span>
                    </div>
                `;
            }
            
            const workingDays = document.getElementById('allocation-working-days')?.value;
            if (workingDays) {
                summaryHTML += `
                    <div class="input-row">
                        <span class="input-label">Working Days/Year:</span>
                        <span class="input-value">${workingDays}</span>
                    </div>
                `;
            }
            
            // Client allocations
            if (this.allocationClients && this.allocationClients.length > 0) {
                summaryHTML += '<h3 style="margin-top: 1.5rem;">Client Allocations</h3>';
                this.allocationClients.forEach(client => {
                    summaryHTML += `
                        <div class="input-row">
                            <span class="input-label">${client.name}:</span>
                            <span class="input-value">${client.allocationPct}% @ ${client.dailyRate.toLocaleString('en-US')} CHF/day</span>
                        </div>
                    `;
                });
            }
        }
        
        summaryDiv.innerHTML = summaryHTML;
        
        // Insert at the beginning of appropriate results section
        let resultsSection;
        if (isAllocationMode) {
            resultsSection = document.getElementById('allocation-results-section');
        } else {
            resultsSection = document.getElementById('results-section');
        }
        
        if (resultsSection && resultsSection.firstChild) {
            // Insert header first
            resultsSection.insertBefore(headerDiv, resultsSection.firstChild);
            // Then insert summary after header
            resultsSection.insertBefore(summaryDiv, headerDiv.nextSibling);
        }
        
        // Add timestamp to results section for footer
        const now = new Date();
        const timestamp = now.toLocaleString('en-GB', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        });
        if (resultsSection) {
            resultsSection.setAttribute('data-print-date', timestamp);
        }
        
        // Add mode class to results section for print CSS targeting
        if (isB2BMode && resultsSection) {
            resultsSection.classList.add('b2b-mode');
        } else if (resultsSection) {
            resultsSection.classList.remove('b2b-mode');
        }
        
        return summaryDiv;
    },
    
    /**
     * Clean up print view
     */
    cleanupPrintView() {
        // Remove print header
        const headerDiv = document.querySelector('.print-header');
        if (headerDiv) {
            headerDiv.remove();
        }
        
        // Remove print summary
        const summaryDiv = document.querySelector('.print-input-summary');
        if (summaryDiv) {
            summaryDiv.remove();
        }
        
        // Remove mode classes from body
        document.body.classList.remove('print-employee-mode', 'print-b2b-mode', 'print-allocation-mode');
        
        // Remove B2B mode class from results section
        const resultsSection = document.getElementById('results-section');
        if (resultsSection) {
            resultsSection.classList.remove('b2b-mode');
        }
    },
    
    
    /**
     * Export to PDF
     */
    async exportToPDF() {
        try {
            const { jsPDF } = window.jspdf;
            const pdf = new jsPDF('p', 'mm', 'a4');
            
            const pageWidth = 210; // A4 width in mm
            const pageHeight = 297; // A4 height in mm
            const margin = 15;
            const contentWidth = pageWidth - (2 * margin);
            
            let yPosition = 20;
            
            // Add title
            pdf.setFontSize(16);
            pdf.setTextColor(237, 28, 36); // TSG Red
            pdf.text('TSG Salary & Cost Calculator', margin, yPosition);
            yPosition += 8;
            
            // Add date
            pdf.setFontSize(9);
            pdf.setTextColor(100, 100, 100);
            pdf.text(`Generated: ${new Date().toLocaleString()}`, margin, yPosition);
            yPosition += 10;
            
            // Add employee details if available
            const employeeName = document.getElementById('employee-name')?.value;
            const dateOfBirth = document.getElementById('date-of-birth')?.value;
            const employeeRole = document.getElementById('employee-role')?.value;
            
            if (employeeName || dateOfBirth || employeeRole) {
                pdf.setFontSize(11);
                pdf.setTextColor(17, 50, 77); // Deep Steel Blue
                pdf.setFont(undefined, 'bold');
                pdf.text('Employee Information', margin, yPosition);
                pdf.setFont(undefined, 'normal');
                yPosition += 7;
                
                pdf.setFontSize(9);
                pdf.setTextColor(0, 0, 0);
                
                if (employeeName) {
                    pdf.text(`Name: ${employeeName}`, margin + 5, yPosition);
                    yPosition += 5;
                }
                
                if (dateOfBirth) {
                    pdf.text(`Date of Birth: ${dateOfBirth}`, margin + 5, yPosition);
                    yPosition += 5;
                }
                
                if (employeeRole) {
                    pdf.text(`Role / Position: ${employeeRole}`, margin + 5, yPosition);
                    yPosition += 5;
                }
                
                yPosition += 5;
            }
            
            // Add results section as image
            const resultsSection = document.getElementById('results-section');
            
            // Capture as canvas with better quality
            const canvas = await html2canvas(resultsSection, {
                scale: 1.5,
                useCORS: true,
                logging: false,
                backgroundColor: '#ffffff'
            });
            
            const imgData = canvas.toDataURL('image/png');
            
            // Calculate dimensions to fit A4
            const imgWidth = contentWidth;
            const imgHeight = (canvas.height * imgWidth) / canvas.width;
            
            // Check if image fits on current page
            const availableHeight = pageHeight - yPosition - margin;
            
            if (imgHeight <= availableHeight) {
                // Fits on one page
                pdf.addImage(imgData, 'PNG', margin, yPosition, imgWidth, imgHeight);
            } else {
                // Split across multiple pages
                let remainingHeight = imgHeight;
                let sourceY = 0;
                
                while (remainingHeight > 0) {
                    const currentPageHeight = Math.min(remainingHeight, availableHeight);
                    const sourceHeight = (currentPageHeight / imgHeight) * canvas.height;
                    
                    // Create a temporary canvas for this page section
                    const tempCanvas = document.createElement('canvas');
                    tempCanvas.width = canvas.width;
                    tempCanvas.height = sourceHeight;
                    const tempCtx = tempCanvas.getContext('2d');
                    
                    tempCtx.drawImage(canvas, 0, sourceY, canvas.width, sourceHeight, 0, 0, canvas.width, sourceHeight);
                    
                    const tempImgData = tempCanvas.toDataURL('image/png');
                    pdf.addImage(tempImgData, 'PNG', margin, yPosition, imgWidth, currentPageHeight);
                    
                    remainingHeight -= currentPageHeight;
                    sourceY += sourceHeight;
                    
                    if (remainingHeight > 0) {
                        pdf.addPage();
                        yPosition = margin;
                    }
                }
            }
            
            // Save
            const filename = `TSG_Calculator_${new Date().toISOString().split('T')[0]}.pdf`;
            pdf.save(filename);
            
        } catch (error) {
            console.error('PDF export error:', error);
            this.showError('Failed to export PDF. Please try using the Print function instead.');
        }
    },
    
    /**
     * Show loading indicator
     */
    showLoading() {
        document.getElementById('loading-indicator').style.display = 'block';
    },
    
    /**
     * Hide loading indicator
     */
    hideLoading() {
        document.getElementById('loading-indicator').style.display = 'none';
    },
    
    /**
     * Show error message
     */
    showError(message) {
        document.getElementById('error-text').textContent = message;
        document.getElementById('error-message').style.display = 'flex';
    },
    
    /**
     * Hide error message
     */
    hideError() {
        document.getElementById('error-message').style.display = 'none';
    },
    
    /**
     * Hide results section
     * 
     * ===== STATE ISOLATION: Do NOT clear mode-specific results =====
     * This function only hides the UI, preserving employeeResults and b2bResults.
     * This allows switching modes without losing calculations.
     */
    hideResults() {
        document.getElementById('results-section').style.display = 'none';
        // DO NOT clear employeeResults or b2bResults here
        // Each mode's results persist until explicitly recalculated
        this.currentBusinessMetrics = null;
    },

    /**
     * ===== ALLOCATION MODE FUNCTIONS =====
     * All functions below are for Allocation mode ONLY
     * Fully isolated from Employee and B2B calculations
     */

    /**
     * Initialize allocation clients table with 2 default clients
     */
    initializeAllocationClients() {
        this.allocationClients = [
            { id: 1, name: 'Client A', allocationPct: 60, dailyRate: 1250 },
            { id: 2, name: 'Client B', allocationPct: 20, dailyRate: 1250 }
        ];
        this.renderAllocationClientsTable();
    },

    /**
     * Render allocation clients table
     */
    renderAllocationClientsTable() {
        const tableContainer = document.getElementById('allocation-clients-table');
        
        if (this.allocationClients.length === 0) {
            tableContainer.innerHTML = '<p class="help-text">No clients added yet. Click "Add Client" to start.</p>';
            return;
        }

        let html = `
            <table class="allocation-table">
                <thead>
                    <tr>
                        <th>Client Name</th>
                        <th>Allocation %</th>
                        <th>Daily Rate (CHF)</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
        `;

        this.allocationClients.forEach((client, index) => {
            html += `
                <tr data-client-id="${client.id}">
                    <td>
                        <input type="text" class="input-field" value="${client.name}" 
                               onchange="UI.updateClientField(${client.id}, 'name', this.value)">
                    </td>
                    <td>
                        <input type="number" class="input-field" value="${client.allocationPct}" 
                               min="0" max="100" step="0.1"
                               onchange="UI.updateClientField(${client.id}, 'allocationPct', this.value)">
                    </td>
                    <td>
                        <input type="number" class="input-field" value="${client.dailyRate}" 
                               min="0" step="0.01"
                               onchange="UI.updateClientField(${client.id}, 'dailyRate', this.value)">
                    </td>
                    <td>
                        <button type="button" class="btn-remove" onclick="UI.removeAllocationClient(${client.id})">
                            <i class="fas fa-trash"></i>
                        </button>
                    </td>
                </tr>
            `;
        });

        html += `
                </tbody>
            </table>
        `;

        tableContainer.innerHTML = html;
    },

    /**
     * Add a new allocation client
     */
    addAllocationClient() {
        const newId = this.allocationClients.length > 0 
            ? Math.max(...this.allocationClients.map(c => c.id)) + 1 
            : 1;
        
        this.allocationClients.push({
            id: newId,
            name: `Client ${String.fromCharCode(65 + this.allocationClients.length)}`,
            allocationPct: 0,
            dailyRate: 0
        });

        this.renderAllocationClientsTable();
    },

    /**
     * Remove an allocation client
     */
    removeAllocationClient(clientId) {
        this.allocationClients = this.allocationClients.filter(c => c.id !== clientId);
        this.renderAllocationClientsTable();
    },

    /**
     * Update a client field
     */
    updateClientField(clientId, field, value) {
        const client = this.allocationClients.find(c => c.id === clientId);
        if (client) {
            if (field === 'name') {
                client[field] = value;
            } else {
                client[field] = parseFloat(value) || 0;
            }
        }
    },

    /**
     * Perform allocation calculation
     */
    performAllocationCalculation() {
        // ===== MODE ISOLATION: Only run in allocation mode =====
        if (activeMode !== 'allocation') return;

        // Hide validation message
        const validationMsg = document.getElementById('allocation-validation-msg');
        validationMsg.style.display = 'none';

        // Get inputs
        const salary100 = parseFloat(document.getElementById('allocation-salary-100').value) || 0;
        const engagementPct = parseFloat(document.getElementById('allocation-engagement-pct').value) || 0;
        const employerMultiplier = parseFloat(document.getElementById('allocation-multiplier').value) || 1.20;
        const workingDays = parseInt(document.getElementById('allocation-working-days').value) || 220;

        // Prepare clients array
        const clients = this.allocationClients.map(c => ({
            name: c.name,
            allocationPct: c.allocationPct,
            dailyRate: c.dailyRate
        }));

        // Call AllocationCalculator
        const results = AllocationCalculator.calculate({
            salary100,
            engagementPct,
            employerMultiplier,
            workingDays,
            clients
        });

        if (!results.success) {
            // Show error
            validationMsg.textContent = results.error;
            validationMsg.style.display = 'block';
            validationMsg.className = 'validation-message error';
            return;
        }

        // ===== STATE ISOLATION: Store in allocationResults =====
        this.allocationResults = results;

        // Display results
        this.displayAllocationResults(results);
    },

    /**
     * Display allocation results
     */
    displayAllocationResults(results) {
        // ===== MODE ISOLATION: Only run in allocation mode =====
        if (activeMode !== 'allocation') return;

        const summaryDiv = document.getElementById('allocation-summary');
        const clientTableDiv = document.getElementById('allocation-client-table');

        // Summary metrics
        summaryDiv.innerHTML = `
            <div class="allocation-summary-grid">
                <div class="summary-item">
                    <span class="label">Engaged Salary (Annual)</span>
                    <span class="value">${AllocationCalculator.formatCurrency(results.calculated.engagedSalary)}</span>
                </div>
                <div class="summary-item">
                    <span class="label">Employer Cost (Annual)</span>
                    <span class="value">${AllocationCalculator.formatCurrency(results.calculated.employerCostAnnual)}</span>
                </div>
                <div class="summary-item highlight">
                    <span class="label">Base Daily Cost</span>
                    <span class="value">${AllocationCalculator.formatCurrency(results.calculated.baseDailyCost)}</span>
                </div>
                <div class="summary-item">
                    <span class="label">Total Revenue / Day</span>
                    <span class="value">${AllocationCalculator.formatCurrency(results.calculated.totalRevenuePerDay)}</span>
                </div>
                <div class="summary-item highlight">
                    <span class="label">Total Profit / Day</span>
                    <span class="value profit">${AllocationCalculator.formatCurrency(results.calculated.totalProfitPerDay)}</span>
                </div>
                <div class="summary-item">
                    <span class="label">Annual Profit</span>
                    <span class="value profit">${AllocationCalculator.formatCurrency(results.calculated.annualProfit)}</span>
                </div>
                <div class="summary-item">
                    <span class="label">Profit Margin</span>
                    <span class="value">${results.calculated.profitMarginPct.toFixed(1)}%</span>
                </div>
            </div>
        `;

        // Client breakdown table
        let tableHtml = `
            <table class="allocation-results-table">
                <thead>
                    <tr>
                        <th>Client</th>
                        <th>Allocation %</th>
                        <th>Daily Rate</th>
                        <th>Revenue / Day</th>
                        <th>Profit / Day</th>
                        <th>Notes</th>
                    </tr>
                </thead>
                <tbody>
        `;

        results.clients.forEach(client => {
            const baselineLabel = client.isBaseline ? '<span class="baseline-badge">Baseline (covers cost)</span>' : '';
            tableHtml += `
                <tr ${client.isBaseline ? 'class="baseline-row"' : ''}>
                    <td><strong>${client.name}</strong></td>
                    <td>${client.allocationPct.toFixed(1)}%</td>
                    <td>${AllocationCalculator.formatCurrency(client.dailyRate)}</td>
                    <td>${AllocationCalculator.formatCurrency(client.revenuePerDay)}</td>
                    <td class="${client.profitPerDay >= 0 ? 'profit' : 'loss'}">
                        ${AllocationCalculator.formatCurrency(client.profitPerDay)}
                    </td>
                    <td>${baselineLabel}</td>
                </tr>
            `;
        });

        tableHtml += `
                </tbody>
            </table>
        `;

        clientTableDiv.innerHTML = tableHtml;

        // Show results section
        document.getElementById('allocation-results-section').style.display = 'block';
        document.getElementById('allocation-results-section').scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });
    },

    /**
     * Export allocation results to PDF
     */
    exportAllocationToPDF() {
        alert('Allocation PDF export - Coming soon!');
    },

    /**
     * Print allocation results
     */
    printAllocationResults() {
        // Prepare print view with input summary
        this.preparePrintView();
        
        // Print
        window.print();
        
        // Clean up after print dialog closes (give it a moment)
        setTimeout(() => {
            this.cleanupPrintView();
        }, 100);
    }
};

// Make UI available globally
window.UI = UI;

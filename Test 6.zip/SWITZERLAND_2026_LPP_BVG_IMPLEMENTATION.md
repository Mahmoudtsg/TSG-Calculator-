# Switzerland 2026 LPP/BVG Implementation Summary

## Date: January 13, 2026

## Overview
Successfully implemented Switzerland (Geneva) 2026 BVG/LPP fixes to correctly cap high salaries at the mandatory BVG maximum while preserving the option for super-obligatory pension plans.

---

## ✅ Changes Implemented

### 1. Updated 2026 BVG Constants (switzerland.js)
- **LPP_MIN_SALARY**: Updated from 22,050 to **22,680 CHF** (2026)
- **LPP_COORDINATION**: Updated from 25,725 to **26,460 CHF** (2026)
- **LPP_MAX_SALARY**: Added new constant **90,720 CHF** (2026 BVG cap)

### 2. Implemented Mandatory BVG Salary Cap Logic (switzerland.js)
**For Mandatory Plan (default):**
```javascript
const cappedYearly = Math.min(yearlyGross, LPP_MAX_SALARY);  // Cap at 90,720
const insuredSalaryYearly = Math.max(0, cappedYearly - LPP_COORDINATION);
const insuredSalaryMonthly = insuredSalaryYearly / 12;
lpp_employee = insuredSalaryMonthly * lppRate;
lpp_employer = insuredSalaryMonthly * lppRate;
```

**For Super-obligatory Plan:**
```javascript
const insuredSalaryYearly = Math.max(0, yearlyGross - LPP_COORDINATION);  // No cap
const insuredSalaryMonthly = insuredSalaryYearly / 12;
lpp_employee = insuredSalaryMonthly * lppRate;
lpp_employer = insuredSalaryMonthly * lppRate;
```

### 3. Added UI Toggle for Pension Plan Mode (index.html)
New radio button group in Switzerland Advanced Options:
- **Option A (default)**: "BVG Mandatory (capped at CHF 90,720)"
- **Option B**: "Super-obligatory (uncapped)"

Located before the LPP Rate field in the CH-specific options section.

### 4. Updated Parameter Handling (ui.js & calculator.js)
- Added `lppPlanMode` parameter extraction from radio buttons
- Passed `lppPlanMode` through calculator to Switzerland rules
- Default value: `'mandatory'`
- Possible values: `'mandatory'` | `'super'`

### 5. Enhanced LPP Breakdown Display (switzerland.js)
Updated formula display to show:
- Insured salary base in the label: `"LPP (Pension) - insured base: CHF X/month"`
- Mode indicator in formula: `[Mandatory: capped]` or `[Super-obligatory: uncapped]`
- Both employee and employer contributions show the same information

---

## 🧪 Test Results

### Test Case: Monthly Gross CHF 15,000

**Yearly Gross:** 180,000 CHF

#### Mandatory Mode (Capped):
- Capped Yearly: Min(180,000, 90,720) = **90,720 CHF**
- Insured Yearly: 90,720 - 26,460 = **64,260 CHF**
- Insured Monthly: 64,260 / 12 = **5,355 CHF**
- LPP @ 7%: 5,355 × 0.07 = **374.85 CHF** ✅

#### Super-obligatory Mode (Uncapped):
- Insured Yearly: 180,000 - 26,460 = **153,540 CHF**
- Insured Monthly: 153,540 / 12 = **12,795 CHF**
- LPP @ 7%: 12,795 × 0.07 = **895.65 CHF** ✅

**Difference:** 895.65 - 374.85 = **520.80 CHF/month** (correct)

---

## 📁 Modified Files

### 1. js/rules/switzerland.js
- Updated BVG constants for 2026
- Implemented conditional capping logic based on `lppPlanMode`
- Enhanced formula display with insured base and mode indicator
- Applied to both employee and employer LPP calculations

### 2. index.html
- Added pension plan mode toggle (radio buttons)
- Positioned in Switzerland-specific advanced options
- Default selection: Mandatory (capped)

### 3. js/ui.js
- Extract `lppPlanMode` from radio button selection
- Pass to calculator with default `'mandatory'`

### 4. js/calculator.js
- Added `lppPlanMode` parameter to function signature
- Include in input object passed to Switzerland rules

---

## 🔒 Hard Rules Compliance

✅ **NO changes to Spain/Romania** - Only Switzerland modified  
✅ **NO B2B mode affected** - Changes only affect employee payroll calculations  
✅ **Minimal UI changes** - Single radio button group added  
✅ **All existing formulas preserved** - Only LPP calculation modified  
✅ **Tax year updated** - Header shows "2026" in switzerland.js comment  

---

## 📋 User Impact

### For Users with High Salaries (>90,720 CHF/year):
- **Default behavior**: LPP capped at mandatory BVG maximum (correct for most cases)
- **Option available**: Switch to "Super-obligatory" for uncapped pension contributions
- **Transparency**: Insured salary base clearly displayed in breakdown

### For Standard Salaries (<90,720 CHF/year):
- **No change in behavior**: Calculations remain the same
- **Mode selector available**: Can still choose between modes (no practical difference)

---

## 🚀 Deployment Checklist

- [x] Switzerland 2026 constants updated
- [x] Mandatory BVG cap implemented
- [x] Super-obligatory option added
- [x] UI toggle created
- [x] Parameters wired through calculator
- [x] Insured base displayed in breakdown
- [x] Test cases verified (CHF 15,000 monthly)
- [x] README.md updated with 2026 details
- [x] No impact on Spain/Romania confirmed
- [x] No B2B mode affected

---

## 📖 Usage Instructions

1. **Select Switzerland (Geneva) as country**
2. **Enter monthly/yearly gross salary**
3. **In Advanced Options:**
   - Choose "BVG Mandatory (capped)" for standard mandatory pension
   - Choose "Super-obligatory (uncapped)" for executive/high-earner plans
4. **View results:**
   - LPP breakdown shows insured salary base
   - Formula indicates which mode is active
   - Both employee and employer contributions reflect the cap

---

## 🎯 Acceptance Criteria Met

✅ **Constants updated** to 2026 values  
✅ **Mandatory cap** applied correctly at 90,720 CHF  
✅ **Super-obligatory mode** bypasses cap  
✅ **UI toggle** minimal and clear  
✅ **Insured base** displayed for auditability  
✅ **Test case** verified: CHF 15,000 monthly gross  
✅ **Spain/Romania** untouched  
✅ **B2B mode** unaffected  

---

## 📞 Support

For questions about the 2026 BVG/LPP implementation, refer to:
- This document
- README.md (updated)
- test-lpp-2026.html (test file with calculations)

**Implementation completed:** January 13, 2026  
**Version:** 1.1.7 (Geneva 2026 Update)

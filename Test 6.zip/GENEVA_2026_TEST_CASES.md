# Geneva 2026 Payroll - Verification Test Cases

## Test Date: 2026-01-12
## Status: Ready for Testing

---

## Test Case 1: Below AC Ceiling

**Input:**
- Country: Switzerland (Geneva)
- Monthly Gross: **10,000 CHF**
- Calculation Mode: From Gross

**Expected Results:**

| Contribution | Calculation | Amount (CHF) |
|--------------|-------------|--------------|
| **AVS** | 10,000 × 4.35% | 435.00 |
| **AI** | 10,000 × 0.70% | 70.00 |
| **APG** | 10,000 × 0.25% | 25.00 |
| **AC Employee** | Min(10,000, 12,350) × 1.10% = 10,000 × 1.10% | **110.00** |
| **AMat Employee** | 10,000 × 0.029% | **2.90** |
| **AC Employer** | Min(10,000, 12,350) × 1.10% = 10,000 × 1.10% | **110.00** |
| **AMat Employer** | 10,000 × 0.029% | **2.90** |

**Key Verifications:**
- ✅ AC Employee = AC Employer (both 110.00)
- ✅ AMat shows 0.029% in breakdown labels
- ✅ AC formula displays: "Min(10000.00, 12350.00) × 1.10% = 10000.00 × 1.10%"

---

## Test Case 2: At AC Ceiling (Boundary)

**Input:**
- Country: Switzerland (Geneva)
- Monthly Gross: **12,350 CHF**
- Calculation Mode: From Gross

**Expected Results:**

| Contribution | Calculation | Amount (CHF) |
|--------------|-------------|--------------|
| **AC Employee** | Min(12,350, 12,350) × 1.10% = 12,350 × 1.10% | **135.85** |
| **AMat Employee** | 12,350 × 0.029% | **3.58** |
| **AC Employer** | Min(12,350, 12,350) × 1.10% = 12,350 × 1.10% | **135.85** |
| **AMat Employer** | 12,350 × 0.029% | **3.58** |

**Key Verifications:**
- ✅ AC Employee = AC Employer (both 135.85)
- ✅ AC base = 12,350 (at ceiling)
- ✅ Formula shows ceiling is reached

---

## Test Case 3: Above AC Ceiling ⭐ CRITICAL

**Input:**
- Country: Switzerland (Geneva)
- Monthly Gross: **12,500 CHF**
- Calculation Mode: From Gross

**Expected Results:**

| Contribution | Calculation | Amount (CHF) |
|--------------|-------------|--------------|
| **AVS** | 12,500 × 4.35% | 543.75 |
| **AI** | 12,500 × 0.70% | 87.50 |
| **APG** | 12,500 × 0.25% | 31.25 |
| **AC Employee** | Min(12,500, 12,350) × 1.10% = **12,350** × 1.10% | **135.85** |
| **AMat Employee** | 12,500 × 0.029% | **3.63** |
| **LPP Employee** | (150,000 - 25,725) / 12 × 7% | ~724.91 |
| **LAA Employee** | 12,500 × 1.5% (default) | **187.50** |
| **AC Employer** | Min(12,500, 12,350) × 1.10% = **12,350** × 1.10% | **135.85** |
| **AMat Employer** | 12,500 × 0.029% | **3.63** |
| **AF** | 12,500 × 2.25% | 281.25 |
| **LPP Employer** | (150,000 - 25,725) / 12 × 7% | ~724.91 |
| **LAA Employer** | 12,500 × 1.0% | 125.00 |

**CRITICAL Verifications:**
- ✅ AC Employee = 135.85 CHF (NOT 134.26 or other wrong value)
- ✅ AC Employer = 135.85 CHF (NOT 123.42 or other wrong value)
- ✅ AC Employee = AC Employer (MUST MATCH)
- ✅ AC base is capped at 12,350 CHF
- ✅ Formula displays: "Min(12500.00, 12350.00) × 1.10% = 12350.00 × 1.10%"
- ✅ AMat shows 3.63 CHF (0.029% rate, not 0.032%)
- ✅ LAA Non-Prof shows 187.50 CHF (1.5% default, not 3.0%)

---

## Test Case 4: Well Above AC Ceiling

**Input:**
- Country: Switzerland (Geneva)
- Monthly Gross: **15,000 CHF**
- Calculation Mode: From Gross

**Expected Results:**

| Contribution | Calculation | Amount (CHF) |
|--------------|-------------|--------------|
| **AC Employee** | Min(15,000, 12,350) × 1.10% = **12,350** × 1.10% | **135.85** |
| **AC Employer** | Min(15,000, 12,350) × 1.10% = **12,350** × 1.10% | **135.85** |
| **AMat Employee** | 15,000 × 0.029% | **4.35** |
| **AMat Employer** | 15,000 × 0.029% | **4.35** |

**Key Verifications:**
- ✅ AC amounts still capped at 135.85 CHF (ceiling applies)
- ✅ AC Employee = AC Employer
- ✅ No "additional rate" applied
- ✅ AMat calculated on full 15,000 gross (no ceiling)

---

## Test Case 5: LAA Non-Professional Configurability

**Input:**
- Country: Switzerland (Geneva)
- Monthly Gross: **10,000 CHF**
- LAA Non-Prof Rate: **3.0%** (changed from default 1.5%)

**Expected Results:**

| Contribution | Default (1.5%) | Custom (3.0%) |
|--------------|----------------|---------------|
| **LAA Employee** | 150.00 CHF | **300.00 CHF** |

**Key Verifications:**
- ✅ LAA Non-Prof input field visible in Advanced Options
- ✅ Default value is 1.5%
- ✅ Changing value recalculates LAA amount
- ✅ Label shows "(varies by insurer)"
- ✅ Value persists during session

---

## Test Case 6: UI/UX Verification

**Country Selection: Switzerland**

**Advanced Options Section Should Show:**
1. ✅ LPP Rate (Pension) % - Default: 7%
2. ✅ LFP Employer Rate % - Default: 0.05%
3. ✅ **LAA Non-Professional Rate %** - Default: 1.5% (NEW)
4. ✅ LPP Reference Link to www.ciepp.ch

**Breakdown Display Should Show:**
1. Employee Contributions:
   - ✅ AVS (4.35%)
   - ✅ AI (0.70%)
   - ✅ APG (0.25%)
   - ✅ AC (1.10%)
   - ✅ **AMat (0.029%)** ← Updated from 0.032%
   - ✅ LPP (Pension)
   - ✅ LAA (Non-prof)

2. Employer Contributions:
   - ✅ AVS (4.35%)
   - ✅ AI (0.70%)
   - ✅ APG (0.25%)
   - ✅ AC (1.10%)
   - ✅ AF (2.25%)
   - ✅ **AMat (0.029%)** ← Updated from 0.032%
   - ✅ CPE (0.07%)
   - ✅ LFP (variable)
   - ✅ **LPP (Pension - employer)** ← Clarified label
   - ✅ LAA (Professional)

---

## Test Case 7: Spain/Romania Unchanged

**Spain Input:**
- Monthly Gross: 3,000 EUR

**Expected:**
- ✅ All Spain calculations work normally
- ✅ No Switzerland parameters visible
- ✅ No errors in console

**Romania Input:**
- Monthly Gross: 8,000 RON

**Expected:**
- ✅ All Romania calculations work normally
- ✅ No Switzerland parameters visible
- ✅ No errors in console

---

## Test Case 8: B2B Mode Unchanged

**B2B Input:**
- Contractor Cost: 500 EUR/day
- Working Days: 220

**Expected:**
- ✅ B2B calculations work normally
- ✅ No employee deductions calculated
- ✅ No payroll taxes applied
- ✅ Client budget margin calculations correct

---

## Test Case 9: Reverse Calculations

**From Net to Gross (CH):**
- Target Net: 8,000 CHF
- Expected: Should converge to gross within 50 iterations
- ✅ AC ceiling logic applies correctly in reverse

**From Total Cost to Gross (CH):**
- Target Total: 15,000 CHF
- Expected: Should find gross where Total Cost = Gross + Employer Contrib + Benefits = 15,000
- ✅ AC ceiling logic applies correctly in reverse

---

## Test Case 10: PDF Export

**Input:**
- Country: Switzerland
- Monthly Gross: 12,500 CHF
- Employee Name: "Test User"
- Export to PDF

**PDF Should Show:**
- ✅ AC Employee: 135.85 CHF
- ✅ AC Employer: 135.85 CHF
- ✅ AMat: 0.029% label
- ✅ LAA Non-Prof: Configured rate
- ✅ All formulas display correctly
- ✅ Year shown as 2026

---

## Regression Testing Checklist

### Functionality
- [ ] All test cases pass
- [ ] AC employee/employer amounts match exactly
- [ ] AMat shows 0.029% throughout UI
- [ ] LAA non-prof is configurable
- [ ] Spain calculations unchanged
- [ ] Romania calculations unchanged
- [ ] B2B mode works correctly

### UI/UX
- [ ] LAA input field visible for CH
- [ ] Default LAA value is 1.5%
- [ ] "(varies by insurer)" note displays
- [ ] Breakdown labels show correct percentages
- [ ] LPP employer label clarified
- [ ] No console errors

### Performance
- [ ] Calculations complete < 100ms
- [ ] No memory leaks
- [ ] PDF export works
- [ ] FX rates load correctly

### Browser Testing
- [ ] Chrome latest
- [ ] Firefox latest
- [ ] Safari latest
- [ ] Edge latest

---

## Known Limitations

1. **Income Tax**: Still not included (canton-dependent)
2. **AC Additional Rate (0.5%)**: Not implemented (applies above 148,200/year only, complex annual calculation)
3. **LPP Age Bands**: User must manually select rate (7%, 10%, 15%, 18%)
4. **LAA Professional**: Remains fixed at 1% (less variable than non-prof)

---

## Sign-off

**Tested By:** _________________  
**Date:** _________________  
**Status:** [ ] Pass  [ ] Fail  
**Notes:** _________________

---

**For detailed fix documentation, see:**
- `GENEVA_2026_PAYROLL_FIX.md` - Complete implementation guide
- `GENEVA_2026_QUICK_REF.md` - Quick reference
- `AC_CALCULATION_FIX_DETAILS.md` - AC/ALV fix details

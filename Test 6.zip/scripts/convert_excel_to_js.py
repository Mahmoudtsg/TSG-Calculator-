#!/usr/bin/env python3
"""
Excel to JavaScript Salary Data Converter
Converts IT_Salaries_Switzerland_2025.xlsx to JavaScript format
"""

import pandas as pd
import json

def convert_excel_to_js(excel_file, output_js_file):
    """
    Convert Excel salary data to JavaScript format
    
    Expected Excel columns:
    - Role / Job Title / Position
    - Min / Minimum / Min Salary
    - Median / Average / Median Salary
    - Max / Maximum / Max Salary
    - Experience / Level (optional)
    - Source / Year (optional)
    """
    
    print(f"📂 Reading Excel file: {excel_file}")
    
    # Read Excel file
    df = pd.read_excel(excel_file)
    
    print(f"✅ Found {len(df)} rows")
    print(f"📊 Columns: {list(df.columns)}")
    
    # Detect column names (case-insensitive)
    def find_column(df, possible_names):
        for col in df.columns:
            if col.lower() in [name.lower() for name in possible_names]:
                return col
        return None
    
    role_col = find_column(df, ['role', 'job title', 'position', 'title', 'job'])
    min_col = find_column(df, ['min', 'minimum', 'min salary', 'minimum salary'])
    median_col = find_column(df, ['median', 'average', 'avg', 'median salary', 'mid'])
    max_col = find_column(df, ['max', 'maximum', 'max salary', 'maximum salary'])
    exp_col = find_column(df, ['experience', 'level', 'seniority', 'exp'])
    source_col = find_column(df, ['source', 'year', 'data source'])
    
    if not role_col:
        print("❌ Error: Could not find 'Role' column")
        print("Available columns:", list(df.columns))
        return False
    
    print(f"\n🔍 Detected columns:")
    print(f"   Role: {role_col}")
    print(f"   Min: {min_col}")
    print(f"   Median: {median_col}")
    print(f"   Max: {max_col}")
    print(f"   Experience: {exp_col if exp_col else 'Not found (will default to Mid)'}")
    print(f"   Source: {source_col if source_col else 'Not found (will default to 2025)'}")
    
    # Convert to list of dictionaries
    salary_data = []
    
    for idx, row in df.iterrows():
        role = row[role_col]
        
        # Skip empty rows
        if pd.isna(role) or str(role).strip() == '':
            continue
        
        # Get salary values
        min_sal = row[min_col] if min_col else None
        median_sal = row[median_col] if median_col else None
        max_sal = row[max_col] if max_col else None
        
        # Skip if no salary data
        if pd.isna(min_sal) and pd.isna(median_sal) and pd.isna(max_sal):
            continue
        
        # Default values
        experience = row[exp_col] if exp_col and not pd.isna(row[exp_col]) else 'Mid'
        source = row[source_col] if source_col and not pd.isna(row[source_col]) else '2025'
        
        # Convert to int, handle missing values
        min_sal = int(min_sal) if not pd.isna(min_sal) else None
        median_sal = int(median_sal) if not pd.isna(median_sal) else None
        max_sal = int(max_sal) if not pd.isna(max_sal) else None
        
        # If any salary is missing, try to estimate
        if min_sal is None and median_sal and max_sal:
            min_sal = int(median_sal * 0.8)
        if median_sal is None and min_sal and max_sal:
            median_sal = int((min_sal + max_sal) / 2)
        if max_sal is None and min_sal and median_sal:
            max_sal = int(median_sal * 1.3)
        
        salary_data.append({
            'role': str(role).strip(),
            'min': min_sal,
            'median': median_sal,
            'max': max_sal,
            'experience': str(experience).strip(),
            'source': str(source).strip()
        })
    
    print(f"\n✅ Converted {len(salary_data)} salary records")
    
    # Generate JavaScript code
    js_code = """/**
 * Swiss IT Salaries Data - Converted from Excel
 * Source: IT_Salaries_Switzerland_2025.xlsx
 * Auto-generated: Do not edit manually
 */

const SwissSalaryData = {
    salaryData: """
    
    js_code += json.dumps(salary_data, indent=8)
    
    js_code += """,
    
    /**
     * Load this data into the salary benchmark system
     */
    initialize() {
        if (window.SalaryBenchmark) {
            window.SalaryBenchmark.swissSalaryData = this.salaryData;
            console.log(`✅ Loaded ${this.salaryData.length} Swiss IT salary records`);
            return true;
        } else {
            console.error('❌ SalaryBenchmark not found. Make sure salaryBenchmark.js is loaded first.');
            return false;
        }
    }
};

// Auto-initialize when script loads
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        SwissSalaryData.initialize();
    });
} else {
    SwissSalaryData.initialize();
}

// Make available globally
window.SwissSalaryData = SwissSalaryData;
"""
    
    # Write to file
    with open(output_js_file, 'w', encoding='utf-8') as f:
        f.write(js_code)
    
    print(f"\n💾 Saved to: {output_js_file}")
    print(f"📝 File size: {len(js_code)} bytes")
    
    # Print sample
    print(f"\n📋 Sample records:")
    for i, record in enumerate(salary_data[:5]):
        print(f"   {i+1}. {record['role']}: {record['min']:,} - {record['median']:,} - {record['max']:,} CHF")
    
    if len(salary_data) > 5:
        print(f"   ... and {len(salary_data) - 5} more")
    
    return True

if __name__ == '__main__':
    import sys
    
    excel_file = 'data/IT_Salaries_Switzerland_2025.xlsx'
    output_file = 'js/swissSalaryData.js'
    
    print("=" * 60)
    print("Excel to JavaScript Salary Data Converter")
    print("=" * 60)
    
    try:
        success = convert_excel_to_js(excel_file, output_file)
        if success:
            print("\n✅ SUCCESS! Data converted successfully.")
            print("\n📋 Next steps:")
            print("   1. Review the generated file: js/swissSalaryData.js")
            print("   2. The file is already linked in index.html")
            print("   3. Refresh your browser to see the data")
        else:
            print("\n❌ Conversion failed. Check errors above.")
            sys.exit(1)
    except FileNotFoundError:
        print(f"\n❌ Error: File not found: {excel_file}")
        print("   Make sure the Excel file is in the 'data' folder")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Error: {str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

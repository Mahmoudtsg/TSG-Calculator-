# B2B Currency Selector Update

## Summary
Added independent currency selectors (EUR/CHF) for Client Daily Rate and Client Budget per Day in B2B mode, with intelligent currency matching logic for results.

## Changes Made

### 1. HTML Updates (index.html)

#### Client Daily Rate
- **Before**: Fixed currency display showing contractor cost currency
- **After**: Independent currency selector (EUR/CHF dropdown)
- Changed from `<span>` to `<select>` element with id `b2b-client-rate-currency`

#### Client Budget per Day
- **Before**: Fixed currency display showing contractor cost currency
- **After**: Independent currency selector (EUR/CHF dropdown)
- Changed from `<span>` to `<select>` element with id `b2b-client-budget-currency`

### 2. JavaScript Updates (js/ui.js)

#### Event Listeners
- Removed automatic currency syncing from contractor cost currency
- Added independent event listeners for:
  - `b2b-client-rate-currency` selector
  - `b2b-client-budget-currency` selector
- Both trigger recalculation when currency is changed

#### Calculation Logic (performB2BCalculation)

##### Currency Conversion Helper
Added helper function to convert between currencies using FX rates:
```javascript
const convertCurrency = (value, fromCurrency, toCurrency) => {
    if (fromCurrency === toCurrency) return value;
    // Convert via EUR: from → EUR → to
    const eurToFrom = ratesData.rates[fromCurrency] || 1;
    const eurToTo = ratesData.rates[toCurrency] || 1;
    const inEur = value / eurToFrom;
    return inEur * eurToTo;
};
```

##### Result Currency Logic
Implemented intelligent currency matching:
- **If contractor cost currency = client rate/budget currency**: Results in same currency
- **If contractor cost currency ≠ client rate/budget currency**: Results in EUR

##### Mode-Specific Updates

**Target Margin % Mode**
- No changes needed (doesn't involve client currency)
- Results stay in contractor cost currency

**Client Daily Rate Mode**
1. Gets client rate currency from selector
2. Determines result currency based on matching logic
3. Converts both contractor cost and client rate to result currency
4. Performs calculations in result currency

**Client Budget Mode**
1. Gets client budget currency from selector
2. Determines result currency based on matching logic
3. Converts client budget to result currency
4. Calculates max contractor cost in result currency
5. Performs all calculations in result currency

### 3. Results Storage
- Updated `results.costCurrency` to store `resultCurrency` instead
- All monetary values stored in the determined result currency

## Usage Examples

### Example 1: Same Currency
- Contractor Cost: 500 CHF/day
- Client Daily Rate: 750 CHF/day
- **Result**: All calculations in CHF

### Example 2: Different Currencies
- Contractor Cost: 500 EUR/day
- Client Daily Rate: 750 CHF/day
- **Result**: All calculations in EUR (converted using FX rates)

### Example 3: Client Budget Same Currency
- Contractor Cost Currency: CHF
- Client Budget: 800 CHF/day with 30% margin
- **Result**: All calculations in CHF

### Example 4: Client Budget Different Currency
- Contractor Cost Currency: CHF
- Client Budget: 800 EUR/day with 30% margin
- **Result**: All calculations in EUR (converted using FX rates)

## Benefits

1. **Flexibility**: Users can input client rates/budgets in their preferred currency
2. **Intelligent Conversion**: Automatic currency matching and conversion
3. **Clear Results**: Results always in a single, logical currency
4. **EUR as Default**: When currencies don't match, EUR provides a neutral standard

## Testing Checklist

- [ ] Client Daily Rate mode with EUR/EUR (same currency)
- [ ] Client Daily Rate mode with EUR/CHF (different currencies → EUR result)
- [ ] Client Daily Rate mode with CHF/EUR (different currencies → EUR result)
- [ ] Client Daily Rate mode with CHF/CHF (same currency)
- [ ] Client Budget mode with EUR/EUR (same currency)
- [ ] Client Budget mode with EUR/CHF (different currencies → EUR result)
- [ ] Client Budget mode with CHF/EUR (different currencies → EUR result)
- [ ] Client Budget mode with CHF/CHF (same currency)
- [ ] Currency selector changes trigger recalculation
- [ ] FX rates applied correctly in conversions
- [ ] Results display in correct currency

## Technical Notes

- Uses existing FXService for currency conversions
- All conversions go through EUR as base currency
- Event listeners ensure real-time recalculation on currency change
- Result currency determination happens before calculations
- All calculations performed in determined result currency for consistency

/**
 * Main Entry Point
 * Initialize the application
 */

// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', () => {
    console.log('TSG Salary & Cost Calculator - Initializing...');
    
    try {
        // Initialize UI
        UI.init();
        
        // Initialize calculator with default country (Switzerland)
        Calculator.init('CH');
        
        // Preload exchange rates in background
        FXService.getRates().then(rates => {
            console.log('Exchange rates loaded:', rates.date);
        }).catch(error => {
            console.warn('Could not preload exchange rates:', error);
        });
        
        console.log('TSG Salary & Cost Calculator - Ready');
        
        // Optional: Display welcome message or tooltip
        showWelcomeTooltip();
        
    } catch (error) {
        console.error('Initialization error:', error);
        alert('Application failed to initialize. Please refresh the page.');
    }
});

/**
 * Show welcome tooltip (optional)
 */
function showWelcomeTooltip() {
    // Check if user has seen welcome message
    const hasSeenWelcome = localStorage.getItem('tsg_calc_welcome_seen');
    
    if (!hasSeenWelcome) {
        // Could show a modal or tooltip here
        console.log('Welcome to TSG Salary & Cost Calculator!');
        localStorage.setItem('tsg_calc_welcome_seen', 'true');
    }
}

/**
 * Global error handler
 */
window.addEventListener('error', (event) => {
    console.error('Global error:', event.error);
});

/**
 * Handle unhandled promise rejections
 */
window.addEventListener('unhandledrejection', (event) => {
    console.error('Unhandled promise rejection:', event.reason);
});

/**
 * Keyboard shortcuts (optional)
 */
document.addEventListener('keydown', (event) => {
    // Ctrl/Cmd + Enter to calculate
    // ===== MODE ISOLATION: Click appropriate calculate button based on activeMode =====
    if ((event.ctrlKey || event.metaKey) && event.key === 'Enter') {
        event.preventDefault();
        if (window.activeMode === 'b2b') {
            document.getElementById('b2b-calculate-btn').click();
        } else if (window.activeMode === 'allocation') {
            document.getElementById('allocation-calculate-btn').click();
        } else {
            document.getElementById('calculate-btn').click();
        }
    }
    
    // Ctrl/Cmd + P to print
    if ((event.ctrlKey || event.metaKey) && event.key === 'p') {
        event.preventDefault();
        window.print();
    }
});

/**
 * Utility: Debounce function for performance
 */
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

/**
 * Utility: Throttle function
 */
function throttle(func, limit) {
    let inThrottle;
    return function(...args) {
        if (!inThrottle) {
            func.apply(this, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

// Export utilities if needed
window.AppUtils = {
    debounce,
    throttle
};

// Log application version
console.log('TSG Salary & Cost Calculator v1.1.2');
console.log('© Technology Staffing Group');

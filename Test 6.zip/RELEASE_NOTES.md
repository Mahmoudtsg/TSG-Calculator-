# TSG Salary & Cost Calculator - Release Notes

**Version:** 1.1.6 (Final)  
**Release Date:** 2025-12-19  
**Status:** ✅ Production Ready

---

## 🎯 What's New in v1.1.6

### 1. Occupation Rate Support
- **New Field:** Occupation Rate (1-100%, default 100%)
- **Purpose:** Calculate costs for part-time employees
- **How It Works:**
  - Scales the INPUT SALARY (not working days)
  - Example: 10,000 RON at 80% = 8,000 RON salary
  - Working days remain fixed at 220

### 2. Monthly Meal Benefits
- **Renamed:** "Monthly Other Benefits" → "Monthly Meal Benefits"
- **Non-Taxable:** Properly implemented for Romania
- Added to employee take-home value
- Added to employer cost
- NOT included in taxable income

### 3. Help Icons Updated
- **Changed:** All icons from "!" to "?"
- **Why:** "?" suggests help/information, not warning
- **Count:** 22 icons updated throughout the application

### 4. B2B Improvements
- Display Currency moved after Client Daily Rate
- Business Outputs auto-hide when currencies match
- Better user flow

### 5. Currency Conversion Fixed
- Fixed RON → CHF conversion in Business Outputs
- All conversions now go through RON as intermediate
- Accurate for all currency combinations

---

## 🔧 Technical Changes

**Files Modified:** 3
- `index.html` (2 edits)
- `js/ui.js` (~115 edits)
- `js/rules/romania.js` (10 edits)

**Total Lines Changed:** ~127

---

## 📊 Key Examples

### Occupation Rate (80%)
```
Input: 10,000 RON gross salary, 80% occupation

Calculation:
- Adjusted Salary: 10,000 × 0.8 = 8,000 RON ✅
- Working Days: 220 (always) ✅
- Net Salary: ~4,680 RON
- Daily Cost: (98,160 annual) ÷ 220 = 446.18 RON
```

### Currency Conversion (RON → CHF)
```
Input: 1,000 RON, Reference: CHF

Correct Conversion:
- RON to EUR: 1,000 / 4.97 = 201.21 EUR
- EUR to CHF: 201.21 × 0.93 = 187.12 CHF ✅
```

---

## ✅ Testing

- **Page Load:** ✅ No errors
- **Occupation Rate:** ✅ Scales salary correctly
- **Currency Conversion:** ✅ All combinations accurate
- **Help Icons:** ✅ All show "?"
- **Meal Benefits:** ✅ Non-taxable

---

## 🚀 Deployment

**Essential Files:**
1. `index.html`
2. `js/ui.js`
3. `js/rules/romania.js`
4. `css/style.css` (unchanged)
5. `js/calculator.js` (unchanged)
6. `js/fxService.js` (unchanged)
7. `js/main.js` (unchanged)
8. `js/rules/switzerland.js` (unchanged)
9. `js/rules/spain.js` (unchanged)

**Deployment Steps:**
1. Backup current files
2. Upload modified files
3. Clear browser cache
4. Test with examples above

---

## 📖 Usage Guide

### Using Occupation Rate
1. Open calculator
2. Select Employee engagement type
3. Enter salary as if full-time
4. Set Occupation Rate (e.g., 80 for 4 days/week)
5. Calculate - salary will be scaled automatically

### Using Meal Benefits
1. Open Advanced Options
2. Enter Monthly Meal Benefits amount
3. Benefits will be added to take-home (non-taxable)

### Business Outputs with CHF
1. Select Romania country
2. Choose "CHF" as Reference Currency
3. Business Outputs will show correct conversions

---

## 🎓 Important Notes

**Occupation Rate:**
- ✅ Scales SALARY (10,000 → 8,000 for 80%)
- ✅ Working days ALWAYS 220 (never scaled)
- ❌ Does NOT scale days (220 → 176 for 80%)

**Currency Conversion:**
- All conversions go through RON
- No special cases for any currency
- Formula: Original → RON → Target

**Help Icons:**
- "?" means information/help available
- Hover or click for tooltips
- Not warnings or errors

---

## 💱 Exchange Rate Updates

**Automatic Updates:** ✅ YES

The calculator automatically fetches and updates exchange rates:

### How It Works:
1. **On Page Load:** Fetches live rates from API
2. **Caches for 24 hours:** Stored in browser for fast loading
3. **Auto-refreshes:** After 24 hours, fetches new rates automatically
4. **Fallback rates:** If API fails, uses backup rates (CHF: 0.93, RON: 4.97)

### Manual Refresh:
- Click the **🔄 refresh button** next to exchange rate
- Forces immediate rate update
- Shows loading spinner while fetching
- Updates display automatically

### Rate Source:
- API: `https://api.exchangerate-api.com/v4/latest/EUR`
- Free, reliable, no authentication needed
- Updates daily with market rates

---

## 📞 Support

**For Questions:**
- Review README.md for full documentation
- Check examples above for common scenarios
- Test with provided test cases

**For Issues:**
- Clear browser cache (Ctrl+Shift+Delete)
- Hard refresh (Ctrl+Shift+R)
- Check console for errors (F12)

---

**Version:** 1.1.6 (Final)  
**Exchange Rates:** ✅ Auto-Updated (24h cache)  
**All Features Tested:** ✅  
**Production Ready:** ✅

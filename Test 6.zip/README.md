# TSG Salary & Cost Calculator

![TSG Logo](images/tsg-logo.png)

A comprehensive, responsive web application for calculating payroll costs, taxes, and business margins across three countries: Switzerland, Romania, and Spain. Now includes Allocation mode for multi-client profitability modeling.

---

## 🚀 Project Overview

**Version:** 1.2.3 (Swiss Benchmark B2B Fix)  
**Last Updated:** 2026-01-15  
**Developed for:** Technology Staffing Group (TSG)  

This internal tool helps staffing professionals quickly calculate:
- Employee net/gross salaries
- Total company costs
- Tax and social security contributions
- Business margins and daily rates
- **Multi-client allocation profitability**
- Currency conversions to EUR

---

## 📊 Engagement Types

The calculator supports **three fully isolated engagement types**, each with its own calculation logic and state management:

### 1. 👤 Employee Mode (TSG Payroll)
Standard payroll calculations for employees on TSG's books. Calculates:
- Net/gross salary conversions
- Social security contributions
- Tax withholdings
- Total employer costs
- Business margins and daily rates
- **🎯 Swiss Salary Benchmark** (Switzerland only) **NEW**

**Supports:** Switzerland, Romania, Spain

**Special Feature - Swiss Salary Benchmark:**
- Intelligent job title matching with fuzzy search
- Compares salary against market data
- Handles abbreviations (e.g., "ML Engineer" → "Machine Learning Engineer")
- Visual salary range display
- Position indicator showing where you fall in the market
- Only appears for Switzerland Employee mode

### 2. 🤝 B2B Mode (Independent Contractor)
Business-to-business contractor cost modeling. Features:
- Contractor cost calculations (daily/hourly)
- Client pricing (target margin, daily rate, or budget)
- Multi-currency support
- Profit margin analysis

**Note:** No payroll taxes or social security—pure cost/revenue modeling.

### 3. 📊 Allocation Mode (Multi-Client Profitability) **NEW**
Commercial profitability modeling when **one employee is allocated to multiple clients**. 

**Key Concept:** The employer pays one fixed daily cost (deducted once), and additional client allocations generate incremental profit.

**This is NOT payroll allocation—it's commercial profitability modeling.**

#### Allocation Mode Features:
- ✅ Salary at 100% (annual base)
- ✅ Engagement % (0-100%)
- ✅ Employer multiplier (e.g., 1.20)
- ✅ Dynamic client table (unlimited clients)
- ✅ Allocation % per client (must not exceed engagement %)
- ✅ Daily rate per client
- ✅ Automatic baseline client identification (covers base cost)
- ✅ Incremental profit calculation for additional clients
- ✅ Annual profit projection

#### Allocation Calculation Logic:
```
1. Engaged Salary = Salary100 × (Engagement% / 100)
2. Employer Cost (Annual) = Engaged Salary × Multiplier
3. Base Daily Cost = Employer Cost / Working Days [PAID ONCE]

For each client:
4. Client Revenue/Day = Daily Rate × (Allocation% / 100)

5. Baseline Client = Client with highest revenue/day
   - Baseline Profit = Revenue - Base Daily Cost
   
6. All Other Clients:
   - Profit = Revenue (cost already covered by baseline)

7. Total Profit/Day = Sum of all client profits
8. Annual Profit = Total Profit/Day × Working Days
```

#### Example Test Case:
```
Inputs:
- Salary 100%: 160,000 CHF
- Engagement: 80%
- Multiplier: 1.20
- Working Days: 220
- Client A: 60% allocation, 1,250 CHF/day
- Client B: 20% allocation, 1,250 CHF/day

Results:
- Base Daily Cost: 698.18 CHF
- Client A Revenue/Day: 750 CHF → Profit: 51.82 CHF (baseline)
- Client B Revenue/Day: 250 CHF → Profit: 250 CHF (incremental)
- Total Profit/Day: 301.82 CHF
- Annual Profit: 66,400.40 CHF
```

---

## ✨ Features

### Core Features
- ✅ **Multi-Country Support**: Switzerland, Romania, Spain
- ✅ **Three Calculation Modes**: Start from Net Salary, Gross Salary, or Total Company Cost
- ✅ **Salary Period Toggle**: Monthly or Yearly input options
- ✅ **Reverse Calculations**: Advanced iterative algorithms for net→gross and total→gross
- ✅ **Dual Currency Display**: Always shows both original currency and EUR equivalent
- ✅ **Editable Exchange Rates**: Manual override + auto-refresh from API with 24h cache
- ✅ **Occupation Rate**: Configure part-time or fractional employment (60%, 80%, 100%)
- ✅ **Advanced Options**: Meal benefits (non-taxable), dependents, tax exemptions, pension rates
- ✅ **Business Metrics**: Daily/Monthly sell rates, profit margins, markup calculations
- ✅ **Formula Transparency**: View detailed calculation steps and reverse formulas with "?" help icons
- ✅ **Employee Information**: Capture name, date of birth, and role for reports
- ✅ **Export Capabilities**: PDF export with employee details, full color clarity, and print-friendly layout
- ✅ **Country-Specific Resources**: Switzerland includes LPP pension reference link (www.ciepp.ch)
- ✅ **Responsive Design**: Works on desktop, tablet, and mobile

### Technical Features
- 🏗️ **Modular Architecture**: Separate rule engines per country
- 🔄 **Real-time Calculations**: Instant results with debounced inputs
- 💾 **Client-side Caching**: Exchange rates cached for 24 hours
- 🎨 **TSG Branding**: Professional design with brand colors
- ♿ **Accessibility**: WCAG-compliant design
- 📱 **Mobile-First**: Responsive grid system

---

## 🌍 Supported Countries

### Switzerland - CHF
**Tax Year:** 2026  
**Contributions Implemented:**
- AVS (Old-age insurance): 4.35% employee + 4.35% employer
- AI (Disability insurance): 0.70% employee + 0.70% employer
- APG (Income compensation): 0.25% employee + 0.25% employer
- AC (Unemployment): 1.10% each (capped at monthly ceiling: 12,350 CHF)
- AF (Family allowances): 2.25% employer only
- AMat (Maternity): 0.029% each (Geneva 2026)
- CPE (Training fund): 0.07% employer only
- LFP (Vocational training): 0.03-0.08% employer (configurable)
- LPP (Pension): Variable rate (default 7%, age-dependent) with mandatory cap option
- LAA (Accident insurance): 1% employer (professional), configurable employee (non-professional, default 1.5%)

**2026 BVG/LPP Updates:**
- Minimum salary for LPP: 22,680 CHF/year (updated from 22,050)
- Coordination deduction: 26,460 CHF/year (updated from 25,725)
- **NEW: BVG maximum insured salary: 90,720 CHF/year**
- **NEW: Pension plan mode toggle:**
  - **Mandatory BVG (default)**: Insured salary capped at 90,720 CHF/year
  - **Super-obligatory**: Uncapped insured salary (for higher earners)

**Notes:**
- Income tax NOT included (varies by canton, commune, church)
- AC ceiling: Monthly gross capped at 12,350 CHF (annual ceiling 148,200 / 12)
- LAA non-professional rate varies by insurer (configurable in Advanced Options)
- For high salaries (>90,720 CHF/year), choose pension plan mode in Advanced Options

### Romania - RON
**Contributions Implemented:**
- CAS (Social security): 25% employee
- CASS (Health insurance): 10% employee
- CAM (Work insurance): 2.25% employer
- Income tax: 10% on taxable base
- Personal deduction: 510 RON/month (base function only)
- Dependent deduction: 110 RON/month per dependent

**Notes:**
- Tax exemptions available for IT workers, disabled persons
- Personal deductions only apply if "base function" is checked

### Spain - EUR
**Contributions Implemented:**
- Common Contingencies: 4.70% employee + 23.60% employer
- Unemployment: 1.55% employee + 5.50% employer
- Professional Training: 0.10% employee + 0.60% employer
- FOGASA: 0.20% employer only
- Contribution base: Min 1,323 EUR, Max 4,720.50 EUR/month
- IRPF (Income tax): Progressive bands (19%-47%)

**Notes:**
- IRPF is an **estimate** based on simplified progressive bands
- Actual withholding depends on personal circumstances and autonomous community
- Contribution base limits applied to social security (not IRPF)

---

## 🆕 What's New in v1.1.6 (2025-12-19)

### 🎯 CRITICAL FIX: Target Margin % as TRUE Profit Margin
**Breaking Change:** The B2B "Target Margin %" now uses the **TRUE profit margin formula** (not markup).

**Old Behavior (INCORRECT - Markup):**
```
Cost: 500 EUR, Target: 30%
Placement Rate = 500 × 1.30 = 650 EUR
Actual Margin = (150/650) = 23.08% ❌ NOT 30%!
```

**New Behavior (CORRECT - True Margin):**
```
Cost: 500 EUR, Target: 30%
Placement Rate = 500 ÷ (1 - 0.30) = 714.29 EUR
Actual Margin = (214.29/714.29) = 30.00% ✅ Exactly 30%!
```

**Formula:**
- `daily_placement_rate = daily_cost_rate / (1 - target_margin)`
- `daily_profit = daily_placement_rate - daily_cost_rate`
- `displayed_margin = (daily_profit / daily_placement_rate) × 100`

**Impact:** Client quotes are now correctly priced to maintain the target profit margin.

### 🛠️ Occupation Rate - FIXED Logic
**Previous Bug:** Occupation rate incorrectly changed working days (100% = 220, 80% = 176).

**Current Behavior:**
- ✅ Occupation rate scales **ONLY** salary and employer cost
- ✅ Working days are **ALWAYS** fixed at 220
- ✅ Daily Cost Rate = Annual Total Cost ÷ 220

**Examples:**
```
Full-time Salary: 10,000 RON, Occupation: 100%
→ Adjusted Salary: 10,000 RON, Working Days: 220 ✅

Part-time Salary: 10,000 RON, Occupation: 80%
→ Adjusted Salary: 8,000 RON, Working Days: 220 ✅ (NOT 176!)
```

### 🍽️ Monthly Meal Benefits (Romania)
- Renamed from "Monthly Other Benefits" for clarity
- Properly implemented as **non-taxable**
- Added to:
  - ✓ Total company cost (employer expense)
  - ✓ Employee take-home (benefit value)
  - ✗ NOT added to gross (no tax impact)

### 💱 Currency Conversion - Fixed
**Rule:** All conversions now go through RON as base currency.

**Formula:**
1. Input → RON: `valueRON = valueInput × RON_per_input`
2. RON → Target: `valueTarget = valueRON / RON_per_target`

**Example:** 10,000 RON → CHF
```
Given: 1 EUR = 4.97 RON, 1 EUR = 0.93 CHF
RON per CHF = 4.97 / 0.93 = 5.344
Result: 10,000 / 5.344 = 1,871.17 CHF ✅

WRONG (old): 10,000 × 4.97 = 49,700 CHF ❌
```

### 🎨 UI Improvements
1. **Help Icons (?):** Changed all 22 "!" info icons to "?" help icons
2. **B2B Layout:** "Display Currency" moved after "Client Daily Rate" for better flow
3. **Smart Hiding:** Business Outputs hidden when contractor and client currencies match
4. **Rounding:** Margin percentages shown as 0 decimals (e.g., "30%"), money as 2 decimals

**See TESTING_GUIDE_v1.1.6.md and IMPLEMENTATION_VERIFIED_v1.1.6.md for complete details.**

---

## 📂 Project Structure

```
tsg-salary-calculator/
├── index.html                  # Main HTML file with all three engagement types
├── css/
│   ├── style.css              # Main styles with TSG branding + allocation styles
│   └── print.css              # Print-specific styles
├── js/
│   ├── main.js                # Application entry point
│   ├── calculator.js          # Employee payroll calculation engine
│   ├── allocation.js          # Allocation mode calculation engine (ISOLATED)
│   ├── ui.js                  # UI management and display (all modes)
│   ├── fxService.js           # Currency exchange service
│   └── rules/
│       ├── romania.js         # Romania payroll rules
│       ├── switzerland.js     # Switzerland payroll rules
│       └── spain.js           # Spain payroll rules
├── images/
│   └── tsg-logo.png           # TSG logo
├── README.md                  # This file
└── TEST_CASES.md              # Test cases documentation
```

---

## 🚦 Getting Started

### Prerequisites
- Modern web browser (Chrome 90+, Firefox 88+, Safari 14+, Edge 90+)
- Internet connection (for exchange rates and CDN libraries)

### Installation

1. **Clone or Download** the project files

2. **Open in Browser**:
   ```
   Simply open index.html in your web browser
   ```

3. **Or use a Local Server** (recommended for development):
   ```bash
   # Using Python 3
   python -m http.server 8000
   
   # Using Node.js
   npx serve
   
   # Using PHP
   php -S localhost:8000
   ```
   Then navigate to `http://localhost:8000`

### No Build Process Required
This is a static website with no dependencies to install. All libraries are loaded via CDN.

---

## 📖 How to Use

### Selecting Engagement Type

**First, choose your engagement type:**
1. **👤 Employee** - TSG payroll calculations (CH, RO, ES)
2. **🤝 B2B** - Independent contractor cost modeling
3. **📊 Allocation** - Multi-client profitability modeling *(NEW)*

### Employee Mode Usage

1. **Select Country**: Choose from Switzerland, Romania, or Spain
2. **Select Calculation Mode**: 
   - Start from Net Salary (calculate gross and total)
   - Start from Gross Salary (calculate net and total)
   - Start from Total Company Cost (calculate gross and net)
3. **Enter Amount**: Input the salary or cost amount
4. **Click Calculate**: View detailed results

### B2B Mode Usage

1. **Enter Contractor Cost**: Daily or hourly rate in any currency
2. **Choose Pricing Mode**:
   - Target Margin % (calculate required client rate)
   - Client Daily Rate (calculate margin from rate)
   - Client Budget (work backwards from budget)
3. **Click Calculate**: View profitability analysis

### Allocation Mode Usage *(NEW)*

1. **Enter Base Parameters**:
   - Salary at 100% (annual)
   - Engagement % (e.g., 80%)
   - Employer multiplier (e.g., 1.20)
   - Working days per year (default 220)

2. **Add Clients**:
   - Click "Add Client" to add rows
   - Enter client name, allocation %, and daily rate
   - Total allocation % must not exceed engagement %

3. **Click Calculate**: View:
   - Base daily cost (paid once)
   - Revenue and profit per client
   - Baseline client indicator
   - Total daily and annual profit

### Advanced Options (Employee Mode)

Click "Advanced Options" to access:
- **Monthly Other Benefits**: Additional costs included in total company cost
- **Base Function**: Affects personal deductions (Romania specific)
- **Number of Dependents**: For tax deductions
- **Tax Exemption**: For IT workers, disabled persons (where applicable)
- **LPP Rate**: Pension contribution rate (Switzerland)
- **LFP Rate**: Vocational training rate (Switzerland)

### Display in EUR

Toggle "Display in EUR" to:
- Convert all amounts to EUR using live exchange rates
- View current exchange rate and update date
- Rates are cached for 24 hours for performance

### Business Outputs

Input business parameters to calculate:
- **Daily Cost Rate**: Employee cost per working day (220 days/year)
- **Daily Revenue Rate**: Client billing rate per day
- **Daily Gross Margin**: Profit per day in EUR
- **Gross Margin %**: Profit percentage
- **Required Rates**: Based on target margin or markup

### Export & Print

- **Export to PDF**: Generate PDF document with all results
- **Print**: Print-friendly layout with:
  - ✅ **TSG Logo and Branding** at the top of every print output
  - ✅ **Engagement Type display** (Employee/B2B/Allocation)
  - ✅ **Mode isolation** - Only relevant results for selected mode
  - ✅ Input summary with all calculation parameters
  - ✅ Essential information formatted for printing
  - ✅ Professional appearance with TSG brand colors

---

## 🔧 Configuration & Maintenance

### Updating Tax Rates (Annual Maintenance)

Tax rates change annually. Update files in `js/rules/`:

#### Romania (`js/rules/romania.js`)
```javascript
rates: {
    CAS: 0.25,              // Update if changed
    CASS: 0.10,             // Update if changed
    INCOME_TAX: 0.10,       // Update if changed
    CAM: 0.0225,            // Update if changed
    PERSONAL_DEDUCTION: 510, // Update annually
    DEPENDENT_DEDUCTION: 110 // Update annually
}
```

#### Switzerland (`js/rules/switzerland.js`)
```javascript
rates: {
    AVS_EMPLOYEE: 0.0435,    // Update if changed
    AC_CEILING: 148200,      // Update annually
    LPP_MIN_SALARY: 22050,   // Update annually
    LPP_COORDINATION: 25725, // Update annually
    // ... other rates
}
```

#### Spain (`js/rules/spain.js`)
```javascript
rates: {
    SS_BASE_MIN: 1323.00,    // Update annually
    SS_BASE_MAX: 4720.50,    // Update annually
    IRPF_BANDS: [            // Update if changed
        { limit: 12450, rate: 0.19 },
        { limit: 20200, rate: 0.24 },
        // ...
    ]
}
```

### Updating Working Days

Change in `js/calculator.js`:
```javascript
WORKING_DAYS_PER_YEAR: 220,  // Update if needed
```

### Exchange Rate API

Currently using: `https://api.exchangerate-api.com/v4/latest/EUR`

To change provider, update in `js/fxService.js`:
```javascript
API_URL: 'https://your-api-url.com/rates',
```

### Customizing Brand Colors

Update in `css/style.css`:
```css
:root {
    --tsg-red: #ED1C24;      /* Primary brand color */
    --tsg-black: #231F20;    /* Primary text color */
    --digital-blue: #005DFF; /* Accent color */
    /* ... other colors */
}
```

---

## 🧮 Calculation Methods

### Forward Calculation (Gross → Net)
1. Apply employee social security contributions
2. Calculate taxable base (after deductions)
3. Apply income tax
4. Subtract from gross to get net
5. Add employer contributions to get total cost

### Reverse Calculation (Net → Gross)
**Method**: Newton-Raphson iteration
- Initial estimate: Net × 1.5
- Iterate until convergence (tolerance: 0.01)
- Maximum 50 iterations
- Adjusts based on effective tax rate

### Reverse Calculation (Total → Gross)
**Method**: Binary search
- Search range: 0 to Total Cost
- Iterate until convergence (tolerance: 0.01)
- Maximum 50 iterations
- More stable than Newton-Raphson for this case

### Rounding Rules
- All monetary values rounded to 2 decimal places
- Rounding method: `Math.round(value * 100) / 100`
- Applied consistently across all calculations

---

## 🧪 Testing

See `TEST_CASES.md` for comprehensive test cases covering:
- Basic calculations for all countries
- Edge cases (min/max thresholds)
- Reverse calculations
- Currency conversions
- Business metrics
- Input validation

### Quick Test
```
Country: Romania
Mode: Gross Salary
Amount: 5,000 RON

Expected:
- Net Salary: 3,425.00 RON
- Total Cost: 5,112.50 RON
```

---

## 🐛 Known Limitations & Assumptions

### Switzerland
- ❗ **Income tax NOT included** - varies by canton, commune, church tax
- ⚠️ LPP rates are configurable but age-dependent in reality
- ⚠️ LAA rates are estimates (vary by industry/company)
- ℹ️ AC additional rate (0.5%) above ceiling applies

### Romania
- ⚠️ Meal vouchers not automatically calculated (can be added in benefits)
- ℹ️ Tax exemptions are binary (on/off) - no partial exemptions

### Spain
- ❗ **IRPF is an estimate** - actual withholding varies significantly
- ⚠️ Simplified progressive bands used
- ⚠️ Does not account for:
  - Autonomous community variations
  - Personal circumstances (disability, family situation)
  - Annual adjustments (14 payments vs 12)
- ℹ️ Contribution base limits applied to social security only

### General
- 💱 Exchange rates updated daily (cached 24h)
- 📅 Calculations assume standard employment contracts
- 🔢 Reverse calculations have ±0.01 to ±1.00 tolerance
- 🌐 Requires internet connection for FX rates and CDN libraries

---

## 🔐 Privacy & Data

- ✅ **All calculations performed client-side** (no data sent to servers)
- ✅ **No personal data stored** (except localStorage for FX cache)
- ✅ **No cookies used**
- ✅ **GDPR compliant**
- ⚠️ PDF exports contain entered data (handle appropriately)

---

## 🌐 Browser Compatibility

| Browser | Minimum Version | Status |
|---------|----------------|--------|
| Chrome | 90+ | ✅ Fully Supported |
| Firefox | 88+ | ✅ Fully Supported |
| Safari | 14+ | ✅ Fully Supported |
| Edge | 90+ | ✅ Fully Supported |
| Opera | 76+ | ✅ Fully Supported |
| IE 11 | - | ❌ Not Supported |

### Required Features
- ES6+ JavaScript
- CSS Grid & Flexbox
- Fetch API
- LocalStorage
- CSS Custom Properties

---

## 📊 Performance

- **Initial Load**: < 2s on 3G
- **Calculation Speed**: < 100ms per calculation
- **FX Rate Cache**: 24-hour client-side cache
- **Bundle Size**: No build process, CDN libraries on-demand

---

## 🚧 Future Enhancements

### Planned Features
- [ ] More countries (France, Germany, UK)
- [ ] Export to Excel format
- [ ] Save/load calculation scenarios
- [ ] Comparison mode (side-by-side countries)
- [ ] Annual declaration preview
- [ ] Multi-language support
- [ ] Dark mode theme

### Technical Improvements
- [ ] Add automated unit tests (Jest)
- [ ] Implement service worker for offline use
- [ ] Add progressive web app (PWA) capabilities
- [ ] Optimize for very slow connections

---

## 📞 Support & Contact

**Developed by:** TSG Internal Development Team  
**For questions or issues:** Contact your HR or Finance department

**Version History:**
- v1.2.3 (2026-01-15): **🔧 Swiss Benchmark B2B Fix** - Fixed issue where Swiss Salary Benchmark was incorrectly appearing in B2B mode. Added explicit hiding logic to ensure benchmark ONLY appears in Employee mode for Switzerland.
- v1.2.2 (2026-01-14): **🎯 Swiss Salary Benchmark** - Added intelligent salary benchmarking for Switzerland Employee mode. Features fuzzy job title matching, abbreviation recognition, visual salary ranges, and market position indicators. Handles variations like "ML Engineer" → "Machine Learning Engineer".
- v1.2.1 (2026-01-14): **🖨️ Print Output Improvements** - Added engagement type display to all print outputs, fixed Allocation mode print isolation to prevent showing Employee/B2B results, added TSG logo and branding to print headers
- v1.2.0 (2026-01-13): **🎉 Allocation Mode Launch** - New third engagement type for multi-client profitability modeling. Fully isolated calculations, dynamic client table, incremental profit analysis. Cost paid once, additional allocations generate pure profit.
- v1.1.7 (2026-01-12): **Geneva 2026 payroll corrections** - Fixed AC/ALV ceiling logic, updated AMat to 0.029%, configurable LAA non-prof rate
- v1.1.6 (2025-12-19): B2B mode isolation and UX improvements
- v1.1.3 (2025-12-18): Formula transparency with "!" info icons, employee details in PDF exports
- v1.1.2 (2025-12-18): Enhanced business outputs and dual currency display
- v1.1.1 (2025-12-18): Improved reverse calculations and exchange rate management
- v1.1.0 (2025-12-18): Added salary period selector and business metrics
- v1.0.0 (2025-01-XX): Initial release with CH, RO, ES support


---

## 📄 License

© Technology Staffing Group. All rights reserved.

This tool is for internal use only. Unauthorized distribution prohibited.

---

## 🙏 Acknowledgments

- **Exchange Rates**: exchangerate-api.com
- **Icons**: Font Awesome
- **Fonts**: Google Fonts (Inter)
- **PDF Export**: jsPDF library
- **PDF Rendering**: html2canvas

---

## ⚠️ Disclaimer

This calculator provides **estimates** based on current tax rules and rates. Results should be used for planning purposes only.

**For accurate payroll processing:**
- Consult with certified tax professionals
- Verify with official government sources
- Consider individual circumstances
- Account for local variations and exceptions

Tax laws change frequently. This tool should be reviewed and updated annually.

---

## 📝 Quick Reference Card

### Romania Quick Rates
- CAS: 25% (employee)
- CASS: 10% (employee)
- CAM: 2.25% (employer)
- Income Tax: 10%

### Switzerland Quick Rates
- AVS/AI/APG: 5.3% (employee + employer each)
- AC: 1.1% each
- LPP: ~7-18% (age-dependent)
- AF: 2.25% (employer)

### Spain Quick Rates
- Employee SS: ~6.35%
- Employer SS: ~29.90%
- IRPF: 19-47% (progressive)
- Base: 1,323 - 4,720.50 EUR

---

**Last Updated**: 2025-01-XX  
**Documentation Version**: 1.0.0

/**
 * Allocation Mode Calculator
 * 
 * FULLY ISOLATED - NO SHARED LOGIC WITH EMPLOYEE OR B2B
 * 
 * Purpose: Model commercial profitability when one employee is allocated 
 * to multiple clients. The employer pays one fixed daily cost (deducted once),
 * and additional allocations generate incremental profit.
 * 
 * This is NOT payroll allocation. This is commercial profitability modeling.
 */

const AllocationCalculator = {
    /**
     * State for Allocation mode (ISOLATED)
     */
    allocationState: {
        salary100: 0,
        engagementPct: 0,
        employerMultiplier: 1.20,
        workingDays: 220,
        clients: []
    },

    /**
     * Initialize Allocation calculator
     */
    init() {
        console.log('Allocation Calculator - Initialized');
    },

    /**
     * Validate allocation inputs
     * @param {Object} inputs - Input parameters
     * @returns {Object} - {valid: boolean, error: string}
     */
    validate(inputs) {
        const { salary100, engagementPct, employerMultiplier, workingDays, clients } = inputs;

        // Basic validation
        if (!salary100 || salary100 <= 0) {
            return { valid: false, error: 'Salary at 100% must be greater than 0' };
        }

        if (!engagementPct || engagementPct <= 0 || engagementPct > 100) {
            return { valid: false, error: 'Engagement % must be between 0 and 100' };
        }

        if (!employerMultiplier || employerMultiplier < 1) {
            return { valid: false, error: 'Employer multiplier must be at least 1.00' };
        }

        if (!workingDays || workingDays <= 0) {
            return { valid: false, error: 'Working days must be greater than 0' };
        }

        if (!clients || clients.length === 0) {
            return { valid: false, error: 'At least one client is required' };
        }

        // Validate each client
        for (let i = 0; i < clients.length; i++) {
            const client = clients[i];
            
            if (!client.name || client.name.trim() === '') {
                return { valid: false, error: `Client ${i + 1}: Name is required` };
            }

            if (client.allocationPct === null || client.allocationPct === undefined || client.allocationPct < 0 || client.allocationPct > 100) {
                return { valid: false, error: `Client ${client.name}: Allocation % must be between 0 and 100` };
            }

            if (!client.dailyRate || client.dailyRate < 0) {
                return { valid: false, error: `Client ${client.name}: Daily rate must be 0 or greater` };
            }
        }

        // CRITICAL VALIDATION: Sum of allocation % must not exceed engagement %
        const totalAllocationPct = clients.reduce((sum, client) => sum + parseFloat(client.allocationPct || 0), 0);
        
        if (totalAllocationPct > engagementPct) {
            return { 
                valid: false, 
                error: `Sum of allocation % (${totalAllocationPct.toFixed(1)}%) exceeds engagement % (${engagementPct}%). Please adjust client allocations.` 
            };
        }

        return { valid: true };
    },

    /**
     * Calculate allocation profitability
     * @param {Object} inputs - Input parameters
     * @returns {Object} - Calculation results
     */
    calculate(inputs) {
        // Validate inputs first
        const validation = this.validate(inputs);
        if (!validation.valid) {
            return {
                success: false,
                error: validation.error
            };
        }

        const { salary100, engagementPct, employerMultiplier, workingDays, clients } = inputs;

        // Step 1: Engaged salary
        const engagedSalary = salary100 * (engagementPct / 100);

        // Step 2: Employer annual cost
        const employerCostAnnual = engagedSalary * employerMultiplier;

        // Step 3: Base daily cost (PAID ONCE - this is the key)
        const baseDailyCost = employerCostAnnual / workingDays;

        // Step 4: Calculate per-client metrics
        const clientResults = [];
        let maxRevenueClient = null;
        let maxRevenue = -1;

        for (const client of clients) {
            const allocationPct = parseFloat(client.allocationPct || 0);
            const dailyRate = parseFloat(client.dailyRate || 0);

            // Client revenue per day
            const clientRevenuePerDay = dailyRate * (allocationPct / 100);

            // Track which client has highest revenue (baseline)
            if (clientRevenuePerDay > maxRevenue) {
                maxRevenue = clientRevenuePerDay;
                maxRevenueClient = client.name;
            }

            clientResults.push({
                name: client.name,
                allocationPct: allocationPct,
                dailyRate: dailyRate,
                revenuePerDay: clientRevenuePerDay,
                isBaseline: false, // Will set this after loop
                profitPerDay: 0 // Will calculate after identifying baseline
            });
        }

        // Step 5: Identify baseline client
        // The baseline client is the one that covers the cost
        for (const result of clientResults) {
            if (result.name === maxRevenueClient) {
                result.isBaseline = true;
                // Baseline profit = revenue - base cost
                result.profitPerDay = result.revenuePerDay - baseDailyCost;
            } else {
                // All other clients: profit = revenue (cost already covered)
                result.profitPerDay = result.revenuePerDay;
            }
        }

        // Step 6: Total revenue per day
        const totalRevenuePerDay = clientResults.reduce((sum, client) => sum + client.revenuePerDay, 0);

        // Step 7: Total profit per day (COST PAID ONCE)
        const totalProfitPerDay = totalRevenuePerDay - baseDailyCost;

        // Step 8: Annual profit
        const annualProfit = totalProfitPerDay * workingDays;

        // Step 9: Profit margin
        const profitMarginPct = totalRevenuePerDay > 0 ? (totalProfitPerDay / totalRevenuePerDay * 100) : 0;

        // Return results
        return {
            success: true,
            inputs: {
                salary100,
                engagementPct,
                employerMultiplier,
                workingDays
            },
            calculated: {
                engagedSalary: this.round(engagedSalary),
                employerCostAnnual: this.round(employerCostAnnual),
                baseDailyCost: this.round(baseDailyCost),
                totalRevenuePerDay: this.round(totalRevenuePerDay),
                totalProfitPerDay: this.round(totalProfitPerDay),
                annualProfit: this.round(annualProfit),
                profitMarginPct: this.round(profitMarginPct, 1)
            },
            clients: clientResults.map(client => ({
                ...client,
                revenuePerDay: this.round(client.revenuePerDay),
                profitPerDay: this.round(client.profitPerDay)
            }))
        };
    },

    /**
     * Round to specified decimal places
     * @param {number} value - Value to round
     * @param {number} decimals - Number of decimal places (default 2)
     * @returns {number} - Rounded value
     */
    round(value, decimals = 2) {
        const factor = Math.pow(10, decimals);
        return Math.round(value * factor) / factor;
    },

    /**
     * Format currency for display
     * @param {number} value - Value to format
     * @param {string} currency - Currency code (default CHF)
     * @returns {string} - Formatted string
     */
    formatCurrency(value, currency = 'CHF') {
        return `${this.round(value).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ${currency}`;
    }
};

// Initialize on load
if (typeof document !== 'undefined') {
    document.addEventListener('DOMContentLoaded', () => {
        AllocationCalculator.init();
    });
}
